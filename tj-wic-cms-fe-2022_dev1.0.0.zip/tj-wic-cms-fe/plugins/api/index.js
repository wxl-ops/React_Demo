import services from './service'

export default {
  install(Vue) {
    Vue.prototype.$api = {
      ...Vue.prototype.$api,
      ...services
    }
  }
}
