import Vue from 'vue'
import VueBus from 'vue-bus'
import './iview'
import plugins from './plugins'
import apiPlugin from './api'
import globalMix from '@/mixins/global'

Vue.use(VueBus)
Vue.use(plugins)
Vue.use(apiPlugin)
Vue.mixin(globalMix)
