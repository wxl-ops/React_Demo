const includeArray = (list1, list2) => {
  let status = false
  list2.forEach((item) => {
    if (list1.includes(item)) status = true
  })
  return status
}

export default {
  inserted(el, binding, vnode) {
    const store = window?.$nuxt?.$store
    const { value } = binding
    const { access } = store.state.wau.user.info

    if (
      value &&
      Array.isArray(value) &&
      value.length &&
      access &&
      access.length
    ) {
      const isPermission = includeArray(value, access)
      if (!isPermission) {
        el.parentNode && el.parentNode.removeChild(el)
      }
    } else {
      el.parentNode && el.parentNode.removeChild(el)
    }
  }
}
