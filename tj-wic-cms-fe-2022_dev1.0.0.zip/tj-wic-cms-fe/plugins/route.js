import iView from 'view-design'
import menus from '@/menu/sider'
import util from '@/libs/util'

export default ({ app, store }) => {
  iView.LoadingBar.start()
  const menuLoadOver = false
  // 加载菜单
  // const loadMenu = (to) => {
  //   store.dispatch('wau/menu/load').then((role) => {
  //     menuLoadOver = true
  //     app.store.role = role
  //     // 判断是否已路由页面
  //     if (to.name === 'custom') {
  //       app.router.replace({
  //         name: 'error-404'
  //       })
  //     } else {
  //       app.router.replace({
  //         name: to.name,
  //         query: to.query
  //       })
  //     }
  //   })
  // }
  window.addEventListener(
    'hashchange',
    () => {
      window.location.reload()
    },
    false
  )
  // store.dispatch('wau/user/load')
  // store.commit('wau/status/setLoadingStatus', {
  //   field: 'pageCreating',
  //   status: false
  // })
  // store.commit('wau/page/changePager', {
  //   current: 1,
  //   pageSize: 10,
  //   total: 0
  // })
  app.router.beforeEach((to, from, next) => {
    console.log('页面跳转时的值')
    console.log(window.isEditIng)
    if (window.isEditIng === true) {
      setTimeout(() => {
        console.log('延后的处理')
        iView.Modal.confirm({
          title: '离开页面',
          content: `正在操作离开，请确认当前编辑内容已保存!`,
          closable: true,
          onOk: () => {
            window.isEditIng = false
            app.router.replace({
              name: to.name,
              query: to.query,
              parms: to.parms
            })
          }
        })
        next(false)
      }, 100)
    } else {
      iView.LoadingBar.start()
      const token = util.cookies.get('token')
      if (!token || token === 'undefined') {
        if (to.name !== 'account-login') {
          setTimeout(() => {
            app.router.replace({
              name: 'account-login'
            })
          }, 50)
          next(false)
          // window.location.href = '/account/login'
          // next()
        } else {
          next()
        }
      } else if (menuLoadOver === false) {
        // loadMenu(to)
        next()
      } else {
        next()
      }
    }
  })
  app.router.afterEach((to, from) => {
    iView.LoadingBar.finish()
    if (to.path !== '/account/login') {
      let current = {}
      menus.forEach((menu, mIndex) => {
        if (menu.children) {
          menu.children.forEach((subMenu) => {
            if (subMenu.path === to.path) {
              current = {
                menu,
                subMenu
              }
            } else if (subMenu.children) {
              subMenu.children.forEach((subChildrenMenu) => {
                if (subChildrenMenu.path === to.path) {
                  current = {
                    menu,
                    subMenu,
                    subChildrenMenu
                  }
                }
              })
            }
          })
        }
      })
      store.commit('wau/crumb/changeCrumb', current)
    }
  })
}
