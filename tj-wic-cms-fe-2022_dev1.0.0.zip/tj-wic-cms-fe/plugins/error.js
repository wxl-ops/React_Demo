export default {
  install(Vue, options) {
    Vue.config.errorHandler = function(error, instance, info) {
      if (process.env.NODE_ENV === 'development') {
        console.log(info)
        console.log(instance)
        console.log(error)
      }
    }
  }
}
