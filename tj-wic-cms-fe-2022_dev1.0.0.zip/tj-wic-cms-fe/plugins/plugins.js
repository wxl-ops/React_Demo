import components from '@/components'
import filters from '@/filters/index'
import directiveAuth from '@/plugins/auth'

export default {
  install(Vue, options) {
    Object.keys(components).forEach((key) => {
      Vue.component(key, components[key])
    })
    Object.keys(filters).forEach((key) => {
      Vue.filter(key, filters[key])
    })
    Vue.directive('auth', directiveAuth)
  }
}
