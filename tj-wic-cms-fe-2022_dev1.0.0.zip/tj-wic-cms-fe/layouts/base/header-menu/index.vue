<template>
  <div class="layout-nav">
    <MenuItem
      v-for="(menu, index) in list"
      :key="index"
      :to="menu.path"
      :name="`${index + 1}`"
    >
      <Icon :type="menu.icon"></Icon>
      {{ menu.title }}
    </MenuItem>
  </div>
</template>

<script>
import list from '@/menu/header'
export default {
  data() {
    return {
      list
    }
  }
}
</script>
