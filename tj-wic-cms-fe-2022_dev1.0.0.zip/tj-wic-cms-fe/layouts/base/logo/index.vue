<template>
  <div class="wau-logo" @click="goIndex">
    <img src="@/static/images/logo.png" alt="logo" />
    <span>{{ title }}</span>
  </div>
</template>

<script>
export default {
  data() {
    return {
      title: ''
    }
  },
  methods: {
    goIndex() {
      this.$router.push({
        name: 'index'
      })
    }
  }
}
</script>

<style lang="less">
.wau-logo {
  float: left;
  height: 45px;
  margin: 10px 0;
  font-size: 20px;
  line-height: 45px;
  color: #fff;
  cursor: pointer;
  img {
    height: 100%;
  }
  span {
    vertical-align: top;
    margin-left: 15px;
  }
}
</style>
