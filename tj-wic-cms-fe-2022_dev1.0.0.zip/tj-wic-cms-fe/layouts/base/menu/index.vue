<template>
  <Menu
    v-if="menus.length > 0"
    :active-name="activeName"
    :open-names="openNames"
    :theme="theme"
    :accordion="true"
    width="auto"
    :class="menuitemClasses"
  >
    <Submenu
      v-for="(menu, mIndex) in menus"
      :key="mIndex"
      :name="`${mIndex + 1}`"
    >
      <template slot="title">
        <Icon :type="menu.icon"></Icon>
        <span>{{ menu.title }}</span>
      </template>
      <div v-for="(subMenu, sIndex) in menu.children" :key="sIndex">
        <MenuItem
          v-if="isHidden(subMenu)"
          :name="`${mIndex + 1}-${sIndex + 1}`"
          :to="subMenu.path"
          >{{ subMenu.title }}</MenuItem
        >
      </div>
    </Submenu>
    <MenuItem
      v-if="checkUrl('yun_exhibition_hall')"
      name="url1"
      class="singLink"
      to="https://conf.cantonfair.org.cn/home"
      target="_blank"
      ><Icon type="md-cloudy" />云展厅管理平台</MenuItem
    >
    <MenuItem
      v-if="checkUrl('user_manager')"
      name="url3"
      class="singLink"
      :replace="false"
      :to="getFullUrl('/usrv/oss/v3#/iframe-user?type=user')"
      target="_blank"
      ><Icon type="md-cloudy" />用户管理</MenuItem
    >
    <MenuItem
      v-if="false"
      name="url2"
      class="singLink"
      to="http://www.qq.com"
      target="_blank"
      ><Icon type="md-cloudy" />数据看板</MenuItem
    >
    <!-- <li class="ivu-menu-submenu" @click="getDataUrl">
      <div class="ivu-menu-submenu-title">
        <Icon type="md-cloudy" />数据统计
      </div>
    </li> -->
  </Menu>
</template>

<script>
import { mapState } from 'vuex'
import localSiders from '@/menu/sider'
import WauConfig from '@/wau.config'
import { getDataUrl } from '@/api/common'
export default {
  props: {
    isCollapsed: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      menus: [],
      permission_list: '',
      activeName: '1-1',
      openNames: ['1'],
      theme: WauConfig.layout.siderTheme
    }
  },
  computed: {
    // ...mapState('wau/menu', ['siders', 'permissionStr']),
    ...mapState('wau/menu', ['permissionStr']),
    menuitemClasses() {
      return ['menu-item', this.isCollapsed ? 'collapsed-menu' : '']
    }
  },
  watch: {
    // siders: {
    //   handler(siders) {
    //     if (siders.length > 0) {
    //       this.menus = siders
    //       this.loadCurrent()
    //     }
    //   },
    //   immediate: true
    // }
  },
  mounted() {
    this.menus = localSiders
    this.loadCurrent()
  },
  methods: {
    isHidden({ auth }) {
      if (auth && auth.includes('hidden')) {
        return false
      } else {
        return true
      }
    },
    // 判断跳转页权限
    checkUrl(key) {
      if (String(this.permissionStr).includes(key + '_')) {
        return true
      } else {
        return false
      }
    },
    getFullUrl(_url) {
      return window.location.protocol + '//' + window.location.host + _url
    },
    // 获取数据统计的url地址
    getDataUrl() {
      getDataUrl().then((res) => {
        if (res.ret === 0) {
          window.open(res.data.url)
        }
      })
    },
    loadCurrent() {
      let current = ''
      this.menus.forEach((menu, mIndex) => {
        menu.children.forEach((subMenu, sIndex) => {
          if (subMenu.path === this.$route.path) {
            current = {
              ...subMenu,
              activeName: `${mIndex + 1}-${sIndex + 1}`,
              parentName: `${mIndex + 1}`
            }
          }
        })
      })
      this.activeName = current.activeName
      this.openNames = [current.parentName]
      window.title = current.title
    }
  }
}
</script>

<style lang="less">
.layout {
  border: 1px solid #d7dde4;
  background: #f5f7f9;
  position: relative;
  border-radius: 4px;
  overflow: hidden;
}
.layout-header-bar {
  background: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
}
.layout-logo-left {
  width: 90%;
  height: 30px;
  background: #5b6270;
  border-radius: 3px;
  margin: 15px auto;
}
.menu-icon {
  transition: all 0.3s;
}
.rotate-icon {
  transform: rotate(-90deg);
}
.menu-item {
  height: calc(100vh - 64px);
  overflow-y: auto;
}
.menu-item span {
  display: inline-block;
  overflow: hidden;
  width: 69px;
  text-overflow: ellipsis;
  white-space: nowrap;
  vertical-align: bottom;
  transition: width 0.2s ease 0.2s;
}
.menu-item i {
  transform: translateX(0px);
  transition: font-size 0.2s ease, transform 0.2s ease;
  vertical-align: middle;
  font-size: 16px;
}
.collapsed-menu span {
  width: 0px;
  transition: width 0.2s ease;
}
.collapsed-menu .ivu-menu {
  display: none;
}
.collapsed-menu i {
  transform: translateX(5px);
  transition: font-size 0.2s ease 0.2s, transform 0.2s ease 0.2s;
  vertical-align: middle;
  font-size: 22px;
  &.ivu-icon-ios-arrow-down,
  &.ivu-icon-ios-arrow-down {
    display: none;
  }
}
.ivu-menu-submenu-title {
  .ivu-menu-submenu-title-icon {
    right: 10px;
  }
}
.singLink {
  i {
    margin-left: 0px;
    margin-right: 10px;
  }
  a {
    color: rgba(255, 255, 255, 0.7);
    &:hover {
      color: #fff;
    }
  }
}
</style>
