<template>
  <span
    class="i-layout-header-trigger i-layout-header-trigger-min"
    @click="toggleFullscreen"
  >
    <Icon v-if="!isFullscreen" type="md-expand" size="23" title="全屏显示" />
    <Icon v-if="isFullscreen" type="md-contract" size="23" title="退出全屏" />
  </span>
</template>
<script>
import { mapState, mapActions } from 'vuex'

export default {
  name: 'IHeaderFullscreen',
  computed: {
    ...mapState('wau/layout', ['isFullscreen'])
  },
  methods: {
    ...mapActions('wau/layout', ['toggleFullscreen'])
  }
}
</script>

<style scoped lang="less">
.i-layout-header-trigger {
  cursor: pointer;
  i {
    vertical-align: middle;
    margin-right: 15px;
    color: #888888;
  }
  &:hover i {
    color: #fff;
  }
}
</style>
