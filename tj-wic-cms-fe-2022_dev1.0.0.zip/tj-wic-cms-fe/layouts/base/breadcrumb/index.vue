<template>
  <Breadcrumb v-if="menu.title" class="wau-breadcrumb ivu-p">
    <BreadcrumbItem>首页</BreadcrumbItem>
    <BreadcrumbItem v-if="menu.title">{{ menu.title }}</BreadcrumbItem>
    <BreadcrumbItem v-if="subMenu.title">{{ subMenu.title }}</BreadcrumbItem>
    <BreadcrumbItem v-if="subChildrenMenu.title">{{
      subChildrenMenu.title
    }}</BreadcrumbItem>
  </Breadcrumb>
</template>

<script>
import { mapState } from 'vuex'
import menus from '@/menu/sider'
export default {
  data() {
    return {
      menus,
      current: {}
    }
  },
  computed: {
    ...mapState('wau/crumb', ['crumb']),
    menu() {
      return this.crumb?.menu || {}
    },
    subMenu() {
      return this.crumb?.subMenu || {}
    },
    subChildrenMenu() {
      return this.crumb?.subChildrenMenu || {}
    }
  },
  mounted() {
    let current = {}
    menus.forEach((menu, mIndex) => {
      menu.children.forEach((subMenu, sIndex) => {
        if (subMenu.path === this.$route.path) {
          current = {
            menu,
            subMenu
          }
        } else if (subMenu.children) {
          subMenu.children.forEach((subChildrenMenu) => {
            if (subChildrenMenu.path === this.$route.path) {
              current = {
                menu,
                subMenu,
                subChildrenMenu
              }
            }
          })
        }
      })
    })
    this.current = current
  }
}
</script>

<style lang="less">
.wau-breadcrumb {
  background: #fff;
  border-bottom: solid 1px #f1f1f1;
}
</style>
