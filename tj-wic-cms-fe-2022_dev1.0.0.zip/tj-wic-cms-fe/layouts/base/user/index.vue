<template>
  <span class="i-layout-header-trigger i-layout-header-trigger-min">
    <Dropdown
      trigger="hover"
      class="i-layout-header-user"
      @on-click="handleClick"
    >
      <Avatar class="closeBtn" size="small" icon="md-power" />
      <span v-if="false" class="i-layout-header-user-name">{{
        info.real_name
      }}</span>
      <DropdownMenu slot="list">
        <DropdownItem divided name="logout">
          <Icon type="ios-log-out" />
          <span>退出登录</span>
        </DropdownItem>
      </DropdownMenu>
    </Dropdown>
  </span>
</template>
<script>
import util from '@/libs/util'
import { AccountLogout } from '@/api/account'
export default {
  name: 'IHeaderUser',
  computed: {},
  methods: {
    quit() {
      const that = this
      // 删除cookie
      util.cookies.remove('token')
      util.cookies.remove('uuid')
      that.$Message.loading({
        content: '正在退出...',
        background: true,
        duration: 0
      })
      AccountLogout().then(() => {
        that.$Message.destroy()
        that.$router.replace({
          name: 'account-login'
        })
      })
    },
    handleClick(name) {
      const that = this
      // 退出登陆
      if (name === 'logout') {
        if (window.isEditIng === true) {
          that.$Modal.confirm({
            title: '退出登陆',
            content: `正在操作离开，请确认当前编辑内容已保存!`,
            closable: true,
            onOk: () => {
              window.isEditIng = false
              that.quit()
            }
          })
        } else {
          that.quit()
        }
      }
    }
  }
}
</script>

<style lang="less">
.i-layout-header-user-name {
  color: #fff;
}
.closeBtn {
  cursor: pointer;
  background: #777777 !important;
  color: #ffffff;
  &:hover {
    background: #ffffff !important;
    color: #777777;
  }
}
</style>
