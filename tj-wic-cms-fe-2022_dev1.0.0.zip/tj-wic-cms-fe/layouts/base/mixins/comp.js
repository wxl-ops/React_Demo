import WauMenu from '../menu'
import WauFullscreen from '../header-fullscreen'
import WauBreadcrumb from '../breadcrumb'
import WauUser from '../user'
import WauHeaderMenu from '../header-menu'
import WauLogo from '../logo'

export default {
  components: {
    WauFullscreen,
    WauMenu,
    WauBreadcrumb,
    WauUser,
    WauHeaderMenu,
    WauLogo
  }
}
