<style scoped>
.layout {
  border: 1px solid #d7dde4;
  background: #f5f7f9;
  position: relative;
  border-radius: 4px;
  overflow: hidden;
}
.layout-logo {
  width: 100px;
  height: 30px;
  background: #5b6270;
  border-radius: 3px;
  float: left;
  position: relative;
  top: 15px;
  left: 20px;
}
.layout-nav {
  width: auto;
  margin: 0 auto;
  margin-right: 20px;
  float: right;
}
</style>
<template>
  <Layout class="layout wau-layout">
    <Layout>
      <Sider
        hide-trigger
        class="wau-sider"
        :class="siderTheme"
        :width="WauConfig.layout.siderMenuWidth"
      >
        <wau-menu></wau-menu>
      </Sider>

      <Layout
        class="wau-layout-content"
        :class="{ 'wau-layout-content-crumb': WauConfig.showBreadcrumb }"
      >
        <wau-breadcrumb v-if="WauConfig.showBreadcrumb"></wau-breadcrumb>
        <nuxt />
      </Layout>
    </Layout>
  </Layout>
</template>

<script>
import compMix from './base/mixins/comp'
import WauConfig from '@/wau.config'
export default {
  mixins: [compMix],
  data() {
    return {
      WauConfig
    }
  },
  computed: {
    siderTheme() {
      if (this.WauConfig.layout.siderTheme === 'dark') {
        return `wau-sider-dark`
      } else {
        return `wau-sider-light`
      }
    }
  }
}
</script>
