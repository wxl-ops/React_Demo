<template>
  <!-- 空布局，已经引入 iframe 自适应 -->
  <div class="empty-layout">
    <nuxt />
  </div>
</template>

<script>
import iframeMix from '@/wau/mixins/iframe'
export default {
  mixins: [iframeMix]
}
</script>

<style lang="less">
.empty-layout {
  background: #f1f1f1;
}
</style>
