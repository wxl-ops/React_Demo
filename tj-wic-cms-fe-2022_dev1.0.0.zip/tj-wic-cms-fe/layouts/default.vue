<template>
  <Layout :class="showHeader ? 'layout wau-layout' : ''">
    <Header v-if="showHeader" class="wau-header">
      <Menu
        class="wau-header-menu"
        mode="horizontal"
        theme="dark"
        active-name="1"
      >
        <wau-logo></wau-logo>
        <wau-header-menu></wau-header-menu>
      </Menu>
      <wau-fullscreen />
      <wau-user></wau-user>
    </Header>
    <Layout v-if="showHeader">
      <Sider
        hide-trigger
        class="wau-sider"
        :class="siderTheme"
        :width="WauConfig.layout.siderMenuWidth"
      >
        <wau-menu></wau-menu>
      </Sider>

      <Layout
        class="wau-layout-content"
        :class="{ 'wau-layout-content-crumb': WauConfig.showBreadcrumb }"
      >
        <wau-breadcrumb v-if="WauConfig.showBreadcrumb"></wau-breadcrumb>
        <nuxt class="wau-layout-content-page" />
      </Layout>
    </Layout>
    <nuxt v-if="!showHeader && $route.name" />
  </Layout>
</template>

<script>
import compMix from './base/mixins/comp'
import WauConfig from '@/wau.config'
export default {
  mixins: [compMix],
  data() {
    return {
      showHeader: true,
      WauConfig
    }
  },
  computed: {
    siderTheme() {
      if (this.WauConfig.layout.siderTheme === 'dark') {
        return `wau-sider-dark`
      } else {
        return `wau-sider-light`
      }
    }
  },
  watch: {
    $route(to, from) {
      this.setPage(to)
    }
  },
  created() {
    this.setPage(this.$route)
  },

  methods: {
    setPage(currRoute) {
      if (
        !currRoute.name ||
        currRoute.name === 'account-login' ||
        currRoute.name === 'custom'
      ) {
        this.showHeader = false
      } else {
        this.showHeader = true
      }
    }
  }
}
</script>

<style scoped>
.layout {
  border: none;
  background: #f5f7f9;
  position: relative;
  border-radius: 0;
  overflow: hidden;
}
.layout-logo {
  width: 100px;
  height: 30px;
  background: #5b6270;
  border-radius: 3px;
  float: left;
  position: relative;
  top: 15px;
  left: 20px;
}
.layout-nav {
  width: auto;
  margin: 0 auto;
  margin-right: 20px;
  float: right;
}
.wau-header {
  padding: 0 20px 0 10px;
}
.wau-layout-content {
  background: #fff;
}
.wau-layout-content-page {
  padding: 15px 20px;
}
</style>
<style>
.ivu-select-dropdown {
  z-index: 1000;
}
</style>
