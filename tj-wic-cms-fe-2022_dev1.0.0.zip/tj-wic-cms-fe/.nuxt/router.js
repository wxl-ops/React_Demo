import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _6e19ab77 = () => interopDefault(import('..\\pages\\account\\login\\index.vue' /* webpackChunkName: "pages_account_login_index" */))
const _458669ea = () => interopDefault(import('..\\pages\\agendaofConference\\en\\index.vue' /* webpackChunkName: "pages_agendaofConference_en_index" */))
const _6c68415a = () => interopDefault(import('..\\pages\\agendaofConference\\type\\index.vue' /* webpackChunkName: "pages_agendaofConference_type_index" */))
const _3fd27366 = () => interopDefault(import('..\\pages\\agendaofConference\\zh\\index.vue' /* webpackChunkName: "pages_agendaofConference_zh_index" */))
const _77fb58ac = () => interopDefault(import('..\\pages\\cloudEvents\\en\\index.vue' /* webpackChunkName: "pages_cloudEvents_en_index" */))
const _2697fc05 = () => interopDefault(import('..\\pages\\cloudEvents\\zh\\index.vue' /* webpackChunkName: "pages_cloudEvents_zh_index" */))
const _3c7faa84 = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\en\\index.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_en_index" */))
const _4455d319 = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\zh\\index.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_zh_index" */))
const _7d3d9dc2 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\en\\index.vue' /* webpackChunkName: "pages_cloudSeriesActivities_en_index" */))
const _4de91b24 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\type\\index.vue' /* webpackChunkName: "pages_cloudSeriesActivities_type_index" */))
const _23f6d97a = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\zh\\index.vue' /* webpackChunkName: "pages_cloudSeriesActivities_zh_index" */))
const _032320d3 = () => interopDefault(import('..\\pages\\conferenceGuests\\en\\index.vue' /* webpackChunkName: "pages_conferenceGuests_en_index" */))
const _65b8c92e = () => interopDefault(import('..\\pages\\conferenceGuests\\zh\\index.vue' /* webpackChunkName: "pages_conferenceGuests_zh_index" */))
const _53d23cad = () => interopDefault(import('..\\pages\\cooperativePartner\\en\\index.vue' /* webpackChunkName: "pages_cooperativePartner_en_index" */))
const _d9305b08 = () => interopDefault(import('..\\pages\\cooperativePartner\\type\\index.vue' /* webpackChunkName: "pages_cooperativePartner_type_index" */))
const _933035f0 = () => interopDefault(import('..\\pages\\cooperativePartner\\zh\\index.vue' /* webpackChunkName: "pages_cooperativePartner_zh_index" */))
const _610c4fe3 = () => interopDefault(import('..\\pages\\error\\404\\index.vue' /* webpackChunkName: "pages_error_404_index" */))
const _24238406 = () => interopDefault(import('..\\pages\\error\\500\\index.vue' /* webpackChunkName: "pages_error_500_index" */))
const _14d01584 = () => interopDefault(import('..\\pages\\eventIntroduction\\en\\index.vue' /* webpackChunkName: "pages_eventIntroduction_en_index" */))
const _7765bddf = () => interopDefault(import('..\\pages\\eventIntroduction\\zh\\index.vue' /* webpackChunkName: "pages_eventIntroduction_zh_index" */))
const _a6582506 = () => interopDefault(import('..\\pages\\excellentCases\\en\\index.vue' /* webpackChunkName: "pages_excellentCases_en_index" */))
const _0f6995d8 = () => interopDefault(import('..\\pages\\excellentCases\\zh\\index.vue' /* webpackChunkName: "pages_excellentCases_zh_index" */))
const _1757fa12 = () => interopDefault(import('..\\pages\\greatDemo\\showConfig\\index.vue' /* webpackChunkName: "pages_greatDemo_showConfig_index" */))
const _79769e4c = () => interopDefault(import('..\\pages\\home\\list.vue' /* webpackChunkName: "pages_home_list" */))
const _1240f43e = () => interopDefault(import('..\\pages\\homoSapiens\\en\\index.vue' /* webpackChunkName: "pages_homoSapiens_en_index" */))
const _74d69c99 = () => interopDefault(import('..\\pages\\homoSapiens\\zh\\index.vue' /* webpackChunkName: "pages_homoSapiens_zh_index" */))
const _53dfb0bc = () => interopDefault(import('..\\pages\\hotelGuide\\en\\index.vue' /* webpackChunkName: "pages_hotelGuide_en_index" */))
const _38a5cffd = () => interopDefault(import('..\\pages\\hotelGuide\\zh\\index.vue' /* webpackChunkName: "pages_hotelGuide_zh_index" */))
const _0dbdee16 = () => interopDefault(import('..\\pages\\material\\enclosure\\index.vue' /* webpackChunkName: "pages_material_enclosure_index" */))
const _93bbcd60 = () => interopDefault(import('..\\pages\\material\\file\\index.vue' /* webpackChunkName: "pages_material_file_index" */))
const _068c42fa = () => interopDefault(import('..\\pages\\material\\music\\index.vue' /* webpackChunkName: "pages_material_music_index" */))
const _9f8ec2ec = () => interopDefault(import('..\\pages\\material\\picture\\index.vue' /* webpackChunkName: "pages_material_picture_index" */))
const _1ada866d = () => interopDefault(import('..\\pages\\material\\video\\index.vue' /* webpackChunkName: "pages_material_video_index" */))
const _7435a0ac = () => interopDefault(import('..\\pages\\mediaInvitationCode\\code\\index.vue' /* webpackChunkName: "pages_mediaInvitationCode_code_index" */))
const _0878841f = () => interopDefault(import('..\\pages\\newsInformation\\en\\index.vue' /* webpackChunkName: "pages_newsInformation_en_index" */))
const _aee4fd94 = () => interopDefault(import('..\\pages\\newsInformation\\hoten\\index.vue' /* webpackChunkName: "pages_newsInformation_hoten_index" */))
const _0b232991 = () => interopDefault(import('..\\pages\\newsInformation\\hotzh\\index.vue' /* webpackChunkName: "pages_newsInformation_hotzh_index" */))
const _90cbf524 = () => interopDefault(import('..\\pages\\newsInformation\\type\\index.vue' /* webpackChunkName: "pages_newsInformation_type_index" */))
const _6b0e2c7a = () => interopDefault(import('..\\pages\\newsInformation\\zh\\index.vue' /* webpackChunkName: "pages_newsInformation_zh_index" */))
const _7f64c975 = () => interopDefault(import('..\\pages\\pcConfiguration\\en\\index.vue' /* webpackChunkName: "pages_pcConfiguration_en_index" */))
const _3c0b1c60 = () => interopDefault(import('..\\pages\\pcConfiguration\\zh\\index.vue' /* webpackChunkName: "pages_pcConfiguration_zh_index" */))
const _4cdecd9d = () => interopDefault(import('..\\pages\\questionnaire\\enterprise\\index.vue' /* webpackChunkName: "pages_questionnaire_enterprise_index" */))
const _397eb766 = () => interopDefault(import('..\\pages\\questionnaire\\naire\\index.vue' /* webpackChunkName: "pages_questionnaire_naire_index" */))
const _b1ef90e0 = () => interopDefault(import('..\\pages\\registeredUsers\\user\\index.vue' /* webpackChunkName: "pages_registeredUsers_user_index" */))
const _6b95d6e7 = () => interopDefault(import('..\\pages\\registrationAgreement\\en\\index.vue' /* webpackChunkName: "pages_registrationAgreement_en_index" */))
const _63a9017c = () => interopDefault(import('..\\pages\\registrationAgreement\\zh\\index.vue' /* webpackChunkName: "pages_registrationAgreement_zh_index" */))
const _67b6493f = () => interopDefault(import('..\\pages\\scheduleGlance\\en\\index.vue' /* webpackChunkName: "pages_scheduleGlance_en_index" */))
const _6b681ccc = () => interopDefault(import('..\\pages\\scheduleGlance\\zh\\index.vue' /* webpackChunkName: "pages_scheduleGlance_zh_index" */))
const _eb080570 = () => interopDefault(import('..\\pages\\webConfiguration\\en\\index.vue' /* webpackChunkName: "pages_webConfiguration_en_index" */))
const _25dcb4ba = () => interopDefault(import('..\\pages\\webConfiguration\\zh\\index.vue' /* webpackChunkName: "pages_webConfiguration_zh_index" */))
const _1bde3dda = () => interopDefault(import('..\\pages\\agendaofConference\\en\\create.vue' /* webpackChunkName: "pages_agendaofConference_en_create" */))
const _05044ae1 = () => interopDefault(import('..\\pages\\agendaofConference\\en\\edit.vue' /* webpackChunkName: "pages_agendaofConference_en_edit" */))
const _42cebfc1 = () => interopDefault(import('..\\pages\\agendaofConference\\en\\vote.vue' /* webpackChunkName: "pages_agendaofConference_en_vote" */))
const _485434a4 = () => interopDefault(import('..\\pages\\agendaofConference\\type\\create.vue' /* webpackChunkName: "pages_agendaofConference_type_create" */))
const _64794eb2 = () => interopDefault(import('..\\pages\\agendaofConference\\type\\edit.vue' /* webpackChunkName: "pages_agendaofConference_type_edit" */))
const _3b9f77d0 = () => interopDefault(import('..\\pages\\agendaofConference\\zh\\create.vue' /* webpackChunkName: "pages_agendaofConference_zh_create" */))
const _293aab26 = () => interopDefault(import('..\\pages\\agendaofConference\\zh\\edit.vue' /* webpackChunkName: "pages_agendaofConference_zh_edit" */))
const _67052006 = () => interopDefault(import('..\\pages\\agendaofConference\\zh\\vote.vue' /* webpackChunkName: "pages_agendaofConference_zh_vote" */))
const _38072758 = () => interopDefault(import('..\\pages\\cloudEvents\\en\\create.vue' /* webpackChunkName: "pages_cloudEvents_en_create" */))
const _39a89b3c = () => interopDefault(import('..\\pages\\cloudEvents\\en\\edit.vue' /* webpackChunkName: "pages_cloudEvents_en_edit" */))
const _57c8614e = () => interopDefault(import('..\\pages\\cloudEvents\\zh\\create.vue' /* webpackChunkName: "pages_cloudEvents_zh_create" */))
const _076212a7 = () => interopDefault(import('..\\pages\\cloudEvents\\zh\\edit.vue' /* webpackChunkName: "pages_cloudEvents_zh_edit" */))
const _7df977c0 = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\en\\create.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_en_create" */))
const _dce6ae64 = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\en\\edit.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_en_edit" */))
const _6e18dac5 = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\zh\\create.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_zh_create" */))
const _9479edda = () => interopDefault(import('..\\pages\\cloudIntelligentExperience\\zh\\edit.vue' /* webpackChunkName: "pages_cloudIntelligentExperience_zh_edit" */))
const _db0d8502 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\en\\create.vue' /* webpackChunkName: "pages_cloudSeriesActivities_en_create" */))
const _4e70d24d = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\en\\edit.vue' /* webpackChunkName: "pages_cloudSeriesActivities_en_edit" */))
const _70172610 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\type\\create.vue' /* webpackChunkName: "pages_cloudSeriesActivities_type_create" */))
const _04e1ab1e = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\type\\edit.vue' /* webpackChunkName: "pages_cloudSeriesActivities_type_edit" */))
const _facebef8 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\zh\\create.vue' /* webpackChunkName: "pages_cloudSeriesActivities_zh_create" */))
const _72a73292 = () => interopDefault(import('..\\pages\\cloudSeriesActivities\\zh\\edit.vue' /* webpackChunkName: "pages_cloudSeriesActivities_zh_edit" */))
const _ee15776a = () => interopDefault(import('..\\pages\\conferenceGuests\\en\\create.vue' /* webpackChunkName: "pages_conferenceGuests_en_create" */))
const _71981c19 = () => interopDefault(import('..\\pages\\conferenceGuests\\en\\edit.vue' /* webpackChunkName: "pages_conferenceGuests_en_edit" */))
const _7914a750 = () => interopDefault(import('..\\pages\\conferenceGuests\\zh\\create.vue' /* webpackChunkName: "pages_conferenceGuests_zh_create" */))
const _d4630744 = () => interopDefault(import('..\\pages\\conferenceGuests\\zh\\edit.vue' /* webpackChunkName: "pages_conferenceGuests_zh_edit" */))
const _4e29a3b1 = () => interopDefault(import('..\\pages\\cooperativePartner\\en\\create.vue' /* webpackChunkName: "pages_cooperativePartner_en_create" */))
const _61edc602 = () => interopDefault(import('..\\pages\\cooperativePartner\\en\\edit.vue' /* webpackChunkName: "pages_cooperativePartner_en_edit" */))
const _0146c7c2 = () => interopDefault(import('..\\pages\\cooperativePartner\\type\\create.vue' /* webpackChunkName: "pages_cooperativePartner_type_create" */))
const _7edbdd60 = () => interopDefault(import('..\\pages\\cooperativePartner\\type\\edit.vue' /* webpackChunkName: "pages_cooperativePartner_type_edit" */))
const _3e4906b6 = () => interopDefault(import('..\\pages\\cooperativePartner\\zh\\create.vue' /* webpackChunkName: "pages_cooperativePartner_zh_create" */))
const _19810578 = () => interopDefault(import('..\\pages\\cooperativePartner\\zh\\edit.vue' /* webpackChunkName: "pages_cooperativePartner_zh_edit" */))
const _a632348c = () => interopDefault(import('..\\pages\\eventIntroduction\\en\\create.vue' /* webpackChunkName: "pages_eventIntroduction_en_create" */))
const _0f114d48 = () => interopDefault(import('..\\pages\\eventIntroduction\\en\\edit.vue' /* webpackChunkName: "pages_eventIntroduction_en_edit" */))
const _c5f36e82 = () => interopDefault(import('..\\pages\\eventIntroduction\\zh\\create.vue' /* webpackChunkName: "pages_eventIntroduction_zh_create" */))
const _3347ad8d = () => interopDefault(import('..\\pages\\eventIntroduction\\zh\\edit.vue' /* webpackChunkName: "pages_eventIntroduction_zh_edit" */))
const _155e0ce1 = () => interopDefault(import('..\\pages\\excellentCases\\en\\create.vue' /* webpackChunkName: "pages_excellentCases_en_create" */))
const _6cb3dba2 = () => interopDefault(import('..\\pages\\excellentCases\\en\\edit.vue' /* webpackChunkName: "pages_excellentCases_en_edit" */))
const _057d6fe6 = () => interopDefault(import('..\\pages\\excellentCases\\zh\\create.vue' /* webpackChunkName: "pages_excellentCases_zh_create" */))
const _24471b18 = () => interopDefault(import('..\\pages\\excellentCases\\zh\\edit.vue' /* webpackChunkName: "pages_excellentCases_zh_edit" */))
const _5d91de40 = () => interopDefault(import('..\\pages\\homoSapiens\\en\\create.vue' /* webpackChunkName: "pages_homoSapiens_en_create" */))
const _510caf4e = () => interopDefault(import('..\\pages\\homoSapiens\\en\\edit.vue' /* webpackChunkName: "pages_homoSapiens_en_edit" */))
const _4db14145 = () => interopDefault(import('..\\pages\\homoSapiens\\zh\\create.vue' /* webpackChunkName: "pages_homoSapiens_zh_create" */))
const _75430f93 = () => interopDefault(import('..\\pages\\homoSapiens\\zh\\edit.vue' /* webpackChunkName: "pages_homoSapiens_zh_edit" */))
const _13a9175c = () => interopDefault(import('..\\pages\\hotelGuide\\en\\create.vue' /* webpackChunkName: "pages_hotelGuide_en_create" */))
const _3e977f6a = () => interopDefault(import('..\\pages\\hotelGuide\\en\\edit.vue' /* webpackChunkName: "pages_hotelGuide_en_edit" */))
const _03c87a61 = () => interopDefault(import('..\\pages\\hotelGuide\\zh\\create.vue' /* webpackChunkName: "pages_hotelGuide_zh_create" */))
const _62cddfaf = () => interopDefault(import('..\\pages\\hotelGuide\\zh\\edit.vue' /* webpackChunkName: "pages_hotelGuide_zh_edit" */))
const _e1d855ae = () => interopDefault(import('..\\pages\\mediaInvitationCode\\code\\detail.vue' /* webpackChunkName: "pages_mediaInvitationCode_code_detail" */))
const _2e4c4a7f = () => interopDefault(import('..\\pages\\newsInformation\\en\\create.vue' /* webpackChunkName: "pages_newsInformation_en_create" */))
const _24b9c166 = () => interopDefault(import('..\\pages\\newsInformation\\en\\edit.vue' /* webpackChunkName: "pages_newsInformation_en_edit" */))
const _de521f70 = () => interopDefault(import('..\\pages\\newsInformation\\hoten\\create.vue' /* webpackChunkName: "pages_newsInformation_hoten_create" */))
const _8e02b954 = () => interopDefault(import('..\\pages\\newsInformation\\hoten\\edit.vue' /* webpackChunkName: "pages_newsInformation_hoten_edit" */))
const _fe135966 = () => interopDefault(import('..\\pages\\newsInformation\\hotzh\\create.vue' /* webpackChunkName: "pages_newsInformation_hotzh_create" */))
const _4595f8ca = () => interopDefault(import('..\\pages\\newsInformation\\hotzh\\edit.vue' /* webpackChunkName: "pages_newsInformation_hotzh_edit" */))
const _635af310 = () => interopDefault(import('..\\pages\\newsInformation\\type\\create.vue' /* webpackChunkName: "pages_newsInformation_type_create" */))
const _be968fc4 = () => interopDefault(import('..\\pages\\newsInformation\\type\\edit.vue' /* webpackChunkName: "pages_newsInformation_type_edit" */))
const _1e6bad84 = () => interopDefault(import('..\\pages\\newsInformation\\zh\\create.vue' /* webpackChunkName: "pages_newsInformation_zh_create" */))
const _11d97f92 = () => interopDefault(import('..\\pages\\newsInformation\\zh\\edit.vue' /* webpackChunkName: "pages_newsInformation_zh_edit" */))
const _5d6b7192 = () => interopDefault(import('..\\pages\\pcConfiguration\\zh\\index2.vue' /* webpackChunkName: "pages_pcConfiguration_zh_index2" */))
const _316414d4 = () => interopDefault(import('..\\pages\\questionnaire\\enterprise\\detail.vue' /* webpackChunkName: "pages_questionnaire_enterprise_detail" */))
const _1d26f4e6 = () => interopDefault(import('..\\pages\\questionnaire\\naire\\detail.vue' /* webpackChunkName: "pages_questionnaire_naire_detail" */))
const _5b5c6bfa = () => interopDefault(import('..\\pages\\registeredUsers\\user\\detail.vue' /* webpackChunkName: "pages_registeredUsers_user_detail" */))
const _2ed950b7 = () => interopDefault(import('..\\pages\\registrationAgreement\\en\\create.vue' /* webpackChunkName: "pages_registrationAgreement_en_create" */))
const _4bac5385 = () => interopDefault(import('..\\pages\\registrationAgreement\\en\\edit.vue' /* webpackChunkName: "pages_registrationAgreement_en_edit" */))
const _1ef8b3bc = () => interopDefault(import('..\\pages\\registrationAgreement\\zh\\create.vue' /* webpackChunkName: "pages_registrationAgreement_zh_create" */))
const _6fe2b3ca = () => interopDefault(import('..\\pages\\registrationAgreement\\zh\\edit.vue' /* webpackChunkName: "pages_registrationAgreement_zh_edit" */))
const _9271ad42 = () => interopDefault(import('..\\pages\\scheduleGlance\\en\\create.vue' /* webpackChunkName: "pages_scheduleGlance_en_create" */))
const _3b08362d = () => interopDefault(import('..\\pages\\scheduleGlance\\en\\edit.vue' /* webpackChunkName: "pages_scheduleGlance_en_edit" */))
const _b232e738 = () => interopDefault(import('..\\pages\\scheduleGlance\\zh\\create.vue' /* webpackChunkName: "pages_scheduleGlance_zh_create" */))
const _5f3e9672 = () => interopDefault(import('..\\pages\\scheduleGlance\\zh\\edit.vue' /* webpackChunkName: "pages_scheduleGlance_zh_edit" */))
const _705d6f93 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'hash',
  base: decodeURI('/cms-fe/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/account/login",
    component: _6e19ab77,
    name: "account-login"
  }, {
    path: "/agendaofConference/en",
    component: _458669ea,
    name: "agendaofConference-en"
  }, {
    path: "/agendaofConference/type",
    component: _6c68415a,
    name: "agendaofConference-type"
  }, {
    path: "/agendaofConference/zh",
    component: _3fd27366,
    name: "agendaofConference-zh"
  }, {
    path: "/cloudEvents/en",
    component: _77fb58ac,
    name: "cloudEvents-en"
  }, {
    path: "/cloudEvents/zh",
    component: _2697fc05,
    name: "cloudEvents-zh"
  }, {
    path: "/cloudIntelligentExperience/en",
    component: _3c7faa84,
    name: "cloudIntelligentExperience-en"
  }, {
    path: "/cloudIntelligentExperience/zh",
    component: _4455d319,
    name: "cloudIntelligentExperience-zh"
  }, {
    path: "/cloudSeriesActivities/en",
    component: _7d3d9dc2,
    name: "cloudSeriesActivities-en"
  }, {
    path: "/cloudSeriesActivities/type",
    component: _4de91b24,
    name: "cloudSeriesActivities-type"
  }, {
    path: "/cloudSeriesActivities/zh",
    component: _23f6d97a,
    name: "cloudSeriesActivities-zh"
  }, {
    path: "/conferenceGuests/en",
    component: _032320d3,
    name: "conferenceGuests-en"
  }, {
    path: "/conferenceGuests/zh",
    component: _65b8c92e,
    name: "conferenceGuests-zh"
  }, {
    path: "/cooperativePartner/en",
    component: _53d23cad,
    name: "cooperativePartner-en"
  }, {
    path: "/cooperativePartner/type",
    component: _d9305b08,
    name: "cooperativePartner-type"
  }, {
    path: "/cooperativePartner/zh",
    component: _933035f0,
    name: "cooperativePartner-zh"
  }, {
    path: "/error/404",
    component: _610c4fe3,
    name: "error-404"
  }, {
    path: "/error/500",
    component: _24238406,
    name: "error-500"
  }, {
    path: "/eventIntroduction/en",
    component: _14d01584,
    name: "eventIntroduction-en"
  }, {
    path: "/eventIntroduction/zh",
    component: _7765bddf,
    name: "eventIntroduction-zh"
  }, {
    path: "/excellentCases/en",
    component: _a6582506,
    name: "excellentCases-en"
  }, {
    path: "/excellentCases/zh",
    component: _0f6995d8,
    name: "excellentCases-zh"
  }, {
    path: "/greatDemo/showConfig",
    component: _1757fa12,
    name: "greatDemo-showConfig"
  }, {
    path: "/home/list",
    component: _79769e4c,
    name: "home-list"
  }, {
    path: "/homoSapiens/en",
    component: _1240f43e,
    name: "homoSapiens-en"
  }, {
    path: "/homoSapiens/zh",
    component: _74d69c99,
    name: "homoSapiens-zh"
  }, {
    path: "/hotelGuide/en",
    component: _53dfb0bc,
    name: "hotelGuide-en"
  }, {
    path: "/hotelGuide/zh",
    component: _38a5cffd,
    name: "hotelGuide-zh"
  }, {
    path: "/material/enclosure",
    component: _0dbdee16,
    name: "material-enclosure"
  }, {
    path: "/material/file",
    component: _93bbcd60,
    name: "material-file"
  }, {
    path: "/material/music",
    component: _068c42fa,
    name: "material-music"
  }, {
    path: "/material/picture",
    component: _9f8ec2ec,
    name: "material-picture"
  }, {
    path: "/material/video",
    component: _1ada866d,
    name: "material-video"
  }, {
    path: "/mediaInvitationCode/code",
    component: _7435a0ac,
    name: "mediaInvitationCode-code"
  }, {
    path: "/newsInformation/en",
    component: _0878841f,
    name: "newsInformation-en"
  }, {
    path: "/newsInformation/hoten",
    component: _aee4fd94,
    name: "newsInformation-hoten"
  }, {
    path: "/newsInformation/hotzh",
    component: _0b232991,
    name: "newsInformation-hotzh"
  }, {
    path: "/newsInformation/type",
    component: _90cbf524,
    name: "newsInformation-type"
  }, {
    path: "/newsInformation/zh",
    component: _6b0e2c7a,
    name: "newsInformation-zh"
  }, {
    path: "/pcConfiguration/en",
    component: _7f64c975,
    name: "pcConfiguration-en"
  }, {
    path: "/pcConfiguration/zh",
    component: _3c0b1c60,
    name: "pcConfiguration-zh"
  }, {
    path: "/questionnaire/enterprise",
    component: _4cdecd9d,
    name: "questionnaire-enterprise"
  }, {
    path: "/questionnaire/naire",
    component: _397eb766,
    name: "questionnaire-naire"
  }, {
    path: "/registeredUsers/user",
    component: _b1ef90e0,
    name: "registeredUsers-user"
  }, {
    path: "/registrationAgreement/en",
    component: _6b95d6e7,
    name: "registrationAgreement-en"
  }, {
    path: "/registrationAgreement/zh",
    component: _63a9017c,
    name: "registrationAgreement-zh"
  }, {
    path: "/scheduleGlance/en",
    component: _67b6493f,
    name: "scheduleGlance-en"
  }, {
    path: "/scheduleGlance/zh",
    component: _6b681ccc,
    name: "scheduleGlance-zh"
  }, {
    path: "/webConfiguration/en",
    component: _eb080570,
    name: "webConfiguration-en"
  }, {
    path: "/webConfiguration/zh",
    component: _25dcb4ba,
    name: "webConfiguration-zh"
  }, {
    path: "/agendaofConference/en/create",
    component: _1bde3dda,
    name: "agendaofConference-en-create"
  }, {
    path: "/agendaofConference/en/edit",
    component: _05044ae1,
    name: "agendaofConference-en-edit"
  }, {
    path: "/agendaofConference/en/vote",
    component: _42cebfc1,
    name: "agendaofConference-en-vote"
  }, {
    path: "/agendaofConference/type/create",
    component: _485434a4,
    name: "agendaofConference-type-create"
  }, {
    path: "/agendaofConference/type/edit",
    component: _64794eb2,
    name: "agendaofConference-type-edit"
  }, {
    path: "/agendaofConference/zh/create",
    component: _3b9f77d0,
    name: "agendaofConference-zh-create"
  }, {
    path: "/agendaofConference/zh/edit",
    component: _293aab26,
    name: "agendaofConference-zh-edit"
  }, {
    path: "/agendaofConference/zh/vote",
    component: _67052006,
    name: "agendaofConference-zh-vote"
  }, {
    path: "/cloudEvents/en/create",
    component: _38072758,
    name: "cloudEvents-en-create"
  }, {
    path: "/cloudEvents/en/edit",
    component: _39a89b3c,
    name: "cloudEvents-en-edit"
  }, {
    path: "/cloudEvents/zh/create",
    component: _57c8614e,
    name: "cloudEvents-zh-create"
  }, {
    path: "/cloudEvents/zh/edit",
    component: _076212a7,
    name: "cloudEvents-zh-edit"
  }, {
    path: "/cloudIntelligentExperience/en/create",
    component: _7df977c0,
    name: "cloudIntelligentExperience-en-create"
  }, {
    path: "/cloudIntelligentExperience/en/edit",
    component: _dce6ae64,
    name: "cloudIntelligentExperience-en-edit"
  }, {
    path: "/cloudIntelligentExperience/zh/create",
    component: _6e18dac5,
    name: "cloudIntelligentExperience-zh-create"
  }, {
    path: "/cloudIntelligentExperience/zh/edit",
    component: _9479edda,
    name: "cloudIntelligentExperience-zh-edit"
  }, {
    path: "/cloudSeriesActivities/en/create",
    component: _db0d8502,
    name: "cloudSeriesActivities-en-create"
  }, {
    path: "/cloudSeriesActivities/en/edit",
    component: _4e70d24d,
    name: "cloudSeriesActivities-en-edit"
  }, {
    path: "/cloudSeriesActivities/type/create",
    component: _70172610,
    name: "cloudSeriesActivities-type-create"
  }, {
    path: "/cloudSeriesActivities/type/edit",
    component: _04e1ab1e,
    name: "cloudSeriesActivities-type-edit"
  }, {
    path: "/cloudSeriesActivities/zh/create",
    component: _facebef8,
    name: "cloudSeriesActivities-zh-create"
  }, {
    path: "/cloudSeriesActivities/zh/edit",
    component: _72a73292,
    name: "cloudSeriesActivities-zh-edit"
  }, {
    path: "/conferenceGuests/en/create",
    component: _ee15776a,
    name: "conferenceGuests-en-create"
  }, {
    path: "/conferenceGuests/en/edit",
    component: _71981c19,
    name: "conferenceGuests-en-edit"
  }, {
    path: "/conferenceGuests/zh/create",
    component: _7914a750,
    name: "conferenceGuests-zh-create"
  }, {
    path: "/conferenceGuests/zh/edit",
    component: _d4630744,
    name: "conferenceGuests-zh-edit"
  }, {
    path: "/cooperativePartner/en/create",
    component: _4e29a3b1,
    name: "cooperativePartner-en-create"
  }, {
    path: "/cooperativePartner/en/edit",
    component: _61edc602,
    name: "cooperativePartner-en-edit"
  }, {
    path: "/cooperativePartner/type/create",
    component: _0146c7c2,
    name: "cooperativePartner-type-create"
  }, {
    path: "/cooperativePartner/type/edit",
    component: _7edbdd60,
    name: "cooperativePartner-type-edit"
  }, {
    path: "/cooperativePartner/zh/create",
    component: _3e4906b6,
    name: "cooperativePartner-zh-create"
  }, {
    path: "/cooperativePartner/zh/edit",
    component: _19810578,
    name: "cooperativePartner-zh-edit"
  }, {
    path: "/eventIntroduction/en/create",
    component: _a632348c,
    name: "eventIntroduction-en-create"
  }, {
    path: "/eventIntroduction/en/edit",
    component: _0f114d48,
    name: "eventIntroduction-en-edit"
  }, {
    path: "/eventIntroduction/zh/create",
    component: _c5f36e82,
    name: "eventIntroduction-zh-create"
  }, {
    path: "/eventIntroduction/zh/edit",
    component: _3347ad8d,
    name: "eventIntroduction-zh-edit"
  }, {
    path: "/excellentCases/en/create",
    component: _155e0ce1,
    name: "excellentCases-en-create"
  }, {
    path: "/excellentCases/en/edit",
    component: _6cb3dba2,
    name: "excellentCases-en-edit"
  }, {
    path: "/excellentCases/zh/create",
    component: _057d6fe6,
    name: "excellentCases-zh-create"
  }, {
    path: "/excellentCases/zh/edit",
    component: _24471b18,
    name: "excellentCases-zh-edit"
  }, {
    path: "/homoSapiens/en/create",
    component: _5d91de40,
    name: "homoSapiens-en-create"
  }, {
    path: "/homoSapiens/en/edit",
    component: _510caf4e,
    name: "homoSapiens-en-edit"
  }, {
    path: "/homoSapiens/zh/create",
    component: _4db14145,
    name: "homoSapiens-zh-create"
  }, {
    path: "/homoSapiens/zh/edit",
    component: _75430f93,
    name: "homoSapiens-zh-edit"
  }, {
    path: "/hotelGuide/en/create",
    component: _13a9175c,
    name: "hotelGuide-en-create"
  }, {
    path: "/hotelGuide/en/edit",
    component: _3e977f6a,
    name: "hotelGuide-en-edit"
  }, {
    path: "/hotelGuide/zh/create",
    component: _03c87a61,
    name: "hotelGuide-zh-create"
  }, {
    path: "/hotelGuide/zh/edit",
    component: _62cddfaf,
    name: "hotelGuide-zh-edit"
  }, {
    path: "/mediaInvitationCode/code/detail",
    component: _e1d855ae,
    name: "mediaInvitationCode-code-detail"
  }, {
    path: "/newsInformation/en/create",
    component: _2e4c4a7f,
    name: "newsInformation-en-create"
  }, {
    path: "/newsInformation/en/edit",
    component: _24b9c166,
    name: "newsInformation-en-edit"
  }, {
    path: "/newsInformation/hoten/create",
    component: _de521f70,
    name: "newsInformation-hoten-create"
  }, {
    path: "/newsInformation/hoten/edit",
    component: _8e02b954,
    name: "newsInformation-hoten-edit"
  }, {
    path: "/newsInformation/hotzh/create",
    component: _fe135966,
    name: "newsInformation-hotzh-create"
  }, {
    path: "/newsInformation/hotzh/edit",
    component: _4595f8ca,
    name: "newsInformation-hotzh-edit"
  }, {
    path: "/newsInformation/type/create",
    component: _635af310,
    name: "newsInformation-type-create"
  }, {
    path: "/newsInformation/type/edit",
    component: _be968fc4,
    name: "newsInformation-type-edit"
  }, {
    path: "/newsInformation/zh/create",
    component: _1e6bad84,
    name: "newsInformation-zh-create"
  }, {
    path: "/newsInformation/zh/edit",
    component: _11d97f92,
    name: "newsInformation-zh-edit"
  }, {
    path: "/pcConfiguration/zh/index2",
    component: _5d6b7192,
    name: "pcConfiguration-zh-index2"
  }, {
    path: "/questionnaire/enterprise/detail",
    component: _316414d4,
    name: "questionnaire-enterprise-detail"
  }, {
    path: "/questionnaire/naire/detail",
    component: _1d26f4e6,
    name: "questionnaire-naire-detail"
  }, {
    path: "/registeredUsers/user/detail",
    component: _5b5c6bfa,
    name: "registeredUsers-user-detail"
  }, {
    path: "/registrationAgreement/en/create",
    component: _2ed950b7,
    name: "registrationAgreement-en-create"
  }, {
    path: "/registrationAgreement/en/edit",
    component: _4bac5385,
    name: "registrationAgreement-en-edit"
  }, {
    path: "/registrationAgreement/zh/create",
    component: _1ef8b3bc,
    name: "registrationAgreement-zh-create"
  }, {
    path: "/registrationAgreement/zh/edit",
    component: _6fe2b3ca,
    name: "registrationAgreement-zh-edit"
  }, {
    path: "/scheduleGlance/en/create",
    component: _9271ad42,
    name: "scheduleGlance-en-create"
  }, {
    path: "/scheduleGlance/en/edit",
    component: _3b08362d,
    name: "scheduleGlance-en-edit"
  }, {
    path: "/scheduleGlance/zh/create",
    component: _b232e738,
    name: "scheduleGlance-zh-create"
  }, {
    path: "/scheduleGlance/zh/edit",
    component: _5f3e9672,
    name: "scheduleGlance-zh-edit"
  }, {
    path: "/",
    component: _705d6f93,
    name: "index"
  }, {
    path: "*",
    component: _610c4fe3,
    name: "custom"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
