# pages 目录

####  管理员页面 pages/admin

#### `/admin/user` 成员管理页
- 入录使用wau4框架成员管理的组织架构
  - `/admin/user/list` 成员管理列表
  - `/admin/user/list/department` 成员管理的组织架构(独立划分利于组织架构的后期维护)
#### `/admin/auth` 权限管理页
- 使用wau4框架成员的管理权限
  - `/admin/auth/list` 部门成员权限的划分
  - `/admin/auth/role` 部门成员角色的划分

####  文章管理页面 pages/article
#### `/article/list` 展示文章列表
  - `/article/list/columns` 设计表格字段
  - `/article/list/form` 文章筛选
  - `/article/list/list` 文章列表
  - `/article/list/modal-create` 文章的创建
- `/article/info` 展示文章详情
- `/article/edit` 文章编辑页面
  - `/article/edit/ruleMix` 文章创建时校验规则

#### 编辑器页面 pages/editor
#### `/editor/index` 代码编辑器

#### iframe页面 pages/iframe
#### `/iframe/inner` 要嵌入的页面
#### `/iframe/main` 嵌入方式



####  其他管理页面 与 测试管理页面 通过字典生成（结构同文章管理一致）

#### WAU开发工具页面 pages/wau 
#### `/wau/user` 用户列表页
- `/wau/user/list` 展示用户列表
  - `/article/list/columns` 设计表格字段
  - `/article/list/form` 用户筛选
  - `/article/list/list` 用户列表
  - `/article/list/modal-create` 创建用户
- `/article/info` 展示用户详细信息
- `/article/edit` 编辑用户信息
  - `/article/edit/ruleMix` 创建用户字段校验规则
#### `/wau/dict`字典列表页
- `/dict/list` 展示字典列表
  - `/dict/list/columns` 设计表格字段
  - `/dict/list/form` 字典筛选
  - `/dict/list/list` 字典列表
  - `/dict/list/modal-create` 创建字典
- `/article/info` 展示字典详细信息
- `/article/edit` 编辑字典
  - `/article/edit/dict-table` 字典table
  - `/article/edit/ruleMix` 编辑字典时字段校验规则