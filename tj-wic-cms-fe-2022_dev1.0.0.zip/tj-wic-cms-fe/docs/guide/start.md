# 开发指引

## 安装 cli

```bash
npm i -g @wii/cli
```

## 创建项目

```bash
wii create <项目名称>
```

- 请选择要创建的项目类型

> wii-wau4

- 创建完成选择安装方式:

  - `npm`

  `tnpm`

  `yarn`

- 执行完成，你可以进行开发了！

```
npm run dev
```

运行完成
