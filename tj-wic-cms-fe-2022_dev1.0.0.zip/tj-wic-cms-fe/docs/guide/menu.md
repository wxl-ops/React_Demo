# 导航栏模块

在 menu/modules 文件夹下创建导航，例如 admin.js

```bash
export default {
  path: '/admin',
  title: '管理员',
  icon: 'md-list',
  children: [
    {
      path: '/admin/user/list',//根据pages创建的文件路径
      title: '成员管理'
    },
    {
      path: '/admin/auth/list',
      title: '权限管理'
      //   auth: ['hidden']
    }
  ]
}
```

在 menu/sider.js 中以数组形式抛出

```bash
import admin from './modules/admin'
export default [admin] //抛出顺序与展示顺序一致
```

在布局中的基础组件中使用 layouts/base/menu 下的根组件中使用您写的导航模板

```bash
import menus from '@/menu/sider'
```
