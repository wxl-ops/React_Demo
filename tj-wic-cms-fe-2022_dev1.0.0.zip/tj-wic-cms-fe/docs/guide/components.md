# 组件

## 抛出后全局使用

在 plugins 下创建 plugins.js 文件，将抛出的所有组件注册全局

```bash
import components from '@/components'
export default {
  install(Vue, options) {
    Object.keys(components).forEach((key) => {
      Vue.component(key, components[key])
    })
}
```

在 plugins/index.js 挂载

```bash
import plugins from './plugins'
Vue.use(plugins)
```

在 nuxt.config.js 配置

```bash
 plugins: ['@/plugins/index']
```

## 使用

```bash
export default {
  name: 'WDeleteModal',//直接使用组件抛出的name名
  }
```
