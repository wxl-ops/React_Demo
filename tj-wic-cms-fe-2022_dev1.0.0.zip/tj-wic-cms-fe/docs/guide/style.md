# Style 目录

- style/theme/index.less 自定义主题，可重写 iview 中的样式

```bash
// @primary-color: #358ccc;
@layout-header-background: #191a23;
@menu-dark-title: #191a23;
@menu-dark-active-bg: lighten(#191a23, 20%);
```

- style/base.less 放置基础样式
- style/index.css 放置 iview 样式
- style/index.less 放置全局样式

在 nuxt.config.js 中配置：

```bash
 css: ['@/styles/theme/index.less', '@/styles/index.less'],
```
