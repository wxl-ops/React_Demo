# nuxt.config.js 目录

`在 nuxt.config.js 中设置进度条颜色`

```bash
 loading: { color: '#000' }
```

`在 nuxt.config.js 中配置全局 css`

```bash
css: ['@/styles/theme/index.less', '@/styles/index.less'],
```

`在 nuxt.config.js 中配置跨域资源请求`

```bash
 modules: [
    '@nuxtjs/axios',
    '@nuxtjs/proxy'
  ],
  axios: {
    proxy: true
  },
  proxy: {
    '/api': {
      target: 'http://example.com',//代理路径

    }
  }
```
