# Store 目录

store/index.js

```bash
//存放状态
export const state = () => ({
  statusList: []
})

//通过mutations修改状态
export const mutations = {
  setStatusList(state, statusList) {
    state.statusList = statusList
  }
}

//异步获取数据
export const actions = {
  async getStatusList({ commit, state, dispatch }) {
    if (isEmpty(state.statusList)) {
      const { list = [] } = await api.list({
        offset: 0,
        count: -1
      })
      const statusList = list.map(({ status_id, status_name }) => {
        return {
          label: status_name,
          value: status_id
        }
      })
      //触发mutations修改数据
      commit('setStatusList', statusList)
    }
  }
}
```
