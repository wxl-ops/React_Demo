# 自动生成

## 开发者工具

- 启动服务后，点击 WAU 开发者工具

![list](http://cdn.qinmudi.cn/rocket/rocket-list.png)

## 创建字典

- 点击右上角的创建字典，在表单中把对应的数据填写进去

![edit](http://cdn.qinmudi.cn/rocket/rocket-edit.png)

### 字段说明

| 字段名称 | 说明                                                                                         |  类型  | 默认值 |
| -------- | :------------------------------------------------------------------------------------------- | :----: | :----: |
| 字典名称 | 模块名称，用做侧边栏名称                                                                     | String |   -    |
| API 前缀 | 接口前缀，如：/api                                                                           | String |  /api  |
| 模块名称 | 模块名，通常作为接口和页面访问路径，如模块`user`， 页面路径：/user/list 接口：/api/user/list | String |   -    |
| 创建人   | 谁创建的，目前没有其它用户                                                                   | String |   -    |

### 数据字典说明

新增的每一个字段都可以作为页面的元素进行使用，具体解释如下：

- `控件类型`决定表单页该字段使用的控件是什么
- `控件宽度`决定列表页该字段占用的宽度是多少
- `表单使用、详情使用、列表使用`分别来控制是否在该页面使用该字段
- `是否查询`选中会在列表页生成选择条件
- `是否校验`选中会在表单页生成校验规则
- `占位文字`相当于控件的 placeholder

## 生成代码

- 进入到你工程的`src`目录，执行以下命令，id 参数可以查看列表的`字典编号`

```bash
wii4 cloud -i [id]
```

- 在你的工程下会生成如下文件：
- `api/${model_name}.js`
- `pages/${model_name}/edit`
- `pages/${model_name}/list`
- `pages/${model_name}/info`
- `menu/modules/${model_name}.js`

## 配置菜单

- 文件生成好了以后，需要去`menu/sider.js`中把你刚才生成的菜单挂载到侧边栏上

```js
// 导入对应的菜单
import model from './modules/model'

// 导出该菜单模块
export default [home, article, `model`, log]
```
