# 目录结构

## 接口目录

- 接口目录<font color=red >**api**</font>用于组织编译的接口放在 api 中，处于安全性考虑建议使用 post 请求.

## assets 目录

- 资源目录<font color=red >**assets**</font>用于组织未编译的静态资源如 LESS 或 JavaScript

## components 目录

- 组件目录
  <font color=red >**components**</font>用于组织放置公用组件，利于后期维护升级，组件创建完成后在 components/index.js 中集体抛出。

  [<font color=skyblue >**查看关于 components 更多信息**</font>](./components.md)

## filters 目录

- <font color=red >**filters**</font>目录将后端传来的数据'过滤'后放在网页上。

  [<font color=skyblue >**查看关于 filters 更多信息**</font>](./filters.md)

## layouts 目录

- 布局目录 [<font color=red >**layouts**</font>](./layouts.md) 用于组织应用的基础组件和布局组件。

  [<font color=skyblue >**查看关于 layouts 更多信息**</font>](./layouts.md)

## libs 目录

- <font color=red >**libs**</font> 目录用于存储 iframe 的使用与公用部分(util)

## menu 目录

- <font color=red >**menu**</font> 目录用于组织编译左侧导航和头部导航。

  [<font color=skyblue >**查看关于 menu 更多信息**</font>](./menu.md)

## middleware 目录

- 布局目录 <font color=red >**middleware**</font> 目录用于存放应用的中间件。
  <!--
    [<font color=skyblue >**查看关于中间件更多信息**</font>](./middleware.md) -->

## mixins 目录

- <font color=red >**mixins**</font>目录用于分发组件中可复用功能。

  [<font color=skyblue >**查看关于 mixins 更多信息**</font>](./mixins.md)

## pages 目录

- 页面目录 <font color=red >**pages**</font> 用于组织应用的路由及视图。该目录下的所有.vue 文件会自动生成对应的路由配置。
 
  [<font color=skyblue >**查看关于pages更多信息**</font>](./pages.md)
## plugins 目录

- 插件目录 <font color=red >**plugins**</font> 用于组织那些需要在 根 vue.js 应用 实例化之前需要运行的 Javascript 插件。

  [<font color=skyblue >**查看关于插件更多信息**</font>](./plugins.md)

## static 文件目录

- 静态文件目录 <font color=red >**static**</font> 用于存放应用的静态文件

## Store 目录

- <font color=red >**Store**</font>目录用于组织应用的状态仓库，在 store 目录下创建 index.js 文件可激活这些配置，还可根据需求创建相关文件夹，如 store/menu/menu.js

  [<font color=skyblue >**查看关于 Store 更多信息**</font>](./store.md)

## Style 目录

- <font color=red >**Style**</font>目录中放置着全局样式。

  [<font color=skyblue >**查看关于 Style 更多信息**</font>](./style.md)

## nuxt.config.js 文件

- <font color=red >**nuxt.config.js**</font>文件用于组织应用的个性化配置，以便覆盖默认配置。(若无额外配置，该文件不能被重命名)

  [<font color=skyblue >**查看关于 nuxt.config.js 更多信息**</font>](./nuxt.md)

## package.json 文件

- <font color=red >**package.json**</font>文件用于描述应用的依赖关系和对外暴露的脚本接口。(该文件不能被重命名)

## 别名

| 别名                                                   | 目录   |
| ------------------------------------------------------ | ------ |
| <font color=red >~</font>或<font color=red >@</font>   | srcDir |
| <font color=red >~~</font>或<font color=red >@@</font> | srcDir |

#### 更多问题可访问 https://www.nuxtjs.cn/faq
