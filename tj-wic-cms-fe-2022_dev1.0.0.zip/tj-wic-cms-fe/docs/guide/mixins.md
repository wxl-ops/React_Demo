# mixins 目录

在 mixins 下创建 demo.js

```bash
import { mapState, mapActions } from 'vuex'

export default {
  mounted() {
    this.getStatusList()
  },
  computed: {
    ...mapState('demo/status', ['statusList'])
  },
  methods: {
    ...mapActions('demo/status', ['getStatusList'])
  }
}
```

在 pages/list/from.vue 中

```bash
import demoMix from '@/mixins/demo'
export default {
  mixins: [demoMix] //从中获取statusList
  }
```

#### 使用

```bash
<div
    v-for="item in statusList"
    :key="item.value"
    >{{ item.label }}
</div>
```

### `注意mixins/global.js，不是全局暴露的功能不要在此文件写入`

直接使用全局功能在 plugins/index.js 引入 global 文件

```bash
import globalMix from '@/mixins/global'
Vue.mixin(globalMix)
```

nuxt.config.js 中配置

```bash
 plugins: ['@/plugins/index']
```
