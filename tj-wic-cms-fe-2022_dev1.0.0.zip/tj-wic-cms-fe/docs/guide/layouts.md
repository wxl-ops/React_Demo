# 布局

## 默认布局

可通过添加 layouts/default.vue 文件使用默认布局。

- `提示：别忘了在布局文件中添加<nuxt/>组件用于显示页面主体内容`

  默认布局的源码如下:

```
<template>
  <nuxt/>
</template>
```

## 自定义布局

layouts 目录中的每个文件都将创建一个可通过页面组件中的 layout 属性访问的自定义布局

例如创建一个我的书架布局 layouts/bookshelf.vue;

```
<template>
  <div>我的书架头部</div>
  <nuxt/>
</template>
```

然后我们告诉页面(即 pages/my.vue)使用您自定义布局:

```
<template>
  <!--Your template  -->
  <nuxt/>
</template>
<script>
  export default{
    layout:'bookshelf'
  }
</script>
```
