# filters

## 例如将后端传来的时间进行处理

- 在 filters 下创建 date.js:

```bash
import dayjs from 'dayjs'

export default {
  date_format: (date, setting = 'YYYY-MM-DD HH:mm:ss') => {
    return dayjs(date).format(setting)
  }
}
```

在 filters/index.js 根目录下抛出，注册至全局使用

```bash
import date from './date'

export default {
  ...date
}
```

在 plugins/index.js 挂载

```bash
import filters from '@/filters/index'
export default {
    Object.keys(filters).forEach((key) => {
      Vue.filter(key, filters[key])
    })
}
```

在 plugins/index.js 挂载

```bash
import plugins from './plugins'
Vue.use(plugins)
```

在 nuxt.config.js 配置

```bash
 plugins: ['@/plugins/index']
```
