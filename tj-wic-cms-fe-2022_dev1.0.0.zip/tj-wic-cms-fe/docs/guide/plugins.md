# 插件

## 将 api 文件下的接口挂载在全局上

在 plugins/api/service.js 中引入：

```bash
import article from '@/api/article'
export default {
  article
}
```

在 plugins/api/index.js 中引入 service 挂载全局

```bash
import services from './service'

export default {
  install(Vue) {
    Vue.prototype.$api = services
  }
}
```

### 使用

```bash
   mounted() {
    this.$api.article.list().then((res)=>{
      console.log(res)
    })
  }

```
