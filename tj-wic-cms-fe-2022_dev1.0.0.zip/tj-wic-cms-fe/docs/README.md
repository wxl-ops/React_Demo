---
home: true
heroImage: /rocket.png
actionText: 即刻开始 →
actionLink: /guide/introduce
footer: MIT Licensed | Copyright © 2020-present rocket-team
---

<div style="text-align: center">
  <Bit/>
</div>

<div class="features">
  <div class="feature">
    <h2>上手简单</h2>
    <p>通过简单的配置可以快速实现系统的开发，而无需对前端有深入的了解。</p>
  </div>
  <div class="feature">
    <h2>高扩展性</h2>
    <p>wau4集成了很多内置能力，如权限控制、状态管理、内置通用逻辑。</p>
  </div>
  <div class="feature">
    <h2>完整生态</h2>
    <p>提供了从项目创建、页面生成、qci、stke部署等能力，只需简单配置即可。</p>
  </div>
</div>
