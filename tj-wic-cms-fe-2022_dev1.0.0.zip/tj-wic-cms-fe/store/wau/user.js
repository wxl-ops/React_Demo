/* eslint-disable no-async-promise-executor */
// import api from '@/api/account'

export const state = () => ({
  info: {}
})

export const mutations = {
  setInfo(state, info) {
    state.info = info
  }
}

export const actions = {
  /*
  load({ commit, state, dispatch }) {
    return new Promise(async (resolve) => {
      const { data = {} } = await api.info()
      commit('setInfo', data)
      resolve()
    })
  }
  */
}
