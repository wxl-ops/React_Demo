export const state = () => ({
  crumb: {
    menu: {},
    subMenu: {},
    subChildrenMenu: {}
  }
})

export const mutations = {
  changeCrumb(state, crumb) {
    state.crumb = crumb
  },
  changeHelpTitle(state, value) {
    state.crumb.subChildrenMenu = value
  }
}
