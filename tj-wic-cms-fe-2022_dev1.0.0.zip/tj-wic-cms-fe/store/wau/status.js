export const state = () => ({
  pageCreating: false,
  modalCreating: false
})

export const mutations = {
  setLoadingStatus(state, { field, status }) {
    state[field] = status
  }
}
