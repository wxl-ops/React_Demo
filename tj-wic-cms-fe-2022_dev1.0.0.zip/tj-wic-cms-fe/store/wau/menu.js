/* eslint-disable no-async-promise-executor */
// import { GetPermission } from '@/api/account'
// import localSiders from '@/menu/sider'
// import wauConfig from '@/wau.config'

// const { source = 'local' } = wauConfig.menu

export const state = () => ({
  openNames: [],
  role: '',
  permissionStr: '',
  siders: []
})

export const mutations = {
  setOpenNames(state, names) {
    state.openNames = names
  }
  // setSider(state, data) {
  //   state.siders = data.menus
  //   state.role = data.role
  //   state.permissionStr = data.permissionStr
  // }
}

// const formatSider = (siders) => {
//   return siders.map((sider) => {
//     if (typeof sider.children !== 'undefined') {
//       sider.children = formatSider(sider.children)
//     }
//     return {
//       children: sider.children ? sider.children : [],
//       title: sider.title,
//       path: sider.path,
//       icon: sider.icon
//     }
//   })
// }

// 检测权限
// const checkPermission = (arr, permissionStr) => {
//   const item = [...arr]
//   const t = item.length
//   if (t > 0) {
//     for (let i = t; i--; i >= 0) {
//       if (item[i].children) {
//         const children = []
//         item[i].children.map((item2) => {
//           if (permissionStr.includes(item2.key + '_')) {
//             children.push(item2)
//           }
//         })
//         if (children.length === 0) {
//           item.splice(i, 1)
//         } else {
//           item[i].children = children
//         }
//       } else if (!permissionStr.includes(item[i].key + '_')) {
//         item.splice(i, 1)
//       }
//     }
//   }
//   // 判断当前url有没有在路由内
//   // if (this.inInitName === false) {
//   //   item.map((list) => {
//   //     if (list.path === this.$route.path) {
//   //       this.inInitName = true
//   //     }
//   //   })
//   // }
//   return item
// }

export const actions = {
  //   load({ commit, state, dispatch }) {
  //     return new Promise(async (resolve, reject) => {
  //       try {
  //         if (state.siders.length === 0) {
  //           let siders = []
  //           let role = 'operator'
  //           let permissionStr = ''
  //           if (source === 'remote') {
  //             const permission = await GetPermission()
  //             if (permission && permission.ret === 0) {
  //               const data = permission.data
  //               role = data.role
  //               data.permission_list.map((item) => {
  //                 permissionStr += ',' + item + '_'
  //               })
  //               siders = checkPermission(localSiders, permissionStr)
  //             }
  //           } else {
  //             siders = localSiders
  //           }
  //           const menus = formatSider(siders)
  //           commit('setSider', { menus, role, permissionStr })
  //           resolve(role)
  //         } else {
  //           resolve('')
  //         }
  //       } catch (ex) {
  //         reject(ex)
  //       }
  //     })
  //   }
}
