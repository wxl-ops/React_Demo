export const state = () => ({
  pager: {
    current: 1,
    pageSize: 10,
    total: 0
  }
})

export const mutations = {
  changePager(state, { current, pageSize, total }) {
    if (current) {
      state.pager.current = current
    }
    if (pageSize) {
      state.pager.pageSize = pageSize
    }
    if (total) {
      state.pager.total = total
    }
  }
}
