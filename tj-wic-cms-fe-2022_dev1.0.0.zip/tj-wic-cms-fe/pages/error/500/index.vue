<template>
  <div class="error-page">
    <div class="error-block">
      <div class="error-img">
        <img
          src="https://file.iviewui.com/iview-pro/icon-500-color.svg"
          alt="500"
        />
      </div>
      <div class="error-content">
        <h1 class="error-title">500</h1>
        <div class="error-desc">服务器内部错误</div>
        <Button type="primary" to="/" size="large">返回首页</Button>
      </div>
    </div>
  </div>
</template>

<style lang="less">
.error-page {
  width: 100%;
  height: 100%;
  background: #fff;
  font-size: 20px;
  color: #888;
  .error-block {
    display: flex;
    position: relative;
    top: 80px;
    width: 850px;
    margin: 0 auto;
    .error-img {
      img {
        width: 430px;
      }
    }
    .error-content {
      padding-top: 50px;
      padding-left: 120px;
      .error-title {
        margin-bottom: 6px;
        font-size: 60px;
        color: #333;
      }
      .error-desc {
        margin-bottom: 20px;
      }
    }
  }
}
</style>
