<template>
  <div class="webconfig-page">
    <Tabs v-model="tabIndex" @on-click="tabsChange">
      <TabPane
        v-for="item in tabs"
        :key="item.value"
        :label="item.label"
      ></TabPane>
      <Button
        slot="extra"
        type="primary"
        @click="goPublish(-1)"
        style="margin-right:10px;"
        >保存</Button
      >
      <Button slot="extra" type="primary" @click="goPublish(0)">发布</Button>
    </Tabs>
    <div class="pcconfig-form-box">
      <Form ref="formItem" :model="formItem">
        <div
          v-for="(items, index) in formItem.other_data.plan"
          :key="index"
          class="h5config-subevents-list"
        >
          <div class="titleandbtn-box">
            <div v-if="tabIndex === 0" class="title-box">
              动态{{ index + 1 }}
            </div>
            <div v-if="tabIndex === 1" class="title-box">
              滨城
            </div>
            <div v-if="tabIndex === 2" class="title-box">
              文创
            </div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.plan.length - 1"
                class="btn"
                @click="onformChildItemDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.plan.length - 1 &&
                    formItem.other_data.plan.length > 1 &&
                    index >= 1
                "
                class="btn"
                @click="onformChildItemUp(index)"
                >上移</a
              >
              <a
                v-if="tabIndex === 1"
                class="btn"
                @click="onformChildItemDel(index)"
                >删除</a
              >
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              v-if="tabIndex == 0"
              label="功能链接"
              :label-width="80"
              :prop="`other_data.plan[${index}].fun_id`"
              :rules="ruleValidate.id"
            >
              <Button
                @click="
                  onListDialogShow(
                    contentType,
                    index,
                    contentType === 5 ? 2 : 1
                  )
                "
                >{{ items.fun_id ? '已选择' : '请选择' }}</Button
              >
            </FormItem>
            <FormItem
              v-if="tabIndex !== 1"
              label="资讯标题"
              :label-width="80"
              :prop="`other_data.plan[${index}].title`"
              :rules="ruleValidate.title"
            >
              <Input
                v-model="items.title"
                placeholder="请输入"
                style="width:400px;"
              />
            </FormItem>
            <FormItem
              v-if="tabIndex == 0"
              label="资讯简介"
              :label-width="80"
              :prop="`other_data.plan[${index}].content`"
              :rules="ruleValidate.content"
            >
              <Input
                v-model="items.content"
                placeholder="请输入简介"
                style="width:400px;"
              />
            </FormItem>
            <FormItem v-if="tabIndex == 0" label="封面图" :label-width="80">
              <CustomVueCropper
                :id="String(index)"
                :value="items.fun_img"
                :fixed="true"
                :is-operation-location="true"
                :width="86"
                :height="60"
                :fixed-number="[86, 60]"
                @onUploadImage="onUploadImage"
              />
            </FormItem>
            <FormItem
              v-if="tabIndex === 1"
              label="发布时间"
              :label-width="80"
              :prop="`other_data.plan[${index}].publish_time`"
              :rules="ruleValidate.publish_time"
            >
              <DatePicker
                :value="items.publish_time"
                type="date"
                placeholder="选择发布时间"
                @on-change="onDateChange(index, $event)"
              ></DatePicker>
            </FormItem>
            <FormItem
              v-if="tabIndex == 1"
              label="内容"
              :label-width="80"
              :prop="`other_data.plan[${index}].title`"
              :rules="ruleValidate.title"
            >
              <vue-ueditor-wrap
                v-model="items.title"
                :config="editorConfig"
                @ready="editorReady"
              />
            </FormItem>
            <FormItem
              v-if="tabIndex == 2"
              label="内容"
              :label-width="80"
              :prop="`other_data.plan[${index}].content_text`"
              :rules="ruleValidate.content_text"
            >
              <vue-ueditor-wrap
                v-model="items.content_text"
                :config="editorConfig"
                @ready="editorReady"
              />
            </FormItem>
          </div>
        </div>
        <div v-if="formItem.other_data.plan.length < maxLength" class="btn-add">
          <Button type="primary" @click="onformChildItemAdd">添加</Button>
          <span class="btn-add-info">最多添加{{ maxLength }}个</span>
        </div>
      </Form>
    </div>
    <listDialog
      :show="isDialogShow"
      :contentType="contentType"
      @cancel="onDialogCancel"
      @sure="onDialogSure"
    />
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from "vue-ueditor-wrap";
import showIframe from "../../../components/iframe";
import CustomVueCropper from "@/components/imgUpload/CustomVueCropper";
import listDialog from "@/components/listDialogEn";
import { GetListData, saveContent } from "@/api/content";
import Setting from "@/wau.config"; // TODO 1 添加编辑的大容器
const CON_UEDITOR = {};
export default {
  components: {
    CustomVueCropper,
    listDialog,
    showIframe,
    VueUeditorWrap,
  },
  data() {
    return {
      tabNum: 0,
      tabIndex: 0,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: "100%",
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl,
      },
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: "",
        type: "",
      },
      tabs: [
        {
          label: "大会动态",
          value: 1,
        },
        {
          label: "美丽滨城",
          value: 2,
        },
        {
          label: "大会文创",
          value: 3,
        },
      ],
      formItem: {
        title: "移动端首页配置",
        other_data: {
          content_model: "wap_index_operate",
          column: "",
          plan: [
            {
              fun_id: "",
              fun_img: "",
              content: "",
              title: "",
              publish_time: " ",
            },
          ],
        },
      },
      ruleValidate: {
        // id: [
        //   {
        //     required: true,
        //     message: '请选择功能链接',
        //     trigger: 'blur'
        //   }
        // ],
        // title: [
        //   {
        //     required: true,
        //     message: '请输入',
        //     trigger: 'blur'
        //   }
        // ],
        // content: [
        //   {
        //     required: true,
        //     message: '请输入简介',
        //     trigger: 'blur'
        //   }
        // ],
        // img: [
        //   {
        //     required: true,
        //     message: '请选择图片',
        //     trigger: 'blur'
        //   }
        // ],
        // publish_time: [
        //   {
        //     required: false,
        //     message: '请输入',
        //     trigger: 'blur'
        //   }
        // ],
      },
      contentType: 1,
      isDialogShow: false,
      maxLength: 4,
      column: "dynamic",
    };
  },
  mounted() {
    this.contentType = 22;
    const that = this;
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "image",
      };
    };
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "video",
      };
    };
    this.tabsChange(0);
  },
  methods: {
    onDateChange(index, e) {
      console.log(this.formItem.other_data.plan[0], e);
      this.formItem.other_data.plan[0].publish_time = e;
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {};
      CON_UEDITOR[e.uid].uEditor = e;
    },
    //校验规则
    changeRules(tabNum) {
      switch (tabNum) {
        case 0: {
          this.ruleValidate = {
            id: [
              {
                required: true,
                message: "请选择功能链接",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入资讯标题",
                trigger: "blur",
              },
            ],
            content: [
              {
                required: true,
                message: "请输入资讯简介",
                trigger: "blur",
              },
            ],
            fun_img: [
              {
                required: true,
                message: "请选择图片",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 1: {
          this.ruleValidate = {
            publish_time: [
              {
                required: false,
                message: "请输入",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 2: {
          this.ruleValidate = {};
          break;
        }
      }
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      console.log(type, list);
      switch (type) {
        case "image":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "";
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
          }
          break;
        case "video":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "<span>&#12288;</span>";
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
          }
          break;
        default:
          console.log("没有匹配的值");
          break;
      }
      this.showIframeObj.show = false;
    },
    // 发布
    goPublish(submitType) {
      this.changeRules(this.tabNum);
      this.formItem.other_data.column = this.column;
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: 1,
        content_type: 31,
        tag: "en",
      };
      const keys = Object.keys(this.ruleValidate);
      if (submitType === 0) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true;
        });
      } else {
        keys.forEach((key) => {
          console.log(key);
          this.ruleValidate[key][0].required = key === "title";
        });
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          const keys = Object.keys(this.ruleValidate);
          keys.forEach((key) => {
            this.ruleValidate[key][0].required = false;
          });

          this.$refs.formItem.validate((valid) => {
            console.log(213, valid);
          });
          saveContent(param).then((res) => {
            if (res.ret === 0) {
              this.$Message.info(`${submitType === -1 ? "保存" : "提交"}成功`);
              this.tabsChange(this.tabIndex);
            }
          });
        } else {
          this.$Message.error("请完善必填信息后再操作发布!");
        }
      });
    },
    onDialogCancel() {
      this.isDialogShow = false;
    },
    onDialogSure(val) {
      const isExit = this.formItem.other_data.plan.find(function(obj) {
        return obj.fun_id === val.id;
      });
      if (!isExit) {
        this.isDialogShow = false;
        this.formItem.other_data.plan[this.listIndex].title = val.title;
        this.formItem.other_data.plan[this.listIndex].fun_id = val._id;
        this.formItem.other_data.plan[this.listIndex].content = val.content;
        this.formItem.other_data.plan[this.listIndex].fun_img = val.head_img;
      } else {
        this.$Message.error("选择数据重复！");
      }
    },
    // 功能选择弹窗显示
    onListDialogShow(contentType, index) {
      this.listIndex = index;
      this.contentType = contentType;
      this.isDialogShow = true;
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.other_data.plan[name].fun_img = url;
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0];
      return arr;
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.plan, index, index + 1);
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.plan, index, index - 1);
    },
    // 添加
    onformChildItemAdd() {
      if (this.formItem.other_data.plan.length === this.maxLength) {
        this.$Message.error(`最多添加${this.maxLength}条！`);
        return false;
      }
      const obj = {
        fun_id: "",
        fun_img: "",
        content: "",
        title: "",
      };
      this.formItem.other_data.plan.splice(
        this.formItem.other_data.plan.length,
        0,
        obj
      );
    },
    // 删除
    onformChildItemDel(index) {
      if (this.formItem.other_data.plan.length > 1) {
        this.formItem.other_data.plan.splice(index, 1);
      } else {
        this.$Message.error("最少一条数据！");
      }
    },
    // tab切换
    tabsChange(e) {
      this.tabNum = e;
      const keys = Object.keys(this.ruleValidate);
      keys.forEach((key) => {
        this.ruleValidate[key][0].required = false;
      });

      this.$refs.formItem.validate((valid) => {
        console.log(213, valid);
      });

      this.changeRules(e);
      this.tabNum = e;
      this.tabIndex = e;
      this.formItem = {
        title: "移动端首页配置",
        other_data: {
          content_model: "wap_index_operate",
          column: "",
          plan: [
            {
              fun_id: "",
              fun_img: "",
              content: "",
              title: "",
              publish_time: " ",
            },
          ],
        },
      };
      if (e === 0) {
        this.column = "dynamic";
        this.maxLength = 4;
      } else if (e === 1) {
        this.column = "bincheng";
        this.maxLength = 1;
      } else if (e === 2) {
        this.column = "wenchuang";
        this.maxLength = 1;
      }
      GetListData({
        tab_type: 1,
        p: 1,
        lang_tag: "en",
        content_type: 31,
        column: this.column,
      }).then((res) => {
        if (res.ret === 0) {
          this.formItem = res.data || {
            title: "移动端首页配置",
            other_data: {
              content_model: "wap_index_operate",
              column: "",
              plan: [
                {
                  fun_id: "",
                  fun_img: "",
                  content: "",
                  title: "",
                  publish_time: " ",
                },
              ],
            },
          };
        }
      });
    },
  },
};
</script>

<style lang="less">
.h5config-subevents-list {
  border-radius: 8px;
  border: 1px solid #dcdee2;
  margin-bottom: 20px;

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #dcdee2;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.btn-add {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-radius: 8px;
  border: 1px solid #dcdee2;
  box-sizing: border-box;
  padding: 10px;

  &-info {
    font-size: 14px;
  }
}
</style>
