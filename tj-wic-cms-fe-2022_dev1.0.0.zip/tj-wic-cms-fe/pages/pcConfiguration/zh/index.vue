<template>
  <div class="pcconfig-page">
    <Tabs v-model="tabIndex" @on-click="tabsChange">
      <TabPane
        v-for="item in tabs"
        :key="item.value"
        :label="item.label"
      ></TabPane>
      <Button
        slot="extra"
        type="primary"
        @click="goPublish(-1)"
        style="margin-right: 10px"
        >保存</Button
      >
      <Button slot="extra" type="primary" @click="goPublish(0)">发布</Button>
    </Tabs>
    <div class="pcconfig-form-box" v-if="showTable">
      <Form ref="formItem" :model="formItem" :rules="ruleValidate">
        <div>
          <div
            v-for="(items, index) in formItem.other_data.plan"
            :key="items.id"
            class="pcconfig-subevents-list"
          >
            <div class="titleandbtn-box">
              <div v-if="tabIndex === 0" class="title-box">直播</div>
              <div v-if="tabIndex === 1" class="title-box">
                峰会{{ index + 1 }}
              </div>
              <div v-if="tabIndex === 2" class="title-box">
                赛事{{ index + 1 }}
              </div>
              <div v-if="tabIndex === 3" class="title-box">
                体验{{ index + 1 }}
              </div>
              <div v-if="tabIndex === 4" class="title-box">
                滨城
              </div>
              <div v-if="tabIndex === 5" class="title-box">
                文创
              </div>
              <div class="btn-box">
                <a
                  v-if="index < formItem.other_data.plan.length - 1"
                  class="btn"
                  @click="onformChildItemDown(index)"
                  >下移</a
                >
                <a
                  v-if="
                    index <= formItem.other_data.plan.length - 1 &&
                    formItem.other_data.plan.length > 1 &&
                    index >= 1
                  "
                  class="btn"
                  @click="onformChildItemUp(index)"
                  >上移</a
                >
                <a
                  v-if="tabIndex !== 0 && tabIndex !== 4 && tabIndex !== 5"
                  class="btn"
                  @click="onformChildItemDel(index)"
                  >删除</a
                >
              </div>
            </div>
            <div class="subevents-form-box">
              <FormItem
                v-if="tabIndex !== 4 && tabIndex !== 5"
                :label="tabIndex === 0 ? '直播链接' : '功能链接'"
                :label-width="80"
                :prop="`other_data.plan[${index}].fun_id`"
                :rules="ruleValidate.id"
              >
                <Button
                  @click="
                    onListDialogShow(
                      contentType,
                      index,
                      tabIndex === 1 ? (contentType === 5 ? 2 : 1) : ''
                    )
                  "
                  >{{ items.fun_id ? "已选择" : "请选择" }}</Button
                >
              </FormItem>
              <FormItem
                v-if="tabIndex !== 4"
                :label="tabIndex === 0 || tabIndex === 1 ? '论坛标题' : '标题'"
                :label-width="80"
                :prop="`other_data.plan[${index}].title`"
                :rules="ruleValidate.title"
              >
                <Input
                  v-model="items.title"
                  :disabled="tabIndex === 0"
                  placeholder="请输入"
                  style="width: 400px"
                />
              </FormItem>
              <FormItem
                v-if="tabIndex === 0 || tabIndex === 1"
                label="论坛时间"
                :label-width="80"
                :prop="`other_data.plan[${index}].time`"
              >
                <div
                  v-if="typeof items.time === 'object' && items.time.length > 0"
                >
                  <p v-for="(lists, idx) in items.time" :key="idx">
                    {{ lists.date }} {{ lists.time
                    }}{{ idx === items.time.length - 1 ? "" : "," }}
                  </p>
                </div>
                <div v-else style="color: #ccc">暂无</div>
              </FormItem>
              <FormItem
                v-if="tabIndex !== 0 && tabIndex !== 4 && tabIndex !== 5"
                label="图片上传"
                :label-width="80"
                :prop="`other_data.plan[${index}].fun_img`"
                :rules="ruleValidate.fun_img"
              >
                <CustomVueCropper
                  :id="String(index)"
                  :value="items.fun_img"
                  :fixed="true"
                  :is-operation-location="true"
                  :width="fixedWidth"
                  :height="index === 0 && tabIndex === 2 ? 465 : fixedHeight"
                  :fixed-number="[
                    fixedWidth,
                    index === 0 && tabIndex === 2 ? 465 : fixedHeight,
                  ]"
                  @onUploadImage="onUploadImage"
                />
              </FormItem>
              <FormItem
                v-if="tabIndex === 4"
                label="发布时间"
                :label-width="80"
                :prop="`other_data.plan[${index}].publish_time`"
                :rules="ruleValidate.publish_time"
              >
                <!-- ：value XXX -->

                <DatePicker
                  :value="items.publish_time"
                  type="date"
                  placeholder="选择发布时间"
                  @on-change="onDateChange(index, $event)"
                ></DatePicker>
              </FormItem>
              <FormItem
                v-if="tabIndex == 4"
                label="内容"
                :label-width="80"
                :prop="`other_data.plan[${index}].title`"
                :rules="ruleValidate.title"
              >
                <vue-ueditor-wrap
                  v-model="items.title"
                  :config="editorConfig"
                  @ready="editorReady"
                />
              </FormItem>
              <FormItem
                v-if="tabIndex == 5"
                label="内容"
                :label-width="80"
                :prop="`other_data.plan[${index}].content_text`"
                :rules="ruleValidate.content_text"
              >
                <vue-ueditor-wrap
                  v-model="items.content_text"
                  :config="editorConfig"
                  @ready="editorReady"
                />
              </FormItem>
            </div>
          </div>
          <div
            v-if="formItem.other_data.plan.length < maxLength"
            class="btn-add"
          >
            <Button type="primary" @click="onformChildItemAdd">添加</Button>
            <span class="btn-add-info">最多添加{{ maxLength }}个</span>
          </div>
        </div>
      </Form>
    </div>
    <listDialog
      :show="isDialogShow"
      :contentType="contentType"
      :searchType="searchType"
      @cancel="onDialogCancel"
      @sure="onDialogSure"
    />
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from "vue-ueditor-wrap";
import showIframe from "../../../components/iframe";
import CustomVueCropper from "@/components/imgUpload/CustomVueCropper";
import listDialog from "@/components/listDialog";
import { GetListData, saveContent } from "@/api/content";
import Setting from "@/wau.config"; // TODO 1 添加编辑的大容器
const CON_UEDITOR = {};

export default {
  components: {
    CustomVueCropper,
    VueUeditorWrap,
    listDialog,
    showIframe,
  },
  data() {
    return {
      tabNum: 0,
      tabIndex: 0,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: "100%",
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl,
      },
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: "",
        type: "",
      },
      tabs: [
        {
          label: "首页直播",
          value: 5,
        },
        {
          label: "高峰会",
          value: 1,
        },
        // {
        //   label: '平行论坛',
        //   value: 2
        // },
        {
          label: "智能赛事",
          value: 3,
        },
        {
          label: "智能体验",
          value: 4,
        },
        {
          label: "美丽滨城",
          value: 6,
        },
        {
          label: "大会文创",
          value: 7,
        },
      ],
      formItem: {
        title: "",
        other_data: {
          content_model: "web_index_operate",
          column: "", // 高峰论坛：summit；平行论坛：parallel；智能赛事：match；智能体验：experience；
          plan: [
            {
              fun_id: "",
              fun_img: "",
              time: [],
              title: "",
              publish_time: "",
            },
          ],
        },
      },
      ruleValidate: {},
      contentType: 1,
      isDialogShow: false,
      searchType: 1,
      maxLength: 2,
      column: "",
      fixedWidth: 386,
      fixedHeight: 228,
      showTable: true,
    };
  },
  mounted() {
    this.contentType = 4;
    console.log(this.formItem.other_data.plan[0].publish_time);
    // debugger;
    const that = this;
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "image",
      };
    };
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "video",
      };
    };
    this.tabsChange(0);
  },
  // updated(){
  //   this.$refs.dd[0]
  // },
  methods: {
    onDateChange(index, e) {
      console.log(123);
      console.log(e);
      this.formItem.other_data.plan[0].publish_time = e;
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {};
      CON_UEDITOR[e.uid].uEditor = e;
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      console.log(type, list);
      switch (type) {
        case "image":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "";
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
          }
          break;
        case "video":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "<span>&#12288;</span>";
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
          }
          break;
        default:
          console.log("没有匹配的值");
          break;
      }
      this.showIframeObj.show = false;
    },
    //校验规则
    changeRules(tabNum) {
      switch (tabNum) {
        case 0: {
          this.ruleValidate = {
            id: [
              {
                required: true,
                message: "请选择功能链接",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 1: {
          this.ruleValidate = {
            id: [
              {
                required: true,
                message: "请选择功能链接",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
            fun_img: [
              {
                required: true,
                message: "请选择图片",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 2: {
          this.ruleValidate = {
            id: [
              {
                required: true,
                message: "请选择功能链接",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
            fun_img: [
              {
                required: true,
                message: "请选择图片",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 3: {
          this.ruleValidate = {
            id: [
              {
                required: true,
                message: "请选择功能链接",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
            fun_img: [
              {
                required: true,
                message: "请选择图片",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 4: {
          this.ruleValidate = {
            publish_time: [
              {
                required: false,
                message: "请输入",
                trigger: "blur",
              },
            ],
            title: [
              {
                required: true,
                message: "请输入",
                trigger: "blur",
              },
            ],
          };
          break;
        }
        case 5: {
          this.ruleValidate = {};
          break;
        }
      }
    },
    // 发布
    goPublish(submitType) {
      this.changeRules(this.tabNum);

      this.formItem.other_data.column = this.column;
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: 1,
        content_type: 30,
        tag: "zh",
      };
      const keys = Object.keys(this.ruleValidate);
      // if (submitType === 0) {
      //   keys.forEach((key) => {
      //     this.ruleValidate[key][0].required = true
      //   })
      //   console.log(this.formItem)
      // console.log(123)
      //   console.log(this.formItem)
      // } else {
      //   keys.forEach((key) => {
      //     console.log(key)
      //     this.ruleValidate[key][0].required = key === 'title'
      //   })
      // }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          const keys = Object.keys(this.ruleValidate);
          keys.forEach((key) => {
            this.ruleValidate[key][0].required = false;
          });

          this.$refs.formItem.validate((valid) => {
            console.log(213, valid);
          });

          saveContent(param).then((res) => {
            if (res.ret === 0) {
              this.$Message.info(`${submitType === -1 ? "保存" : "提交"}成功`);
              this.tabsChange(this.tabIndex);
            }
          });
        } else {
          this.$Message.error("请完善必填信息后再操作发布!");
        }
      });
    },
    onDialogCancel() {
      this.isDialogShow = false;
    },
    onDialogSure(val) {
      // const isExit = this.formItem.other_data.plan.find(function(obj) {
      //   return obj.fun_id === val.id
      // })
      // if (!isExit) {
      this.isDialogShow = false;
      this.formItem.other_data.plan[this.listIndex].title = val.title;
      this.formItem.other_data.plan[this.listIndex].fun_id = val._id;
      this.formItem.other_data.plan[this.listIndex].fun_img = val.head_img;
      this.formItem.other_data.plan[this.listIndex].time = val.schedule_time;
      this.formItem.other_data.plan[this.listIndex].fun_liveroom_id =
        val.other_data.liveroom_id;
      if (this.contentType === 10) {
        this.formItem.other_data.plan[this.listIndex].match_type =
          val.other_data.match_type;
        if (val.other_data.match_type === "2") {
          this.formItem.other_data.plan[this.listIndex].pc_url =
            val.other_data.skip.pc_url;
          this.formItem.other_data.plan[this.listIndex].web_url =
            val.other_data.skip.web_url;
        }
      }
      if (this.contentType === 19) {
        this.formItem.other_data.plan[this.listIndex].detail_page =
          val.other_data.detail_page;
      }
      // } else {
      //   this.$Message.error('选择数据重复！')
      // }
    },
    // 功能选择弹窗显示
    onListDialogShow(contentType, index, searchType) {
      this.searchType = searchType;
      this.listIndex = index;
      this.contentType = contentType;
      this.isDialogShow = true;
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.other_data.plan[name].fun_img = url;
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0];
      return arr;
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.plan, index, index + 1);
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.plan, index, index - 1);
    },
    // 添加
    onformChildItemAdd(index) {
      if (this.formItem.other_data.plan.length === this.maxLength) {
        this.$Message.error(`最多添加${this.maxLength}条！`);
        return false;
      }
      const obj = {
        fun_id: "",
        fun_img: "",
        time: [],
        title: "",
      };
      this.formItem.other_data.plan.splice(
        this.formItem.other_data.plan.length,
        0,
        obj
      );
    },
    // 删除
    onformChildItemDel(index) {
      if (this.formItem.other_data.plan.length > 1) {
        this.formItem.other_data.plan.splice(index, 1);
      } else {
        this.$Message.error("最少一条数据！");
      }
    },
    // tab切换
    tabsChange(e) {
      // 高峰论坛：summit；平行论坛：parallel；智能赛事：match；智能体验：experience；
      // else if (e === 2) {
      //   this.maxLength = 6
      //   this.contentType = 5
      //   this.column = 'parallel'
      //   this.fixedWidth = 386
      //   this.fixedHeight = 228
      // }
      console.log(e, this.ruleValidate, '----------');
      this.tabNum = e;
      const keys = Object.keys(this.ruleValidate);
      keys.forEach((key) => {
        this.ruleValidate[key][0].required = false;
      });

      this.$refs.formItem.validate((valid) => {
        console.log(213, valid);
      });

      this.changeRules(e);
      this.tabNum = e;
      this.tabIndex = e;
      this.showTable = false;
      this.formItem = {
        title: "",
        other_data: {
          content_model: "web_index_operate",
          column: "", // 高峰论坛：summit；平行论坛：parallel；智能赛事：match；智能体验：experience；
          plan: [
            {
              fun_id: "",
              fun_img: "",
              time: [],
              title: "",
              publish_time: "",
            },
          ],
        },
      };
      console.log("点击tab对呀的值");
      console.log(e);
      if (e === 0) {
        this.maxLength = 1;
        this.contentType = 4;
        this.column = "liveroom";
      } else if (e === 1) {
        this.maxLength = 3;
        this.contentType = 4;
        this.column = "summit";
        this.fixedWidth = 580;
        this.fixedHeight = 465;
      } else if (e === 2) {
        this.maxLength = 5;
        this.contentType = 10;
        this.column = "match";
        this.fixedWidth = 386;
        this.fixedHeight = 228;
      } else if (e === 3) {
        this.maxLength = 10;
        this.contentType = 19;
        this.column = "experience";
        this.fixedWidth = 568;
        this.fixedHeight = 456;
      } else if (e === 4) {
        this.maxLength = 1;
        this.column = "bincheng";
      } else if (e === 5) {
        this.maxLength = 1;
        this.column = "wenchuang";
      }
      this.showTable = true;
      GetListData({
        tab_type: 1,
        p: 1,
        lang_tag: "zh",
        content_type: 30,
        column: this.column,
      }).then((res) => {
        if (res && res.ret === 0) {
          // if(this.tabIndex == 4){

          //  this.formItem.other_data.plan[4].publish_time = res.data.other_data.plan[4].publish_time
          // }
          this.formItem = res.data || {
            title: "pc首页配置",
            other_data: {
              content_model: "web_index_operate",
              column: "", // 高峰论坛：summit；平行论坛：parallel；智能赛事：match；智能体验：experience；
              plan: [
                {
                  fun_id: "",
                  fun_img: "",
                  time: [],
                  title: "",
                  publish_time: "",
                },
              ],
            },
          };
        }
      });
    },
  },
};
</script>

<style lang="less">
.pcconfig-subevents-list {
  border-radius: 8px;
  border: 1px solid #dcdee2;
  margin-bottom: 20px;

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #dcdee2;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.btn-add {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-radius: 8px;
  border: 1px solid #dcdee2;
  box-sizing: border-box;
  padding: 10px;

  &-info {
    font-size: 14px;
  }
}
</style>
