<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="活动类型（中文）" prop="title">
        <Input
          v-model="formItem.title"
          placeholder="请输入中文活动类型"
          maxlength="5"
          show-word-limit
        />
      </FormItem>
      <FormItem label="活动类型（英文）" prop="en_title">
        <Input
          v-model="formItem.en_title"
          placeholder="请输入英文活动类型"
          maxlength="20"
          show-word-limit
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem style="margin-top:50px;">
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="submitPreview"
        />
      </FormItem>
    </Form>
  </div>
</template>

<script>
import footerButton from '../../../components/content/fotterButton'
import { getView } from '@/api/content'
import util from '@/libs/util'

export default {
  components: { footerButton },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      formItem: {
        title: '', // 活动类型（中文）
        en_title: '', // 活动类型（英文）
        weight: 999, // 排序
        other_data: {
          content_model: ''
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入中文活动类型',
            trigger: 'blur'
          }
        ],
        en_title: [
          {
            required: true,
            message: '请输入英文活动类型',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 1,
      loading: false
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    if (this.id !== '') {
      this.loadInfo()
    }
  },
  methods: {
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required =
            key === 'title' || key === 'en_title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 预览
    submitPreview(formName) {
      console.log('预览预览。。。。')
    },
    // 获取详情数据
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    }
  }
}
</script>

<style lang="less">
.color_grey {
  color: #999;
}
</style>
