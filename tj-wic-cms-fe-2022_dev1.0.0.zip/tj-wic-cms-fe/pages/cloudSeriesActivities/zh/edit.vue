<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="标题" prop="title">
        <Input v-model="formItem.title" placeholder="请输入" />
      </FormItem>
      <FormItem label="活动类型" prop="other_data.type_id">
        <Select v-model="formItem.other_data.type_id">
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="580"
          :height="220"
          :fixed-number="[580, 220]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="举办单位">
        <Input v-model="formItem.other_data.organizer" placeholder="请输入" />
      </FormItem>
      <!-- short_content -->
      <FormItem label="一句话简介">
        <Input
          v-model="formItem.other_data.short_content"
          placeholder="请输入"
        />
      </FormItem>
      <FormItem label="活动视频">
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.activity_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
      </FormItem>
      <FormItem label="概要介绍">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem label="详情页">
        <RadioGroup v-model="formItem.other_data.detail_page">
          <Radio :label="1">开启</Radio>
          <Radio :label="-1">关闭</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="系列活动介绍">
        <Button
          v-if="formItem.other_data.intro.length === 0"
          @click="onformChildItemAdd(0)"
          >添加</Button
        >
        <div
          v-for="(items, index) in formItem.other_data.intro"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.intro.length - 1"
                class="btn"
                @click="onformChildItemDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.intro.length - 1 &&
                    formItem.other_data.intro.length > 1 &&
                    index >= 1
                "
                class="btn"
                @click="onformChildItemUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemAdd(index)">向下添加</a>
              <a class="btn" @click="onformChildItemDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="标题"
              :label-width="80"
              :rules="ruleValidate.childtitle"
            >
              <Input
                v-model="items.title"
                placeholder="请输入"
                style="width:80%;"
              />
            </FormItem>
            <FormItem
              label="内容"
              style="margin-top:20px;"
              :rules="ruleValidate.childinfo"
            >
              <vue-ueditor-wrap
                style="margin-left:80px;width:80%;"
                :key="items.id"
                v-model="items.info"
                :config="editorConfig"
                @ready="editorReady"
              />
            </FormItem>
            <FormItem
              label="按钮标题"
              :label-width="80"
              style="margin-top:20px;"
            >
              <Input
                v-model="items.but_title"
                placeholder="请输入"
                style="width:80%;"
                :maxlength="langEn === 'zh' ? 5 : 10"
                show-word-limit
              />
            </FormItem>
            <FormItem
              label="附件上传"
              :label-width="80"
              style="margin-top:20px;"
            >
              <Button type="primary" @click="selectFile('document', index)">{{
                items.accessory
                  ? items.accessory.url
                    ? '已选择'
                    : '选择文件'
                  : '选择文件'
              }}</Button>
              <span>支持格式: .pdf</span>
              <div style="margin-left:80px;">
                <span>{{ items.accessory ? items.accessory.name : '' }}</span>
                <Icon
                  v-if="items.accessory && items.accessory.name"
                  type="md-trash"
                  size="18"
                  @click="items.accessory = {}"
                />
              </div>
            </FormItem>
          </div>
        </div>
      </FormItem>
      <FormItem style="margin-top:50px;">
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="submitPreview"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import showIframe from '../../../components/iframe'
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import VideoUpload from '@/components/videoUpload'
import { getView, GetListData } from '@/api/content'
import util from '@/libs/util'
import Setting from '@/wau.config'
const CON_UEDITOR = {} // TODO 1 添加编辑的大容器

export default {
  components: {
    VueUeditorWrap,
    showIframe,
    CustomVueCropper,
    footerButton,
    VideoUpload
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      formItem: {
        title: '', // 标题
        head_img: '', // 封面图
        weight: 999, // 排序
        html_content: '', // 概要介绍
        other_data: {
          content_model: 'cloud_activity',
          organizer: '', // 举办单位
          type_id: '', // 活动类型主键
          short_content: '', // 一句话简介
          activity_video: {
            video_img_url: '',
            video_url: ''
          },
          intro: [],
          detail_page: 1
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        childtitle: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        'other_data.type_id': [
          {
            required: true,
            message: '请选择活动类型',
            trigger: 'blur'
          }
        ],
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        childinfo: [
          {
            required: true,
            message: '请输入内容',
            trigger: 'blur'
          }
        ],
        'other_data.activity_video.video_url': [
          {
            required: true,
            message: '请选择活动视频',
            trigger: 'blur'
          }
        ],
        'other_data.short_content': [
          {
            required: true,
            message: '请输一句话简介',
            trigger: 'blur'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 0,
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      typeList: [],
      loading: false,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: ''
    }
  },
  created() {
    const that = this
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    if (this.id !== '') {
      this.loadInfo()
    }
    this.getTypeList()
  },
  methods: {
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.activity_video.video_url = url
        ? url[0].play_url
        : ''
      this.formItem.other_data.activity_video.video_img_url = url
        ? url[0].title_url
        : ''
    },
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {}
      CON_UEDITOR[e.uid].uEditor = e
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.intro, index, index + 1)
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.intro, index, index - 1)
    },
    // 添加
    onformChildItemAdd(index) {
      const obj = {
        title: '',
        info: '',
        but_title: '',
        accessory: {
          url: '',
          name: ''
        }
      }
      this.formItem.other_data.intro.splice(index + 1, 0, obj)
    },
    // 删除
    onformChildItemDel(index) {
      this.formItem.other_data.intro.splice(index, 1)
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 预览
    submitPreview(formName) {
      console.log('预览预览。。。。')
    },
    // 获取详情数据
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'cloud_activity'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          res.data.other_data.detail_page = res.data.other_data.detail_page
            ? Number(res.data.other_data.detail_page)
            : 1
          if (!res.data.other_data.intro) {
            res.data.other_data.intro = []
          } else {
            res.data.other_data.intro.map((items) => {
              if (!items.accessory) {
                items.accessory = {
                  url: '',
                  name: ''
                }
              }
            })
          }
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 获取活动类型
    getTypeList() {
      const params = {
        content_type: 16,
        tab_type: 1,
        p: 1,
        page_size: 3000
      }
      // 获取列表数据
      GetListData(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          res.data.list.map((items, index) => {
            this.typeList.push({
              label: items.title + '-' + items.en_title,
              value: items.id
            })
          })
        }
      })
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            // console.log('富文本视频的值')
            // console.log(CON_UEDITOR[this.showIframeObj.uid].uEditor)
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        case 'document':
          console.log(this.showIframeObj.valObj)
          console.log(list)
          // eslint-disable-next-line no-case-declarations
          const preg = /\.pdf|\.PDF/
          if (preg.test(list[0].document_url)) {
            console.log('111111111')
            this.formItem.other_data.intro[
              this.showIframeObj.valObj
            ].accessory.url = list[0].document_url
            this.formItem.other_data.intro[
              this.showIframeObj.valObj
            ].accessory.name = list[0].name
          } else {
            this.$Message.error('附件上传支持格式.pdf')
            break
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.head_img = url
    }
  }
}
</script>

<style lang="less">
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;
  .ivu-form-item-error-tip {
    left: 80px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
</style>
