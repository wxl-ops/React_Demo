<template>
  <div class="loginPage">
    <div class="left-page"></div>
    <div class="right-content">
      <div class="login-layer">
        <div class="logo">
        </div>
        <div class="title">登录</div>
        <div class="frame">
          <iframe
            v-if="iframeUrl"
            :src="iframeUrl"
            width="400"
            height="412"
            frameborder="0"
            allowtransparency="true"
            allowfullscreen="true"
          />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import util from '@/libs/util'
// import { getLoginUrl } from '@/api/common'
export default {
  layout: 'empty',
  data() {
    return {
      iframeUrl: '',
      autoLogin: true
    }
  },
  beforeDestroy() {
    window.removeEventListener('message', this.getMessage, false)
  },
  created() {},
  mounted() {
    const url = window.location.host
    // eslint-disable-next-line no-unused-vars
    if (url.includes('t-2022cms.wicongress.org.cn')) {
      this.iframeUrl =
        'https://t-2022cms.wicongress.org.cn/user/oauth2/login/?app_id=9da2acc7c42b0e73&redirect_uri=https%3A%2F%2Ft-2022cms.wicongress.org.cn%2Fcms-fe%2F&type=app_admin&account_id=35c18a07e9ffea71&scope=user_base,user_info,department_ids,role_keys,permission_keys&state=MY_STATE'
    } else if (url.includes('2022cms.wicongress.org.cn')) {
      this.iframeUrl =
        'https://2022cms.wicongress.org.cn/user/oauth2/login/?app_id=ceecbaa43ae0c14d&redirect_uri=https%3A%2F%2F2022cms.wicongress.org.cn%2Fcms-fe%2F&type=app_admin&account_id=35c18a07e9ffea71&scope=user_base,user_info,department_ids,role_keys,permission_keys&state=MY_STATE'
    } else {
      this.iframeUrl =
        'https://t-2022cms.wicongress.org.cn/user/oauth2/login/?app_id=9da2acc7c42b0e73&redirect_uri=https%3A%2F%2Ft-2022cms.wicongress.org.cn%2Fcms-fe%2F&type=app_admin&account_id=35c18a07e9ffea71&scope=user_base,user_info,department_ids,role_keys,permission_keys&state=MY_STATE'
    }
    // 自动登陆
    if (util.cookies.get('uuid')) {
      this.$router.replace(this.$route.query.redirect || '/')
    } else {
      // getLoginUrl()
      //   .then((res) => {
      //     if (res.ret === 0) {
      //       this.iframeUrl = res.data.login_url
      //       if (res.data.env === 'test') {
      //         util.cookies.set('env', 'tcms')
      //       } else {
      //         util.cookies.set('env', 'cms')
      //       }
      //     }
      //   })
      //   .catch(() => {
      //     window.location.href =
      //       'http://sso.cms.cantonfair.org.cn/?cb=http%3A%2F%2Fcms.cantonfair.org.cn%2Fbecms%2Findex.html'
      //   })
      window.addEventListener('message', this.getMessage, false)
    }
  },
  methods: {
    getMessage(e) {
      const event = e
      switch (event.data.method) {
        case 'wiiLoginClose':
          console.log('关闭窗口！')
          break
        case 'wiiLoginSuccessFeUser':
          console.log('登录成功')
          util.cookies.set('uuid', 'admin')
          util.cookies.set('token', 'admin')
          if (process.env.NODE_ENV === 'development') {
            this.$router.replace(this.$route.query.redirect || '/')
          } else {
            const url = window.location.host
            if (url.includes('t-2022cms.wicongress.org.cn')) {
              location.replace('https://t-2022cms.wicongress.org.cn/cms-fe/')
            } else if (url.includes('2022cms.wicongress.org.cn')) {
              location.replace('https://2022cms.wicongress.org.cn/cms-fe/')
            } else {
              this.$router.replace(this.$route.query.redirect || '/')
            }
          }
          break
        default:
          break
      }
    }
  }
}
</script>
<style lang="less" scope>
.loginPage {
  background: #fff;
  height: calc(100vh - 0px);
  min-width: 1000px;
  .left-page {
    float: left;
    min-width: 380px;
    width: calc(38vw);
    height: calc(100vh);
    background: #2d8cf0;
    background: url('../../../static/images/login/left-img.jpg') no-repeat;
    background-size: cover;
    background-position: 50% 50%;
  }
  .right-content {
    float: right;
    height: calc(100vh);
    width: calc(58vw);
    min-width: 580px;
    position: relative;
    .login-layer {
      position: absolute;
      width: 450px;
      height: 580px;
      left: 50%;
      top: 50%;
      margin-left: -225px;
      margin-top: -330px;
      text-align: center;
      .logo {
        img {
          height: 60px;
        }
      }
      .title {
        margin-top: 25px;
        font-size: 20px;
        font-weight: 600;
        height: 30px;
        line-height: 30px;
        background: url('../../../static/images/login/title_bg.jpg') center
          center no-repeat;
      }
      .frame {
        margin-top: 75px;
        // border: 1px solid #ececec;
      }
    }
  }
}
</style>
