<template>
  <div class="content-list-page">
    <!-- <div class="nav-tab-box">
      <Button class="btn" icon="ios-cloud-download-outline" @click="onDownLoad"
        >下载模板</Button
      >
      <Button class="btn" icon="md-cloud-upload" @click="onExport">导出</Button>
      <Upload
        ref="upload"
        class="btn"
        :on-success="handleSuccess"
        :on-error="handleError"
        :format="['xls', 'xlsx']"
        :on-format-error="handleFormatError"
        :before-upload="handleBeforeUpload"
        :show-upload-list="false"
        action="https://t-2021cms.wicongress.org.cn/cms/oss/invitationcode/import"
        style="display: inline-block;border:none;"
      >
        <Button icon="md-cloud-download">导入</Button>
      </Upload>
      <Button class="btn" type="primary" @click="onAdd">新建</Button>
    </div>
    <div class="search-container">
      <div class="sc-left">
        <Input
          v-model="queryData.search_title"
          :maxlength="100"
          class="inputList inputList2"
          placeholder="请输入关键字"
          style="width: 300px;"
        />
        <Select
          v-model="queryData.search_type"
          style="width:300px"
          placeholder="请选择使用状态"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </div>
      <div class="sc-right">
        <Button
          type="primary"
          style="margin-left: 10px;"
          @click="onPageSearch()"
          >查询</Button
        >
        <Button @click="clearSearch()">重置</Button>
      </div>
    </div> -->
    <div class="form-container">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="Number(pagination.current_page)"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
    <Modal v-model="isDialogShow" title="添加">
      <Form ref="formItem" :model="formItem" :rules="rules">
        <FormItem label="公司名称" prop="company_name">
          <Input
            style="width:350px;"
            placeholder="请输入公司名称"
            v-model="formItem.company_name"
          />
        </FormItem>
      </Form>
      <div slot="footer">
        <Button @click="onDialogChooseCancel">取消</Button>
        <Button type="primary" @click="onDialogChooseOk">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import 'viewerjs/dist/viewer.css'
// , importInvitationCode, exportInvitationCode
import {
  getInvitationCodeList,
  updateInvitationCode,
  getInvitationStatusList,
  delInvitationCode
} from '@/api/invitationcode'
import util from '@/libs/util'
export default {
  name: 'ContentListPage',
  data() {
    return {
      // 表格数据加载
      tableLoading: false,
      // 查询相关
      queryData: {
        p: 1,
        page_size: 10,
        search_type: '',
        search_title: ''
      },
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      // 列表数据
      listData: [],
      tableColumns: [
        // {
        //   title: '公司名称',
        //   key: 'company_name',
        //   minWidth: 160
        // },
        { title: '邀请码', key: 'code', minWidth: 160 },
        { title: '使用状态', key: 'status_title', align: 'center', width: 160 },
        {
          title: '操作',
          key: 'action',
          fixed: 'right',
          align: 'center',
          width: 250,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0'
                    // display: params.row.status === 1 ? 'inline-block' : 'none'
                  },
                  on: {
                    click: () => {
                      this.goDetailPage(params.row._id)
                    }
                  }
                },
                '查看'
              )
              // h(
              //   'Button',
              //   {
              //     props: { size: 'small', type: 'text' },
              //     style: {
              //       color: '#2d8cf0',
              //       display: params.row.status === 2 ? 'inline-block' : 'none'
              //     },
              //     on: {
              //       click: () => {
              //         this.onEdit(params.row)
              //       }
              //     }
              //   },
              //   '编辑'
              // ),
              // h(
              //   'Button',
              //   {
              //     props: { size: 'small', type: 'text' },
              //     style: {
              //       color: '#2d8cf0',
              //       display: params.row.status === 2 ? 'inline-block' : 'none'
              //     },
              //     on: {
              //       click: () => {
              //         this.onDel(params.row._id)
              //       }
              //     }
              //   },
              //   '删除'
              // )
            ])
          }
        }
      ],
      typeList: [
        {
          label: '用户1',
          value: '1'
        },
        {
          label: '用户2',
          value: '2'
        },
        {
          label: '用户3',
          value: '3'
        }
      ],
      isDialogShow: false,
      rules: {
        company_name: [
          {
            required: true,
            message: '请输入公司名称',
            trigger: 'blur'
          }
        ]
      },
      formItem: {
        company_name: ''
      }
    }
  },
  watch: {},
  beforeDestroy() {},
  created() {
    const { p } = this.$route.query
    this.queryData.p = p || 1
    this.getUseStatusList()
    this.resize()
  },

  methods: {
    onDownLoad() {
      const a = document.createElement('a') // 创建a标签
      a.style.display = 'none'
      a.setAttribute('download', '导入模板') // download属性
      a.setAttribute(
        'href',
        'https://ti-wic-test-1302130151.cos.ap-beijing.myqcloud.com/static-admin/%E5%AA%92%E4%BD%93%E9%82%80%E8%AF%B7%E7%A0%81%E5%AF%BC%E5%85%A5%E6%A8%A1%E6%9D%BF.xlsx'
      ) // href链接
      a.click() // 自执行点击事件
    },
    handleSuccess(res, file) {
      this.$Message.success('导入成功')
      console.log(res)
      const tableData = res.data
      const tableHeader = ['公司名称', '邀请码', '导入状态(成功/失败)']
      const tableKey = ['company_name', 'code', 'status']
      util.outExportExcel(tableHeader, tableKey, tableData, '导入结果')
      this.queryData.p = 1
      this.getListData()
    },
    handleError(res, file) {
      this.$Message.error('导入失败')
    },
    handleFormatError(file) {
      this.$Notice.warning({
        title: '表格格式错误',
        desc: '文件格式为xls或xlsx.'
      })
    },
    handleBeforeUpload() {
      console.log('图片上传之前')
    },
    // 获取使用状态
    getUseStatusList() {
      console.log('获取使用状态')
      getInvitationStatusList({ all: 1 }).then((res) => {
        if (res.ret === 0) {
          this.typeList = res.data
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // 弹窗点击取消
    onDialogChooseCancel() {
      this.formItem = {}
      this.isDialogShow = false
    },
    // 弹窗点击确定
    onDialogChooseOk() {
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          updateInvitationCode(this.formItem).then((res) => {
            if (res.ret === 0) {
              this.$Message.info((this.formItem._id ? '编辑' : '新增') + '成功')
              this.isDialogShow = false
              this.getListData()
            } else {
              this.isDialogShow = false
              this.$Message.error(res.msg)
            }
          })
        }
      })
    },
    // 导出
    onExport() {
      console.log('导出')
      const params = {
        p: 1,
        page_size: 3000
      }
      // 获取列表数据
      getInvitationCodeList(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          const tableData = res.data.list
          const tableHeader = ['公司名称', '邀请码']
          const tableKey = ['company_name', 'code']
          util.outExportExcel(tableHeader, tableKey, tableData)
        } else {
          this.$Message.error(res.msg || '获取所有数据失败,无法继续导出')
        }
      })
    },
    // 新增
    onAdd() {
      this.formItem.company_name = ''
      this.isDialogShow = true
    },
    // 编辑
    onEdit(row) {
      this.isDialogShow = true
      this.formItem = {
        _id: row._id,
        company_name: row.company_name
      }
    },
    // 删除
    onDel(id) {
      console.log('删除')
      console.log(id)
      delInvitationCode({ _id: id }).then((res) => {
        if (res.ret === 0) {
          this.$Message.info('删除成功')
          this.getListData()
        } else {
          this.$Message.error(res.msg || '删除失败，请稍后再试')
        }
      })
    },
    // 查询事件
    onPageSearch() {
      this.queryData.p = 1
      this.getListData()
    },
    // 跳转详情页面
    goDetailPage(id) {
      const goPath = {
        name: 'mediaInvitationCode-code-detail',
        query: {
          tab_type: this.queryData.tab_type,
          p: this.queryData.p,
          id
        }
      }
      this.$router.push(goPath)
    },
    // 获取表格数据
    getListData() {
      this.tableLoading = true
      this.listData = []
      const params = {
        keyword: this.queryData.search_title,
        status: Number(this.queryData.search_type),
        p: this.queryData.p,
        page_size: this.queryData.page_size
      }
      // 获取列表数据
      getInvitationCodeList(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          if (this.queryData.p > 1 && res.data.list.length === 0) {
            this.queryData.p = this.queryData.p - 1
            this.getListData()
          } else {
            this.listData = res.data.list
            this.pagination = res.data.pagination
          }
        }
      })
    },
    // 清空表单状态
    clearSearch() {
      this.queryData.p = 1
      this.queryData.page_size = this.pageSizeOpts[0]
      this.queryData.search_title = ''
      this.queryData.search_type = ''
      this.getListData()
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.queryData.p = page
      this.getListData()
    },
    PageSizeChange(pageSize) {
      this.queryData.page_size = pageSize
      this.queryData.p = 1
      this.getListData()
    },
    // 自适应大小
    resize() {
      const listHeight = 74
      const searchHeight = 335
      let listNum = ((window.innerHeight - searchHeight) / listHeight) >> 0
      if (listNum < 3) {
        listNum = 3
      }
      this.pageSizeOpts[0] = listNum
      this.pageSizeOpts[1] = listNum * 2
      this.pageSizeOpts[2] = listNum * 3
      this.queryData.page_size = listNum
      this.getListData()
    }
  }
}
</script>
<style lang="less">
.content-list-page {
  padding-bottom: 40px;
  padding-top: 0px !important;
  .nav-tab-box {
    height: 40px;
    width: 100%;
    // background: pink;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    .btn {
      margin-left: 10px;
    }
  }
  .search-container {
    margin-top: 20px;
    height: 32px;
    .sc-left {
      float: left;
      width: calc(~'100% - 170px');
      .inputList {
        width: calc(~'100% - 245px');
        margin-right: 10px;
      }
      .inputList2 {
        width: calc(~'100% - 469px');
        margin-right: 10px;
      }
    }
    .sc-right {
      float: right;
      button {
        margin-left: 20px;
      }
    }
  }
  .form-container {
    clear: both;
    margin-top: 20px;
    &-page {
      margin: 10px 0;
      line-height: 32px;
    }
  }
}
.ivu-modal-content {
  .ivu-form-item-error-tip {
    margin-left: 80px;
  }
}
.ivu-upload-drag {
  border: none;
  overflow: visible;

  &:hover {
    border: none;
  }
}
</style>
