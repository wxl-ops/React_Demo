<template>
  <div>
    <h3 style="box-sizing:border-box;padding:20px;line-height:60px;">
      员工列表
    </h3>
    <div style="box-sizing:border-box;padding:0 20px;">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="pagination.current_page"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
    <div style="margin-top:80px;box-sizing:border-box;padding:0 20px;">
      <Button @click="goBack">返回</Button>
    </div>
  </div>
</template>
<script>
import { getRegisteredUsersList } from '@/api/registeredUsers'
export default {
  components: {},
  data() {
    return {
      // 表格数据加载
      tableLoading: false,
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      // 列表数据
      listData: [],
      tableColumns: [
        { title: '邀请码', key: 'media_code', width: 160 },
        {
          title: '媒体单位',
          key: 'company_name',
          minWidth: 160
        },
        { title: '姓名', key: 'name', align: 'center', width: 160 },
        {
          title: '手机号',
          key: 'mobile',
          width: 160,
          render: (h, params) => {
            return h(
              'a',
              {
                props: {},
                style: {
                  color: '#2d8cf0',
                  display: 'inline-block'
                },
                on: {
                  click: () => {
                    this.goUserDetailPage(params.row._id)
                  }
                }
              },
              params.row.mobile
            )
          }
        },
        { title: '注册时间', key: 'register_time', width: 160 }
      ],
      p: '',
      id: ''
    }
  },
  beforeDestroy() {},
  created() {},
  mounted() {
    this.p = this.$route.query.p || 1
    this.id = this.$route.query.id
    if (this.id !== '') {
      this.getListData()
    }
  },
  methods: {
    // 获取详情
    getListData() {
      console.log('获取详情')
      getRegisteredUsersList({ company_id: this.id }).then((res) => {
        if (res.ret === 0) {
          this.listData = res.data.list
          this.pagination = res.data.pagination
        } else {
          this.$Message.error(res.msg || '获取详情接口报错')
        }
      })
    },
    // 跳转用户详情页
    goUserDetailPage(id) {
      const goPath = {
        name: 'registeredUsers-user-detail',
        query: {
          p: this.p,
          id
        }
      }
      this.$router.push(goPath)
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.pagination.current_page = page
      this.getListData()
    },
    PageSizeChange(pageSize) {
      this.pagination.page_size = pageSize
      this.pagination.current_page = 1
      this.getListData()
    },
    resize() {
      const listHeight = 74
      const searchHeight = 335
      let listNum = ((window.innerHeight - searchHeight) / listHeight) >> 0
      if (listNum < 3) {
        listNum = 3
      }
      this.pageSizeOpts[0] = listNum
      this.pageSizeOpts[1] = listNum * 2
      this.pageSizeOpts[2] = listNum * 3
      this.queryData.page_size = listNum
      this.getListData()
    },
    // 返回
    goBack() {
      const goPath = {
        name: 'mediaInvitationCode-code',
        query: {
          p: this.p
        }
      }
      this.$router.push(goPath)
    }
  }
}
</script>
<style lang="less">
.form-container-page {
  margin: 10px 0;
  line-height: 32px;
}
</style>
