<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="赛事标题" prop="title">
        <Input v-model="formItem.title" placeholder="请输入赛事标题" />
      </FormItem>
      <FormItem label="赛事简介">
        <Input
          v-model="formItem.content"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 5 }"
          placeholder="请输入赛事简介"
        />
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="590"
          :height="340"
          :fixed-number="[590, 340]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="类型">
        <Select
          v-model="formItem.other_data.match_type"
          placeholder="请选择跳转类型"
          @on-change="onSelectChange"
        >
          <Option :value="1">文章详情</Option>
          <Option :value="2">页面跳转</Option>
          <Option :value="3">分赛事</Option>
        </Select>
      </FormItem>
      <!-- 文章详情 -->
      <FormItem
        v-if="formItem.other_data.match_type === 1"
        :key="1201"
        label="选择文章"
        placeholder="请选择文章"
      >
        <Select v-model="formItem.other_data.article_id" filterable>
          <Option
            v-for="(items, index) in articleList"
            :key="index"
            :value="items.value"
            >{{ items.label }}</Option
          >
        </Select>
      </FormItem>
      <!-- 页面跳转 -->
      <div v-if="formItem.other_data.match_type === 2">
        <FormItem :key="1202" label="PC跳转链接" :rules="ruleValidate.httpUrl">
          <Input
            v-model="formItem.other_data.skip.pc_url"
            placeholder="请输入PC端页面跳转链接"
          />
        </FormItem>
        <FormItem
          :key="1203"
          label="移动端跳转链接"
          :rules="ruleValidate.httpUrl"
        >
          <Input
            v-model="formItem.other_data.skip.web_url"
            placeholder="请输入移动端页面跳转链接"
          />
        </FormItem>
      </div>

      <!-- 分赛事 -->
      <div v-if="formItem.other_data.match_type === 3">
        <FormItem :key="1204" label="添加分赛事">
          <Button
            v-if="formItem.other_data.branch.length === 0"
            @click="onformChildItemAdd(0)"
            >添加</Button
          >
          <div
            v-for="(items, index) in formItem.other_data.branch"
            :key="index"
            class="subevents-list"
          >
            <div class="titleandbtn-box">
              <div class="title-box">赛事{{ index + 1 }}</div>
              <div class="btn-box">
                <a
                  v-if="index < formItem.other_data.branch.length - 1"
                  class="btn"
                  @click="onformChildItemDown(index)"
                  >下移</a
                >
                <a
                  v-if="
                    index <= formItem.other_data.branch.length - 1 &&
                      formItem.other_data.branch.length > 1 &&
                      index >= 1
                  "
                  class="btn"
                  @click="onformChildItemUp(index)"
                  >上移</a
                >
                <a class="btn" @click="onformChildItemAdd(index)">向下添加</a>
                <a class="btn" @click="onformChildItemDel(index)">删除</a>
              </div>
            </div>
            <div class="subevents-form-box">
              <FormItem
                label="赛事标题"
                :prop="`other_data.branch[${index}].title`"
                :rules="ruleValidate.title"
              >
                <Input
                  v-model="items.title"
                  placeholder="请输入赛事标题"
                  style="width:350px;"
                />
              </FormItem>
              <FormItem
                label="封面图"
                style="margin-top:20px;"
                :prop="`other_data.branch[${index}].head_img_url`"
                :rules="ruleValidate.head_img_url"
              >
                <CustomVueCropper
                  :id="String(index)"
                  :value="items.head_img_url"
                  :fixed="true"
                  :is-operation-location="true"
                  :width="1440"
                  :height="360"
                  :fixed-number="[1440, 360]"
                  @onUploadImage="onUploadImage"
                />
              </FormItem>
              <FormItem
                label="赛事类型"
                style="margin-top:20px;"
                :prop="`other_data.branch[${index}].type`"
                :rules="ruleValidate.childType"
              >
                <Select v-model="items.type" style="width:350px">
                  <Option :value="1">文章详情</Option>
                  <Option :value="2">页面跳转</Option>
                </Select>
              </FormItem>
              <!-- 文章详情 -->
              <div v-if="items.type === 1">
                <FormItem
                  label="选择文章"
                  placeholder="请选择文章"
                  style="margin-top:20px;"
                  :prop="`other_data.branch[${index}].article_id`"
                  :rules="ruleValidate.childArticle"
                >
                  <Select
                    v-model="items.article_id"
                    style="width:350px"
                    filterable
                  >
                    <Option
                      v-for="(items, index) in articleList"
                      :key="index"
                      :value="items.value"
                      >{{ items.label }}</Option
                    >
                  </Select>
                </FormItem>
              </div>

              <!-- 页面跳转 -->
              <div v-if="items.type === 2">
                <FormItem
                  label="PC跳转链接"
                  style="margin-top:20px;"
                  :prop="`other_data.branch[${index}].skip.pc_url`"
                  :rules="ruleValidate.httpUrl"
                >
                  <Input
                    v-model="items.skip.pc_url"
                    placeholder="请输入PC端页面跳转链接"
                    style="width:350px;"
                  />
                </FormItem>
                <FormItem
                  label="移动端跳转链接"
                  style="margin-top:20px;"
                  :prop="`other_data.branch[${index}].skip.web_url`"
                  :rules="ruleValidate.httpUrl"
                >
                  <Input
                    v-model="items.skip.web_url"
                    placeholder="请输入移动端页面跳转链接"
                    style="width:350px;"
                  />
                </FormItem>
              </div>
            </div>
          </div>
        </FormItem>
      </div>
      <FormItem style="margin-top:50px;">
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
  </div>
</template>

<script>
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import { getView, GetListData } from '@/api/content'

import util from '@/libs/util'

const check_url = (rule, value, callback) => {
  console.log(/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value))
  if (!/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value)) {
    callback(new Error('链接必须以http://或https://开头'))
  } else {
    callback()
  }
}

export default {
  components: { CustomVueCropper, footerButton },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },

  data() {
    return {
      formItem: {
        title: '', // 赛事标题
        weight: 999, // 排序
        content: '', // 赛事简介
        head_img: '', // 封面图
        other_data: {
          content_model: '', // 模块分类
          match_type: '', // 云赛事类型 1 文章详情 2 页面跳转 3 分赛事
          article_id: '',
          skip: {
            pc_url: '', // PC跳转地址
            web_url: '' // 移动端跳转地址
          },
          branch: []
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        content: [
          {
            required: true,
            message: '请输入赛事简介',
            trigger: 'blur'
          }
        ],
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        head_img_url: [
          {
            required: true,
            message: '请选择分赛事封面',
            trigger: 'blur'
          }
        ],
        childType: [
          {
            required: true,
            message: '请选择类型',
            trigger: 'blur',
            type: 'number'
          }
        ],
        childArticle: [
          {
            required: true,
            message: '请选择文章',
            trigger: 'blur'
          }
        ],
        'other_data.match_type': [
          {
            required: true,
            message: '请选择类型',
            trigger: 'blur',
            type: 'number'
          }
        ],
        'other_data.article_id': [
          {
            required: true,
            message: '请选择文章',
            trigger: 'blur'
          }
        ],
        httpUrl: [
          {
            required: true,
            validator: check_url,
            trigger: 'blur'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 1,
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      loading: false,
      articleList: [],
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: ''
    }
  },
  created() {
    const that = this
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 10,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    if (this.id !== '') {
      this.loadInfo()
    }
    this.getArticleList()
  },
  methods: {
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 类型选择值发生变化
    onSelectChange(index) {
      if (index === 3) {
        const obj = {
          title: '', // 分赛事标题
          head_img_url: '', // 分赛事封面
          type: '', // 分赛事类型  1 文章详情 2 页面跳转
          article_id: '',
          skip: {
            pc_url: '', // PC跳转地址
            web_url: '' // 移动端跳转地址
          }
        }
        this.formItem.other_data.branch = [obj]
      }
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
          if (key === 'httpUrl') {
            this.ruleValidate[key][0].validator = check_url
          }
        })
      } else {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = key === 'title'
          this.ruleValidate[key][0].validator = null
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 获取文章列表
    getArticleList() {
      GetListData({
        content_type: 12,
        tab_type: 1,
        p: 1,
        page_size: 3000,
        lang_tag: this.langEn
      }).then((res) => {
        if (res.ret === 0) {
          res.data.list.map((items, index) => {
            this.articleList.push({
              label: items.title,
              value: items.id
            })
          })
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // 分赛事删除
    onformChildItemDel(index) {
      this.formItem.other_data.branch.splice(index, 1)
    },
    // 向下添加数据
    onformChildItemAdd(index) {
      const obj = {
        title: '', // 分赛事标题
        head_img_url: '', // 分赛事封面
        type: '', // 分赛事类型  1 文章详情 2 页面跳转
        article_id: '',
        skip: {
          pc_url: '', // PC跳转地址
          web_url: '' // 移动端跳转地址
        }
      }
      this.formItem.other_data.branch.splice(index + 1, 0, obj)
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.branch, index, index - 1)
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.branch, index, index + 1)
    },
    // 获取详情数据
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'cloud_match'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          res.data.other_data.match_type = res.data.other_data.match_type
            ? parseInt(res.data.other_data.match_type)
            : ''
          if (!res.data.other_data.branch) {
            res.data.other_data.branch = []
          }
          if (res.data.other_data.branch.length > 0) {
            res.data.other_data.branch.map((items) => {
              items.type = items.type ? parseInt(items.type) : ''
            })
          }
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 裁截图片后
    onUploadImage(url, name) {
      if (name === 'head_img') {
        this.formItem[name] = url
      } else {
        this.formItem.other_data.branch[parseInt(name)].head_img_url = url
      }
    }
  }
}
</script>

<style lang="less">
.ivu-select-dropdown-list {
  max-width: 800px !important;
}

.color_grey {
  color: #999;
}
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;

  .ivu-form-item-error-tip {
    left: 140px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
</style>
