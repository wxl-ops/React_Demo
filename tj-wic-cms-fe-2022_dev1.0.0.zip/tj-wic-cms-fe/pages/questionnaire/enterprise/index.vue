<template>
  <div class="content-list-page">
    <div class="search-container">
      <div class="sc-left">
        <!-- <Input
          v-model="queryData.keyword"
          :maxlength="100"
          class="inputList inputList2"
          placeholder="请输入关键字"
          style="width: 300px;"
        /> -->
        <Select
          v-model="queryData.source"
          style="width:300px"
          placeholder="请选择来源"
        >
          <Option
            v-for="item in sourceList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </div>
      <div class="sc-right">
        <Button
          type="primary"
          style="margin-left: 10px;"
          @click="onPageSearch()"
          >查询</Button
        >
        <Button @click="clearSearch()">清空</Button>
      </div>
    </div>
    <div class="form-container">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
        @on-selection-change="selectChange"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="Number(pagination.current_page)"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { enterprise, questionnaireDelete } from '@/api/content'
export default {
  name: 'ContentListPage',
  props: {
    contentType: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      // 表格数据加载
      tableLoading: true,
      // 是否显示表格数据
      showTable: false,
      // tabs状态
      tabIndex: 0, // 当前状态
      // 查询相关
      queryData: {
        tab_type: 1,
        keyword: '',
        p: 1,
        page_size: 10,
        source: '',
        guest_type: '',
        partner_type: '',
        news_type: '',
        schedule_type: '',
        type: '',
        draft_status: 2
      },
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      // 选择列表
      selectListId: '',
      // 列表数据
      listData: [
        {
          name: '111',
          head_img: ''
        }
      ],
      tableColumns: [
        // {
        //   title: '企业名称',
        //   key: 'username',
        //   minWidth: 160
        // },
        { title: '来源', key: 'source', align: 'center', minWidth: 80 },
        {
          title: '提交时间',
          key: 'create_time',
          align: 'center',
          minWidth: 150
        },
        {
          title: '操作',
          key: 'action',
          fixed: 'right',
          align: 'center',
          minWidth: 150,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: 'inline-block'
                  },
                  on: {
                    click: () => {
                      this.goEditPage(params.row.id)
                    }
                  }
                },
                '查看'
              )
              // h(
              //   'Button',
              //   {
              //     props: { size: 'small', type: 'text' },
              //     style: {
              //       color: '#2d8cf0',
              //       display: 'inline-block'
              //     },
              //     on: {
              //       click: () => {
              //         this.deleteData(params.row.id)
              //       }
              //     }
              //   },
              //   '删除'
              // )
            ])
          }
        }
      ],
      typeList: [],
      sourceList: [
        {
          label: '全部',
          value: 'all'
        },
        {
          label: 'PC',
          value: 'pc'
        },
        {
          label: 'H5',
          value: 'h5'
        },
        {
          label: '小程序',
          value: 'mini'
        }
      ]
    }
  },
  watch: {},
  beforeDestroy() {},
  created() {
    const { p } = this.$route.query
    this.queryData.p = p || 1
    this.resize()
    this.getListData()
  },

  methods: {
    // 查询事件
    onPageSearch() {
      this.queryData.p = 1
      this.getListData()
    },
    // 跳转编辑页面
    goEditPage(id) {
      const goPath = {
        name: 'questionnaire-enterprise-detail',
        query: {
          p: this.queryData.p,
          id
        }
      }
      this.$router.push(goPath)
    },
    // 获取表格数据
    getListData() {
      this.tableLoading = true
      this.listData = []
      this.selectListId = ''
      const params = {
        keyword: this.queryData.keyword,
        source: this.queryData.source === 'all' ? '' : this.queryData.source,
        p: this.queryData.p,
        page_size: this.queryData.page_size
      }
      // 获取列表数据
      enterprise(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          this.listData = res.data.list
          this.pagination = res.data.pagination
        }
      })
    },
    deleteData(id) {
      // 删除之前弹窗确认
      this.$Modal.confirm({
        title: '删除数据',
        content: `确定要删除数据吗?`,
        closable: true,
        onOk: () => {
          this.tableLoading = true
          questionnaireDelete({
            id
          }).then((res) => {
            if (res.ret === 0) {
              this.$Message.success(`删除成功`)
              this.getListData()
            } else {
              this.tableLoading = false
              this.$Message.error(res.msg || '操作失败')
            }
          })
        }
      })
    },
    // 清空表单状态
    clearSearch() {
      this.queryData.p = 1
      this.queryData.page_size = this.pageSizeOpts[0]
      this.queryData.keyword = ''
      this.queryData.source = ''
      this.getListData()
    },
    // 选择数据
    selectChange(select) {
      let idStr = ''
      for (const i in select) {
        idStr += (idStr !== '' ? ',' : '') + select[i].id
      }
      this.selectListId = idStr
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.queryData.p = page
      this.getListData()
    },
    PageSizeChange(pageSize) {
      this.queryData.page_size = pageSize
      this.queryData.p = 1
      this.getListData()
    },
    // 自适应大小
    resize() {
      const listHeight = 74
      const searchHeight = 335
      let listNum = ((window.innerHeight - searchHeight) / listHeight) >> 0
      if (listNum < 3) {
        listNum = 3
      }
      this.pageSizeOpts[0] = listNum
      this.pageSizeOpts[1] = listNum * 2
      this.pageSizeOpts[2] = listNum * 3
      this.queryData.page_size = listNum
    }
  }
}
</script>
<style lang="less">
.content-list-page {
  padding-bottom: 40px;
  padding-top: 0px !important;
  .ivu-tabs {
    padding-top: 0px;
    .ivu-tabs-nav-right {
      height: 44px;
      line-height: 40px;
      button {
        margin-left: 10px;
      }
    }
  }
  .ivu-table-overflowX {
    &::-webkit-scrollbar {
      height: 16px;
      width: 4px;
    }
    &::-webkit-scrollbar-track {
      visibility: hidden; /* doesn't seem to work */
    }
    &::-webkit-scrollbar-thumb {
      background: #dcdee2;
    }
    &::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 0, 0, 0.2);
    }
    &::-webkit-scrollbar:window-inactive {
      visibility: hidden;
    }
  }
  .ivu-tabs-bar {
    margin-bottom: 0px;
  }
  .ivu-table-column-center {
    .ivu-table-cell {
      padding: 0px 4px;
    }
  }
  .ivu-form-item-label {
    font-weight: bold;
    color: #464c5b;
    font-size: 14px;
  }
  .ivu-form-item-content {
    font-size: 14px;
  }
  .ivu-tabs-nav-container {
    .ivu-tabs-tab {
      padding: 12px 16px;
    }
  }
  .search-container {
    margin-top: 20px;
    height: 32px;
    .sc-left {
      float: left;
      width: calc(~'100% - 170px');
      .inputList {
        width: calc(~'100% - 245px');
        margin-right: 10px;
      }
      .inputList2 {
        width: calc(~'100% - 469px');
        margin-right: 10px;
      }
    }
    .sc-right {
      float: right;
      button {
        margin-left: 20px;
      }
    }
  }
  .form-container {
    clear: both;
    margin-top: 20px;
    &-page {
      margin: 10px 0;
      line-height: 32px;
    }
  }
  .demo-drawer-footer {
    width: 100%;
    /*position: absolute;*/
    /*bottom: 0;*/
    /*left: 0;*/
    border-top: 1px solid #e7e8eb;
    padding: 20px 16px;
    text-align: right;
    background: #fff;
    button {
      margin-left: 10px;
    }
  }
  .ticket-list {
    .list-item {
      .i-title {
        display: inline-block;
        width: 80px;
        text-align: right;
        margin-right: 35px;
      }
      .i-check {
        color: #ff9901;
      }
      .i-check-btn {
        margin-left: 43px;
        color: #0252db;
        cursor: pointer;
      }
    }
  }
}
</style>
