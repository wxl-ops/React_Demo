<template>
  <div class="container">
    <table class="table">
      <tr>
        <td>姓名</td>
        <td>{{ detail.username }}</td>
        <td>来源</td>
        <td>{{ detail.source }}</td>
      </tr>
      <tr>
        <td>电话号码</td>
        <td>{{ detail.mobile }}</td>
        <td>提交时间</td>
        <td>{{ detail.create_time }}</td>
      </tr>
    </table>

    <div class="title">
      问卷还原
    </div>
    <div class="content">
      <div v-for="(item, index) in list" :key="index" class="box">
        <div class="topic">{{ index + 1 }}.{{ item.topic }}</div>
        <div class="answer">{{ item.answer }}</div>
      </div>
    </div>
    <Button type="default" class="btn" @click="goBack">
      返回
    </Button>
  </div>
</template>
<script>
import { questionnaireDetail } from '@/api/content'
export default {
  components: {},
  data() {
    return {
      detail: {
        name: '张小花',
        source: '小程序',
        tel: '15123767389',
        update_time: '2017-07-19 14:48:38'
      },
      list: [
        {
          title: '您是通过什么渠道知道第四届世界智能大会？',
          content: '网络媒体'
        }
      ],
      p: '',
      fromorigin: ''
    }
  },
  beforeDestroy() {},
  created() {
    const { id, p } = this.$route.query
    this.p = p
    this.fromorigin = this.$route.query.fromorigin || ''
    let params = {}
    if (this.fromorigin === 'user') {
      params = { uid: id }
    } else {
      params = { id }
    }
    questionnaireDetail(params).then((response) => {
      console.log(response.data)
      this.detail = response.data
      this.list = response.data.answer
    })
  },

  methods: {
    goBack() {
      // const goPath = {
      //   name: 'questionnaire-naire',
      //   query: {
      //     p: this.p
      //   }
      // }
      this.$router.go('-1')
    }
  }
}
</script>
<style lang="less" scoped>
.table {
  border-collapse: collapse;
  width: 100%;
  td {
    border: 1px solid #f5f7f9;
    height: 40px;
  }
  tr {
    td {
      padding-left: 20px;
      &:nth-of-type(1),
      &:nth-of-type(3) {
        background-color: #f9fafc;
        text-align: right;
        padding-right: 20px;
      }
    }
  }
}
.title {
  font-size: 16px;
  margin-top: 60px;
  margin-bottom: 20px;
  color: #666;
  font-weight: bold;
}
.content {
  .box {
    border: 1px solid #f5f7f9;
    padding: 6px 10px;
    margin-bottom: 20px;
    &:hover {
      box-shadow: 0 0 5px #999;
    }
    .topic {
      font-size: 16px;
      font-weight: bold;
      color: #666;
    }
    .answer {
      font-size: 12px;
      color: #999;
      margin-top: 10px;
      word-break: break-all;
    }
  }
}
.btn {
  margin: 20px auto;
}
</style>
