<template>
  <div>
    <h1>首页</h1>
  </div>
</template>

<script>
export default {
  layout: '',
  components: {},
  data() {
    return {}
  },
  created() {},

  methods: {}
}
</script>
<style lang="less" scope></style>
