<template>
  <create-page lang-en="en"></create-page>
</template>

<script>
import createPage from '../zh/edit'

export default {
  components: {
    createPage
  },
  data() {
    return {}
  }
}
</script>

<style lang="less" scoped></style>
