<template>
  <div class="page-index">
    <list-page :content-type="contentType"></list-page>
  </div>
</template>

<script>
import ListPage from '~/components/content/listPage.vue'
export default {
  components: {
    ListPage
  },
  data() {
    return {
      contentType: 22
    }
  }
}
</script>

<style lang="less"></style>
