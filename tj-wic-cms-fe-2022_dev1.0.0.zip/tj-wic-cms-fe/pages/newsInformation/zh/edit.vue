<template>
  <div class="form">
    <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
      基本信息
    </h3>
    <Form ref="form" :model="formItem" :rules="rules" :label-width="140">
      <FormItem prop="title" label="资讯标题：">
        <Input v-model="formItem.title" placeholder="请输入资讯标题" />
      </FormItem>
      <FormItem prop="other_data.type_id" label="资讯类型：">
        <Select v-model="formItem.other_data.type_id">
          <Option
            v-for="(item, index) in typeOptions"
            :key="index"
            :value="item.id"
          >
            {{ item.title }}-{{ item.en_title }}
          </Option>
        </Select>
      </FormItem>
      <FormItem label="资讯简介：">
        <Input
          v-model="formItem.other_data.news_content"
          type="textarea"
          placeholder="请输入资讯简介"
        />
      </FormItem>
      <FormItem prop="published_time" label="资讯发布时间：">
        <DatePicker
          v-model="formItem.publish_time"
          type="datetime"
          placement="bottom-start"
          format="yyyy-MM-dd HH:mm"
          placeholder="请选择发布时间"
          style="width: 200px"
          @on-change="dateChange"
        ></DatePicker>
      </FormItem>
      <FormItem prop="source" label="来源：">
        <Input v-model="formItem.source" placeholder="请输入来源" />
      </FormItem>
      <FormItem label="封面图：">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="580"
          :height="220"
          :fixed-number="[580, 220]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="资讯详情：">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <!-- <FormItem  label="二维码：">
            <canvas ref="canvas"></canvas>
          </FormItem> -->
        <!-- 优秀案例展示 -->
      <FormItem label="优秀案例：">
        <RadioGroup v-model="formItem.other_data.case_is_show" style="display:flex;">
          <Radio label="2">
            <span>不展示</span>
          </Radio>
          <Radio label="1" style="margin-left: 4px;">
          <span >
            展示
            <InputNumber
              v-model="formItem.other_data.case_weight"
              :min="1"
              :max="999"
              :precision="0"
              placeholder="请输入排序值"
              style="width:150px;display:inline-block;"
            />
            <span style="color: #999; line-height: 32px; display: inline-block;margin-left: 2px;">请输入1-999间的整数，输入数字越小，排序越靠前</span>
          </span>
          </Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="是否置顶：">
        <RadioGroup v-model="formItem.other_data.is_top">
          <Radio label="2">
            <span>不置顶</span>
          </Radio>
          <Radio label="1">
            <span>置顶</span>
          </Radio>
        </RadioGroup>
      </FormItem>
      <FormItem
        v-show="formItem.other_data.is_top === '1'"
        prop="weight"
        label="排序："
      >
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #999; line-height: 32px; display: inline-block;margin-left: 20px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem>
        <fotter-button
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        ></fotter-button>
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import QRCode from "qrcode";
import VueUeditorWrap from "vue-ueditor-wrap";
import showIframe from "../../../components/iframe";
import Setting from "@/wau.config";
import CustomVueCropper from "@/components/imgUpload/CustomVueCropper";
// import rEdit from '../../../components/editor1'
import { getView, GetListData } from "@/api/content";
import FotterButton from "~/components/content/fotterButton.vue";
import util from "@/libs/util";
// const check_html_content = (rule, value, callback) => {
//   if (value && /&--&/.test(value)) {
//     callback(new Error('请输入详情'))
//   } else {
//     callback()
//   }
// }

export default {
  components: {
    showIframe,
    // rEdit,
    FotterButton,
    VueUeditorWrap,
    CustomVueCropper,
  },
  props: {
    langEn: {
      type: String,
      default: "zh",
    },
  },
  data() {
    return {
      showPreviewDialog: false,
      mobilePreviewUrl: "",
      pcPreviewUrl: "",
      contentType: 22,
      confirm: false,
      loading: false,
      isPreview: false,
      formItem: {
        title: "",
        weight: 999,
        html_content: "",
        content: "",
        publish_time: "",
        published_time: "",
        other_data: {
          content: "",
          type_id: "",
          is_top: "2",
          case_weight: 1,
          case_is_show: "2",
          content_model: "news_info",
        },
        source: "",
        draft_status: "0",
        content_type: 22,
        tag: ["zh"],
        pc_preview: "",
        web_preview: "",
        head_img: "",
      },
      rules: {
        title: [
          {
            required: true,
            message: "请输入资讯标题",
            trigger: "blur",
          },
        ],
        weight: [
          {
            required: true,
            message: "请输入排序",
            trigger: "blur",
            type: "number",
          },
        ],
        "other_data.type_id": [
          { required: true, message: "请选择资讯类型", trigger: "blur" },
        ],
        "other_data.is_top": [
          { required: false, message: "请选择是否置顶", trigger: "blur" },
        ],
        "other_data.case_is_show": [
          {
            required: false,
            message: "请选择是否展示优秀案例",
            trigger: "blur",
          },
        ],
        "other_data.news_content": [
          { required: true, message: "请输入简介", trigger: "blur" },
        ],
        //优秀案例排序
        "other_data.case_weight": [
          { required: true, message: "请输入排序", trigger: "blur" },
        ],

        publish_time: [
          { required: false, message: "请选择发布时间", trigger: "blur" },
        ],
        head_img: [
          { required: true, message: "请上传封面图", trigger: "blur" },
        ],
        published_time: [
          { required: false, message: "请选择发布时间", trigger: "blur" },
        ],
        html_content: [
          { required: true, message: "请输入详情", trigger: "blur" },
        ],
      },
      typeOptions: [],
      id: "",
      tab_type: "",
      p: "",
      showIframeObj: {},
      uEditor: null,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: "100%",
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl,
      },
    };
  },
  created() {
    const { id, tab_type, p, content_type } = this.$route.query;
    this.id = id;
    this.tab_type = tab_type * 1;
    this.p = p * 1;
    this.contentType = content_type * 1;
    this.getType();
    if (id) this.getDetail(id);
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true;
    const that = this;
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: "editor",
        type: "image",
      };
    };
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: "editor",
        type: "video",
      };
    };
  },
  methods: {
    onUploadImage(url, name) {
      this.formItem[name] = url;
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case "image":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "";
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>';
            });
            this.uEditor.execCommand("insertHtml", insertHtml);
          }
          break;
        case "video":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "<span>&#12288;</span>";
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>';
            });
            this.uEditor.execCommand("insertHtml", insertHtml);
          }
          break;
        default:
          console.log("没有匹配的值");
          break;
      }
      this.showIframeObj.show = false;
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1;
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type,
      };
    },
    editorReady(e) {
      // 再次触发rEdit组件的watch
      this.uEditor = e;
    },
    onEditorChange(val) {
      this.formItem.html_content = val;
    },
    onConfirm() {
      this.confirm = false;
      this.$router.push({
        name: "newsInformation-type",
        query: {
          tab_type: this.tab_type,
          p: this.p,
        },
      });
    },
    onCancel() {
      this.confirm = false;
    },
    preview(val) {
      if (val) {
        window.open(val, "_blank");
      } else {
        this.$Message.error("暂不支持预览");
      }
    },
    cancel() {
      this.confirm = true;
    },
    dateChange(date) {
      this.formItem.published_time = date;
    },
    qrCode(url) {
      this.$nextTick(() => {
        QRCode.toCanvas(this.$refs.canvas, url, function(error) {
          if (error) console.error(error);
          console.log("success!");
        });
      });
    },
    getType() {
      GetListData({
        content_type: 21,
        tab_type: 1,
        p: 1,
        page_size: 10000,
      }).then((res) => {
        console.log(res);
        this.typeOptions = res.data.list;
      });
    },
    getDetail(id) {
      getView({
        tab_type: this.tab_type,
        _id: id,
      }).then((res) => {
        res.data.weight = res.data.weight ? parseInt(res.data.weight) : "";
        this.formItem = res.data;
      });
    },
    submitForm(submitType) {
      const keys = Object.keys(this.rules);
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn,
      };
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          if (
            key === "title" ||
            key === "other_data.type_id" ||
            key === "other_data.news_content" ||
            key === "head_img" ||
            key === "html_content"
          ) {
            this.rules[key][0].required = true;
            // if (key === 'html_content')
            // this.rules[key][0].validator = check_html_content
          }
          if (this.formItem.weight === "1") {
            this.rules.weight[0].required = true;
          } else {
            this.rules.weight[0].required = false;
          }
        });
      } else {
        keys.forEach((key) => {
          if (key === "title") {
            this.rules[key][0].required = true;
          } else {
            this.rules[key][0].required = false;
            this.rules[key][0].validator = null;
          }
        });
        console.log(this.rules);
      }
      this.$refs.form.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param);
        } else {
          this.$Message.error("请完善必填信息!");
        }
      });
    },
  },
};
</script>

<style lang="less" scoped></style>
