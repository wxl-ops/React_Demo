<template>
  <div class="form">
    <Form ref="form" :model="formItem" :rules="rules" :label-width="140">
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem prop="title" label="标题：">
        <Input v-model="formItem.title" placeholder="请输入标题" />
      </FormItem>
      <FormItem label="简介：">
        <Input v-model="formItem.content" placeholder="请输入简介" />
      </FormItem>
      <FormItem label="banner图：">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="1356"
          :height="486"
          :fixed-number="[1356, 486]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序：">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #999; line-height: 32px; display: inline-block;margin-left: 20px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="类型：">
        <Select
          v-model="formItem.other_data.hot_type"
          @on-change="handleChange"
        >
          <Option
            v-for="(item, index) in typeOptions"
            :key="index"
            :value="item.value"
          >
            {{ item.label }}
          </Option>
        </Select>
      </FormItem>
      <FormItem
        v-if="formItem.other_data.hot_type === '2'"
        prop="other_data.type_id"
        label="资讯类型："
      >
        <Select v-model="formItem.other_data.type_id" @on-change="changeType">
          <Option v-for="(item, index) in types" :key="index" :value="item.id">
            {{ item.title }}-{{ item.en_title }}
          </Option>
        </Select>
      </FormItem>
      <FormItem
        v-if="formItem.other_data.hot_type === '2'"
        prop="other_data.news_info_id"
        label="选择资讯："
      >
        <Select v-model="formItem.other_data.news_info_id" filterable>
          <!-- <Input
            placeholder="请输入关键字"
            @on-change="handleChangeInput($event)"
          /> -->
          <Option v-for="(item, index) in list" :key="index" :value="item.id">{{
            item.title
          }}</Option>
        </Select>
      </FormItem>
      <FormItem
        v-if="formItem.other_data.hot_type === '3'"
        label="PC官网链接："
      >
        <Input
          v-model="formItem.other_data.web_url"
          placeholder="请输入PC官网链接"
        />
      </FormItem>
      <FormItem
        v-if="formItem.other_data.hot_type === '3'"
        label="移动端官网链接："
      >
        <Input
          v-model="formItem.other_data.wap_url"
          placeholder="请输入移动端官网链接"
        />
      </FormItem>
      <FormItem>
        <fotter-button
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="preview"
        ></fotter-button>
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <show-iframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import ShowIframe from '~/components/iframe'
import util from '@/libs/util'
import { GetListData, getView } from '~/api/content'
import { getNewsType } from '@/api/common'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import FotterButton from '~/components/content/fotterButton.vue'
const check_url = (rule, value, callback) => {
  console.log(/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value))
  if (!/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value)) {
    callback(new Error('链接必须以http://或https://开头'))
  } else {
    callback()
  }
}

export default {
  components: { ShowIframe, CustomVueCropper, FotterButton },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: '',
      isPreview: false,
      contentType: 24,
      confirm: false,
      loading: false,
      rules: {
        title: [{ required: true, message: '请输入标题', trigger: 'change' }],
        head_img: [
          { required: true, message: '请上传banner图', trigger: 'change' }
        ],
        content: [{ required: true, message: '请输入简介', trigger: 'change' }],
        weight: [
          {
            required: true,
            message: '请输入排序 1-999',
            trigger: 'change',
            type: 'number'
          }
        ],
        'other_data.news_info_id': [
          { required: true, message: '请选择资讯', trigger: 'change' }
        ],
        'other_data.type_id': [
          { required: true, message: '请选择资讯类型', trigger: 'change' }
        ],
        'other_data.hot_type': [
          { required: true, message: '请选择类型', trigger: 'change' }
        ],
        'other_data.web_url': [
          {
            required: true,
            validator: check_url,
            // message: '请输入pc官网链接',
            trigger: 'change'
          }
        ],
        'other_data.wap_url': [
          {
            required: true,
            validator: check_url,
            // message: '请输入移动端官网链接',
            trigger: 'change'
          }
        ]
      },
      formItem: {
        title: '',
        head_img: '',
        content: '',
        weight: 999,
        type_title: '',
        other_data: {
          content_model: 'hot_news',
          type_id: '',
          hot_type: '',
          web_url: '',
          wap_url: '',
          news_info_id: ''
        },
        content_type: 24,
        tag: ['zh'],
        draft_status: '0',
        pc_preview: '',
        web_preview: ''
      },
      types: [],
      list: [],
      typeOptions: [
        {
          value: '1',
          label: '不跳转'
        }
      ],
      id: '',
      tab_type: '',
      p: '',
      showIframeObj: {}
    }
  },
  created() {
    const { id, tab_type, p, content_type } = this.$route.query
    this.id = id
    this.tab_type = tab_type * 1
    this.p = p * 1
    this.contentType = content_type * 1
    this.getType()
    this.getNewsType()
    if (id) this.getDetail(id)
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
  },
  methods: {
    handleChangeInput(event) {
      if (this.formItem.other_data.type_id === '') {
        this.$Message.warning('请先选择资讯类型')
        return
      }
      GetListData({
        content_type: 22,
        tab_type: 1,
        p: 1,
        search_title: event.target.value,
        search_type: this.formItem.other_data.type_id,
        lang_tag: this.langEn,
        page_size: 2000
      }).then((res) => {
        console.log(res, '这8副绝地反击第三')
        this.list = res.data.list
      })
    },
    changeType(type_id) {
      GetListData({
        content_type: 22,
        tab_type: 1,
        p: 1,
        search_type: type_id,
        lang_tag: this.langEn,
        page_size: 2000
      }).then((res) => {
        console.log(res, '这8副绝地反击第三')
        this.list = res.data.list
      })
    },
    getNewsType() {
      getNewsType().then((res) => {
        console.log(res, '这是我的嗯减肥豆浆粉都结束了')
        res.data.forEach((item) => {
          item.value = item.value + ''
        })
        this.typeOptions = res.data
      })
    },
    handleChange(value) {
      // const fields = this.$refs.form.fields
      const keys = Object.keys(this.rules)
      const arr = ['other_data.web_url', 'other_data.wap_url']
      const arr2 = ['other_data.type_id', 'other_data.news_info_id']
      keys.forEach((key) => {
        if (arr2.includes(key) && value === '3') {
          const key2 = key.split('.')
          this.formItem[key2[0]][key2[1]] = ''
        }
        if (arr.includes(key) && value === '2') {
          const key2 = key.split('.')
          this.formItem[key2[0]][key2[1]] = ''
          this.list = []
        }
      })
    },
    onUploadImage(url, name) {
      this.formItem[name] = url
    },
    getType() {
      GetListData({
        content_type: 21,
        tab_type: 1,
        p: 1,
        page_size: 10000,
        lang_tag: this.langEn
      }).then((res) => {
        console.log(res)
        this.types = res.data.list
      })
    },
    getDetail(id) {
      getView({
        tab_type: this.tab_type,
        _id: id,
        content_type: 24
      }).then((res) => {
        res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
        this.formItem = res.data
        GetListData({
          content_type: 22,
          tab_type: 1,
          p: 1,
          search_type: res.data.other_data.type_id,
          lang_tag: this.langEn,
          page_size: 2000
        }).then((res) => {
          console.log(res, '这8副绝地反击第三')
          this.list = res.data.list
        })
      })
    },
    // 监听上传后的值
    getSelectFile(type, list) {},
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    cancel() {
      this.confirm = true
    },
    onConfirm() {
      this.confirm = false
      this.$router.push({
        name: 'newsInformation-hotzh',
        query: {
          tab_type: this.tab_type,
          p: this.p
        }
      })
    },
    onCancel() {
      this.confirm = false
    },
    submitForm(submitType) {
      console.log('表单提交数据')
      console.log(this.formItem)
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.rules)
      if (submitType === 0) {
        keys.forEach((key) => {
          this.rules[key][0].required = true
          if (this.formItem.other_data.hot_type === '1') {
            if (key === 'other_data.web_url' || key === 'other_data.wap_url') {
              this.rules[key][0].required = false
              this.rules[key][0].validator = null
            }
            if (
              key === 'other_data.type_id' ||
              key === 'other_data.news_info_id'
            ) {
              this.rules[key][0].required = false
            }
          }
          if (this.formItem.other_data.hot_type === '2') {
            if (key === 'other_data.web_url' || key === 'other_data.wap_url') {
              this.rules[key][0].required = false
              this.rules[key][0].validator = null
            }
            if (
              key === 'other_data.type_id' ||
              key === 'other_data.news_info_id'
            ) {
              this.rules[key][0].required = true
            }
          }
          if (this.formItem.other_data.hot_type === '3') {
            if (
              key === 'other_data.type_id' ||
              key === 'other_data.news_info_id'
            ) {
              this.rules[key][0].required = false
            }
            if (key === 'other_data.web_url' || key === 'other_data.wap_url') {
              this.rules[key][0].required = true
              this.rules[key][0].validator = check_url
            }
          }
        })
      } else {
        keys.forEach((key) => {
          this.rules[key][0].required = key === 'title'
          if (key === 'other_data.web_url' || key === 'other_data.wap_url') {
            this.rules[key][0].required = false
            this.rules[key][0].validator = null
          }
        })
      }
      this.$refs.form.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    }
  }
}
</script>

<style lang="less" scoped></style>
