<template>
  <div class="page-index">
    <div class="content">
      <div class="title">
        基本信息
      </div>
      <div class="form">
        <Form ref="form" :model="formItem" :rules="rules">
          <FormItem :label-width="150" prop="title" label="新闻类型（中文）：">
            <Input
              v-model="formItem.title"
              placeholder="请输入新闻类型（中文）"
              maxlength="5"
              show-word-limit
            />
          </FormItem>
          <FormItem
            :label-width="150"
            prop="en_title"
            label="新闻类型（英文）："
          >
            <Input
              v-model="formItem.en_title"
              placeholder="请输入新闻类型（英文）"
              maxlength="20"
              show-word-limit
            />
          </FormItem>
          <FormItem :label-width="150" label="排序：">
            <InputNumber
              v-model="formItem.weight"
              :min="1"
              :max="999"
              :precision="0"
              placeholder="请输入排序值"
              style="width:150px;display:inline-block;"
            />
            <span
              style="color: #999; line-height: 32px; display: inline-block;margin-left: 20px;"
              >请输入1-999间的整数，输入数字越小，排序越靠前</span
            >
          </FormItem>
          <FormItem>
            <fotter-button
              :id="id"
              :loading="loading"
              :form="formItem"
              :content-type="contentType"
              :tab-type="tab_type"
              :p="p"
              @submitForm="submitForm"
              @submitPreview="preview"
            ></fotter-button>
          </FormItem>
        </Form>
      </div>
    </div>
  </div>
</template>

<script>
import { getView } from '~/api/content'
import FotterButton from '~/components/content/fotterButton.vue'
import util from '@/libs/util'

export default {
  components: {
    FotterButton
  },
  data() {
    return {
      contentType: 21,
      confirm: false,
      formItem: {
        title: '',
        en_title: '',
        weight: 999,
        html_content: '',
        other_data: {
          content_model: 'news_info_type'
        },
        draft_status: '0',
        content_type: 21
      },
      rules: {
        title: [
          {
            required: true,
            message: '请输入新闻类型（中文）',
            trigger: 'blur'
          }
        ],
        en_title: [
          {
            required: true,
            message: '请输入新闻类型（英文）',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序 1-999',
            trigger: 'blur',
            type: 'number'
          }
        ]
      },
      id: '',
      tab_type: '',
      loading: false,
      p: ''
    }
  },
  created() {
    const { id, tab_type, p } = this.$route.query
    this.id = id
    this.tab_type = tab_type * 1
    this.p = p * 1
    if (id) this.getDetail(id)
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
  },
  methods: {
    onConfirm() {
      this.confirm = false
      this.$router.push({
        name: 'newsInformation-type',
        query: {
          tab_type: this.tab_type,
          p: this.p
        }
      })
    },
    onCancel() {
      this.confirm = false
    },
    preview() {
      window.open(this.formItem.returnUrl, '_blank')
    },
    cancel() {
      this.confirm = true
    },
    getDetail(id) {
      getView({
        tab_type: this.tab_type,
        _id: id,
        content_type: this.contentType
      }).then((res) => {
        res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
        this.formItem = res.data
      })
    },
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType
      }
      const keys = Object.keys(this.rules)
      if (submitType === 0) {
        keys.forEach((key) => {
          this.rules[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          this.rules[key][0].required = key === 'title' || key === 'en_title'
        })
      }
      this.$refs.form.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.page-index {
  min-height: 100%;
  position: relative;
  padding: 0;

  .top-bar {
    position: fixed;
    top: 64px;
    left: 255px;
    padding-left: 30px;
    background-color: #fff;
    z-index: 10;
    width: 100%;
    height: 60px;
    line-height: 60px;

    span {
      &:first-child {
        color: #999;
      }
      &:last-child {
        color: #666;
      }
    }
  }

  .content {
    background-color: #fff;
    overflow: hidden;
    margin-left: 30px;
    margin-right: 30px;
    padding-left: 30px;
    padding-right: 30px;
  }

  .title {
    font-size: 16px;
    font-weight: bold;
    margin-top: 40px;
    margin-bottom: 30px;
  }

  .form {
    overflow: hidden;
  }

  /deep/ .fotterButton {
    margin-left: 150px;
  }
}
</style>
