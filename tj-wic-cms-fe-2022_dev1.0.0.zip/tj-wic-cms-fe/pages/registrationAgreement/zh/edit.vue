<template>
  <div class="form">
    <Form ref="formItem" :model="formItem" :rules="rules" :label-width="140">
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem prop="title" label="协议标题：">
        <Input v-model="formItem.title" placeholder="请输入协议标题" />
      </FormItem>
      <FormItem label="排序：">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="引用注册：">
        <RadioGroup v-model="formItem.other_data.is_quote">
          <Radio :label="1">是</Radio>
          <Radio :label="-1">否</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="协议内容：">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem>
        <footerButton
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import footerButton from '../../../components/content/fotterButton'
import showIframe from '../../../components/iframe'
import { getView } from '@/api/content'
import util from '@/libs/util'
import Setting from '@/wau.config'

export default {
  components: {
    showIframe,
    footerButton,
    VueUeditorWrap
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },

  data() {
    return {
      formItem: {
        title: '',
        weight: 999,
        html_content: '',
        other_data: {
          content_model: 'register_agreement',
          is_quote: -1
        }
      },
      rules: {
        title: [{ required: true, message: '请输入标题', trigger: 'change' }],
        weight: [
          {
            required: true,
            message: '请输入排序',
            trigger: 'change',
            type: 'number'
          }
        ],
        html_content: [
          { required: true, message: '请输入内容', trigger: 'change' }
        ]
      },
      loading: false,
      id: '',
      p: 1,
      tab_type: 1,
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      contentType: 1,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: ''
    }
  },
  created() {
    const { id, tab_type, p, content_type } = this.$route.query
    this.id = id || ''
    this.tab_type = tab_type * 1
    this.p = p * 1
    this.contentType = content_type * 1
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    const that = this
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }

    if (this.id !== '') {
      console.log('获取详情信息')
      this.loadInfo(id)
    }
  },
  methods: {
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 富文本组件初始化
    editorReady(e) {
      this.uEditor = e
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.rules)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.rules[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          this.rules[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    loadInfo(id) {
      getView({
        tab_type: this.tab_type,
        content_model: 'register_agreement',
        _id: id
      }).then((res) => {
        res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
        if (![-1, 1].includes(parseInt(res.data.other_data.is_quote))) {
          res.data.other_data.is_quote = -1
        } else {
          res.data.other_data.is_quote = parseInt(res.data.other_data.is_quote)
        }
        this.formItem = res.data
      })
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    }
  }
}
</script>

<style lang="less" scoped></style>
