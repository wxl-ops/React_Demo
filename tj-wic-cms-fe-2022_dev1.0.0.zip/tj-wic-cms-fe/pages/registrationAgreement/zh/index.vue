<template>
  <list-page :content-type="contentType"></list-page>
</template>

<script>
import listPage from '@/components/content/listPage'
import 'viewerjs/dist/viewer.css'

export default {
  name: 'ContentListPage',
  components: { listPage },
  props: {},
  data() {
    return {
      contentType: 1
    }
  }
}
</script>

<style lang="less" sope></style>
