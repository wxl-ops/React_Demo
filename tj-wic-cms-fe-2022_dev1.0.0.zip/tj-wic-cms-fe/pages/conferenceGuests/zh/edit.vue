<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="嘉宾姓名" prop="title">
        <Input v-model="formItem.title" placeholder="请输入嘉宾姓名" />
      </FormItem>
      <FormItem label="嘉宾类型" prop="other_data.guest_type">
        <Select v-model="formItem.other_data.guest_type">
          <Option
            v-for="(items, index) in typeList"
            :key="index"
            :value="items.value"
            >{{ items.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="228"
          :height="320"
          :fixed-number="[228, 320]"
          @onUploadImage="onUploadPosterImage"
        />
      </FormItem>
      <FormItem label="嘉宾简介">
        <Input
          v-model="formItem.content"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 5 }"
          placeholder="请输入嘉宾简介"
        />
      </FormItem>
      <FormItem label="嘉宾海报">
        <CustomVueCropper
          id="other_data.guest_img_url"
          :value="formItem.other_data.guest_img_url"
          :fixed="true"
          :is-operation-location="true"
          :width="456"
          :height="640"
          :fixed-number="[456, 640]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="嘉宾视频">
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.guest_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
      </FormItem>
      <FormItem label="详情页">
        <RadioGroup v-model="formItem.other_data.detail_page">
          <Radio :label="1">开启</Radio>
          <Radio :label="-1">关闭</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="嘉宾详情">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem>
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="submitPreview"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import showIframe from '@/components/iframe'
import VideoUpload from '@/components/videoUpload'
import { getGuestTypeList } from '@/api/common'
import { getView } from '@/api/content'
import util from '@/libs/util'
import Setting from '@/wau.config'

export default {
  components: {
    CustomVueCropper,
    showIframe,
    VideoUpload,
    footerButton,
    VueUeditorWrap
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },

  data() {
    return {
      formItem: {
        title: '', // 嘉宾姓名
        other_data: {
          guest_type: 1, // 嘉宾类型
          guest_img_url: '', // 嘉宾海报
          guest_video: {
            video_url: '', // 嘉宾视频
            video_img_url: ''
          },
          content_model: 'guest',
          detail_page: 1
        },
        weight: 999, // 排序
        head_img: '', // 封面图
        content: '', // 嘉宾简介
        html_content: '' // 嘉宾详情
      },
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入嘉宾姓名',
            trigger: 'blur'
          }
        ],
        'other_data.guest_type': [
          {
            required: true,
            message: '请选择嘉宾类型',
            trigger: 'blur',
            type: 'number'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        'other_data.guest_img_url': [
          {
            required: true,
            message: '请选择嘉宾海报',
            trigger: 'blur'
          }
        ],
        html_content: [
          {
            required: true,
            message: '请输入嘉宾详情',
            trigger: 'blur'
          }
        ],
        content: [
          {
            required: true,
            message: '请输入嘉宾简介',
            trigger: 'blur'
          }
        ]
      },
      typeList: [],
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 1,
      loading: false,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: ''
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    if (this.id !== '') {
      this.loadInfo()
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    const that = this
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 10,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }
    this.getGuestTypeList()
  },
  methods: {
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 富文本组件初始化
    editorReady(e) {
      this.uEditor = e
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          console.log(key)
          this.ruleValidate[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 预览
    submitPreview(formName) {
      console.log('预览预览。。。。')
    },
    // 获取详情信息
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'guest'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          res.data.other_data.detail_page = res.data.other_data.detail_page
            ? Number(res.data.other_data.detail_page)
            : 1
          res.data.other_data.guest_type = parseInt(
            res.data.other_data.guest_type
          )
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 获取嘉宾类型
    getGuestTypeList() {
      getGuestTypeList({}).then((res) => {
        if (res.ret === 0) {
          this.typeList = res.data
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // 裁截图片后
    onUploadPosterImage(url, name) {
      this.formItem.head_img = url
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.other_data.guest_img_url = url
    },
    // 选择文件
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.guest_video.video_url = url
        ? url[0].play_url
        : ''
      this.formItem.other_data.guest_video.video_img_url = url
        ? url[0].title_url
        : ''
    }
  }
}
</script>

<style lang="less"></style>
