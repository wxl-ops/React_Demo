<template>
  <cooperateListPage :content-type="contentType" />
</template>
<script>
import cooperateListPage from '@/components/content/listPage'
export default {
  components: {
    cooperateListPage
  },
  data() {
    return {
      contentType: 8
    }
  },
  created() {},

  methods: {}
}
</script>
