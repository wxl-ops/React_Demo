<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="嘉宾姓名" prop="title">
        <Input v-model="formItem.title" placeholder="请输入嘉宾姓名" />
      </FormItem>
      <FormItem label="一句话简介">
        <Input
          v-model="formItem.other_data.short_content"
          placeholder="请输入一句话简介"
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="228"
          :height="320"
          :fixed-number="[228, 320]"
          @onUploadImage="onUploadPosterImage"
        />
      </FormItem>
      <FormItem label="嘉宾简介">
        <Input
          v-model="formItem.content"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 5 }"
          placeholder="请输入嘉宾简介"
        />
      </FormItem>
      <FormItem label="嘉宾海报">
        <CustomVueCropper
          id="other_data.sapiens_img_url"
          :value="formItem.other_data.sapiens_img_url"
          :fixed="true"
          :is-operation-location="true"
          :width="456"
          :height="640"
          :fixed-number="[456, 640]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="嘉宾视频">
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.sapiens_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
      </FormItem>
      <FormItem label="嘉宾介绍">
        <Input
          v-model="formItem.html_content"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 5 }"
          placeholder="请输入嘉宾介绍"
        />
      </FormItem>
      <FormItem>
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
  </div>
</template>

<script>
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import VideoUpload from '@/components/videoUpload'
import { getView } from '@/api/content'
import util from '@/libs/util'

export default {
  components: {
    CustomVueCropper,
    VideoUpload,
    footerButton
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },

  data() {
    return {
      formItem: {
        title: '', // 嘉宾姓名
        other_data: {
          sapiens_img_url: '', // 嘉宾海报
          short_content: '', // 一句话简介
          sapiens_video: {
            video_url: '', // 嘉宾视频
            video_img_url: ''
          },
          content_model: 'sapiens_wise'
        },
        weight: 999, // 排序
        head_img: '', // 封面图
        content: '', // 嘉宾简介
        html_content: '' // 嘉宾详情
      },
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入嘉宾姓名',
            trigger: 'blur'
          }
        ],
        'other_data.short_content': [
          {
            required: true,
            message: '请输入一句话简介',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        'other_data.sapiens_img_url': [
          {
            required: true,
            message: '请选择嘉宾海报',
            trigger: 'blur'
          }
        ],
        'other_data.sapiens_video.video_url': [
          {
            required: true,
            message: '请选择嘉宾视频',
            trigger: 'blur'
          }
        ],
        html_content: [
          {
            required: true,
            message: '请输入嘉宾介绍',
            trigger: 'blur'
          }
        ],
        content: [
          {
            required: true,
            message: '请输入嘉宾简介',
            trigger: 'blur'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 1,
      loading: false,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: ''
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    if (this.id !== '') {
      this.loadInfo()
    }
  },
  methods: {
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          console.log(key)
          this.ruleValidate[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 获取详情信息
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'sapiens_wise'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 裁截图片后
    onUploadPosterImage(url, name) {
      this.formItem.head_img = url
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.other_data.sapiens_img_url = url
    },
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.sapiens_video.video_url = url
        ? url[0].play_url
        : ''
      this.formItem.other_data.sapiens_video.video_img_url = url
        ? url[0].title_url
        : ''
    }
  }
}
</script>

<style lang="less"></style>
