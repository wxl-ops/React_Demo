<template>
  <div class="page-index">
    <content-list-page :content-type="contentType"></content-list-page>
  </div>
</template>

<script>
import ContentListPage from '~/components/content/listPage'
export default {
  components: { ContentListPage },
  data() {
    return {
      contentType: 27
    }
  }
}
</script>

<style lang="less"></style>
