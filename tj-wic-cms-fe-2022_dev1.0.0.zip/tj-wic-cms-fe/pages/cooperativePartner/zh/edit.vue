<template>
  <div class="form">
    <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
      基本信息
    </h3>
    <Form ref="form" :model="formItem" :rules="rules" :label-width="140">
      <FormItem prop="title" label="合作伙伴名称：">
        <Input v-model="formItem.title" placeholder="请输入合作伙伴名称" />
      </FormItem>
      <FormItem prop="other_data.type_id" label="合作伙伴类型：">
        <Select v-model="formItem.other_data.type_id">
          <Option
            v-for="(item, index) in typeOptions"
            :key="index"
            :value="item.id"
          >
            {{ item.title }}-{{ item.en_title }}
          </Option>
        </Select>
      </FormItem>
      <FormItem label="封面图：">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="280"
          :height="120"
          :fixed-number="[280, 120]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="PC详情图：">
        <CustomVueCropper
          id="other_data.pc_details_img_url"
          :value="formItem.other_data.pc_details_img_url"
          :fixed="true"
          :is-operation-location="true"
          :width="878"
          :height="279"
          :fixed-number="[878, 279]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序：">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #999; line-height: 32px; display: inline-block;margin-left: 20px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="PC官网链接：">
        <Input
          v-model="formItem.other_data.web_url"
          placeholder="请输入PC官网链接"
        />
      </FormItem>
      <FormItem label="详情页">
        <RadioGroup v-model="formItem.other_data.detail_page">
          <Radio :label="1">开启</Radio>
          <Radio :label="-1">关闭</Radio>
        </RadioGroup>
      </FormItem>
      <!-- <FormItem prop="other_data.wap_url" label="移动端官网链接：">
        <Input
          v-model="formItem.other_data.wap_url"
          placeholder="请输入移动端官网链接"
        />
      </FormItem> -->
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        合作伙伴详情
      </h3>
      <FormItem label="合作伙伴详情：">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem>
        <fotter-button
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="preview"
        ></fotter-button>
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import showIframe from '../../../components/iframe'
import Setting from '@/wau.config'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import { GetListData, getView } from '~/api/content'
import util from '@/libs/util'
import FotterButton from '~/components/content/fotterButton.vue'
const check_url = (rule, value, callback) => {
  console.log(/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value))
  if (!/^(http|https):\/\/([\w.]+\/?)\S*/i.test(value)) {
    callback(new Error('链接必须以http://或https://开头'))
  } else {
    callback()
  }
}

export default {
  components: {
    showIframe,
    // rEdit,
    CustomVueCropper,
    FotterButton,
    VueUeditorWrap
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: '',
      isPreview: false,
      contentType: 27,
      confirm: false,
      formItem: {
        pc_preview: '',
        web_preview: '',
        title: '',
        weight: 999,
        html_content: '',
        content: '',
        head_img: '',
        publish_time: '',
        other_data: {
          pc_details_img_url: '',
          type_id: '',
          content_model: 'cooperative_partner',
          web_url: '',
          wap_url: '',
          detail_page: 1
        },
        tag: ['zh'],
        draft_status: '0'
      },
      rules: {
        title: [
          {
            required: true,
            message: '请输入伙伴类型名称',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序',
            trigger: 'blur',
            type: 'number'
          }
        ],
        'other_data.type_id': [
          { required: true, message: '请选择资讯类型', trigger: 'blur' }
        ],
        'other_data.web_url': [
          {
            required: true,
            validator: check_url,
            // message: '请输入pc官网链接',
            trigger: 'blur'
          }
        ],
        // 'other_data.wap_url': [
        //   {
        //     required: true,
        //     validator: check_url,
        //     // message: '请输入移动端官网链接',
        //     trigger: 'blur'
        //   }
        // ],
        head_img: [
          { required: true, message: '请上传banner图', trigger: 'blur' }
        ],
        'other_data.pc_details_img_url': [
          { required: true, message: '请上传PC详情图', trigger: 'blur' }
        ],
        html_content: [
          { required: true, message: '请输入合作伙伴详情', trigger: 'blur' }
        ]
      },
      typeOptions: [],
      id: '',
      tab_type: '',
      p: '',
      showIframeObj: {},
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      loading: false
    }
  },
  created() {
    const { id, tab_type, p, content_type } = this.$route.query
    this.id = id
    this.tab_type = tab_type * 1
    this.p = p * 1
    this.contentType = content_type * 1
    this.getType()
    if (id) this.getDetail(id)
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    const that = this
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }
  },
  methods: {
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            this.uEditor.execCommand('insertHtml', insertHtml)
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 上传图片
    selectFile(type, valObj) {
      console.log(type, valObj)
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    onUploadImage(url, name) {
      console.log(url, name)
      if (/\./.test(name)) {
        const names = name.split('.')
        this.formItem[names[0]][names[1]] = url
      } else {
        this.formItem[name] = url
      }
      // this.$refs.form.validateField(`${name}`)
    },
    editorReady(e) {
      // 再次触发rEdit组件的watch
      this.uEditor = e
    },
    onEditorChange(val) {
      this.formItem.html_content = val
    },
    onConfirm() {
      this.confirm = false
      this.$router.push({
        name: 'newsInformation-type',
        query: {
          tab_type: this.tab_type,
          p: this.p
        }
      })
    },
    onCancel() {
      this.confirm = false
    },
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    cancel() {
      this.confirm = true
    },
    dateChange(date) {
      this.formItem.published_time = date
    },
    getType() {
      GetListData({
        tab_type: 1,
        p: 1,
        page_size: 10000,
        content_type: 26
      }).then((res) => {
        console.log(res)
        this.typeOptions = res.data.list
      })
    },
    getDetail(id) {
      getView({
        tab_type: this.tab_type,
        _id: id
      }).then((res) => {
        res.data.other_data.detail_page = res.data.other_data.detail_page
          ? Number(res.data.other_data.detail_page)
          : 1
        res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
        const keys = Object.keys(res.data)
        const keys2 = Object.keys(res.data.other_data)
        keys.forEach((key) => {
          if (key !== 'other_data') {
            this.formItem[key] = res.data[key]
          }
        })
        keys2.forEach((key) => {
          this.formItem.other_data[key] = res.data.other_data[key]
        })
      })
    },
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.rules)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.rules[key][0].required = true
          if (key === 'other_data.web_url' || key === 'other_data.wap_url')
            this.rules[key][0].validator = check_url
        })
      } else {
        keys.forEach((key) => {
          if (key !== 'title') {
            this.rules[key][0].required = false
            this.rules[key][0].validator = null
          } else {
            this.rules[key][0].required = true
          }
        })
      }
      this.$refs.form.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    }
  }
}
</script>

<style lang="less" scoped></style>
