<template>
  <create-page langEn="en"></create-page>
</template>

<script>
import createPage from '../zh/edit'

export default {
  components: { createPage }
}
</script>

<style lang="less" scoped></style>
