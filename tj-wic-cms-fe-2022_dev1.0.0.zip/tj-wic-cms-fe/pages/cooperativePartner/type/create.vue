<template>
  <create-page></create-page>
</template>

<script>
import createPage from './edit'

export default {
  components: { createPage }
}
</script>

<style lang="less" scoped></style>
