<!--
 * @Author: const_ytl
 * @Date: 2022-04-06 10:40:56
 * @LastEditors: const_ytl
 * @LastEditTime: 2022-04-06 11:40:54
 * @Description: 投票详情
-->
<template>
  <contentVotePage />
</template>
<script>
import contentVotePage from '../zh/vote'
export default {
  components: {
    contentVotePage
  },
  data() {
    return {}
  },
  beforeDestroy() {},
  created() {},
  methods: {}
}
</script>
