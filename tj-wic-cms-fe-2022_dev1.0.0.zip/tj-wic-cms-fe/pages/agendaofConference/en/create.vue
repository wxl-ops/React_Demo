<template>
  <contentEditPage langEn="en" />
</template>
<script>
import contentEditPage from '../zh/edit'
export default {
  components: {
    contentEditPage
  },
  data() {
    return {}
  },
  beforeDestroy() {},
  created() {},
  methods: {}
}
</script>
