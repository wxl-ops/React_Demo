/* eslint-disable vue/valid-v-model */
<template>
  <!-- 大会日程列表中文编辑 -->
  <div>
    <Form
      ref="formItem"
      :model="formItem"
      :rules="ruleValidate"
      :label-width="140"
      label-colon
    >
      <h3 style="box-sizing: border-box; padding-left: 20px; line-height: 60px">
        基本信息
      </h3>
      <FormItem label="论坛标题" prop="title">
        <Input v-model="formItem.title" placeholder="请输入论坛标题" />
      </FormItem>
      <FormItem label="论坛类型" prop="other_data.schedule_type">
        <Select
          v-model="formItem.other_data.schedule_type"
          placeholder="请选择论坛类型"
        >
          <Option
            v-for="itemSchedule in scheduleTypeData"
            :key="String(itemSchedule.value)"
            :value="String(itemSchedule.value)"
            >{{ `${itemSchedule.label}` }}</Option
          >
        </Select>
      </FormItem>
      <FormItem label="论坛时间">
        <!-- <Input
          v-if="formItem.other_data.schedule_type == 1"
          v-model="formItem.other_data.time"
          placeholder="请输入论坛时间"
        /> -->
        <div v-for="(items, index) in formItem.other_data.time" :key="index">
          <DatePicker
            :value="items.date"
            type="date"
            placeholder="选择日期"
            style="width: 168px"
            @on-change="onDateChange(index, $event)"
          ></DatePicker
          ><TimePicker
            :value="items.time ? items.time.split('-') : ''"
            type="timerange"
            placement="bottom-end"
            placeholder="选择时间段"
            format="HH:mm"
            style="width: 168px"
            @on-change="onTimeChange(index, $event)"
          ></TimePicker>
          <Button @click="onOtherTimeAdd(index)">添加</Button>
          <Button
            v-if="formItem.other_data.time.length > 1"
            @click="onOtherTimeDel(index)"
            >删除</Button
          >
        </div>
      </FormItem>
      <FormItem label="投票时间">
        <Date-picker
          type="datetimerange"
          placeholder="选择日期和时间"
          v-model="formItem.other_data.vote_time"
          format="yyyy-MM-dd HH:mm:ss"
          @on-change="timeChange"
          style="width: 300px"
        >
        </Date-picker>
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width: 150px; display: inline-block"
        />
        <span
          style="
            color: #ccc;
            line-height: 32px;
            display: inline-block;
            margin-left: 10px;
          "
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="首页封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="386"
          :height="228"
          :fixed-number="[386, 228]"
          @onUploadImage="onUploadPosterImage"
        />
      </FormItem>
      <FormItem label="主办单位">
        <Input
          v-model="formItem.other_data.organizer"
          placeholder="请输入主办单位"
        />
      </FormItem>
      <FormItem label="论坛地址">
        <Input
          v-model="formItem.other_data.forum_address"
          placeholder="请输入论坛地址"
        />
      </FormItem>
      <FormItem label="主题">
        <Input v-model="formItem.other_data.theme" placeholder="请输入主题" />
      </FormItem>
      <FormItem label="直播类型">
        <Select
          v-model="formItem.other_data.live_type"
          placeholder="请选择直播类型"
        >
          <Option
            v-for="itemSchedule in liveTypeList"
            :key="itemSchedule.value"
            :value="itemSchedule.value"
            >{{ `${itemSchedule.label}` }}</Option
          >
          <!-- <Option :value="1">直播中台</Option>
          <Option :value="2">直播链接</Option>
          <Option :value="3">没有直播</Option> -->
        </Select>
      </FormItem>
      <div v-if="formItem.other_data.live_type === 1">
        <FormItem :key="1101" label="直播ID" prop="other_data.live.live_id">
          <Input
            v-model="formItem.other_data.live.live_id"
            placeholder="请输入直播ID"
          />
        </FormItem>
      </div>
      <!-- <div v-if="formItem.other_data.live_type === 1">
        <FormItem label="直播">
          <RadioGroup v-model="formItem.other_data.live_toggle">
            <Radio :label="-1">关闭</Radio>
            <Radio :label="1">开启</Radio>
          </RadioGroup>
        </FormItem>
      </div> -->
      <div v-if="formItem.other_data.live_type === 2">
        <FormItem
          :key="1102"
          label="直播地址"
          prop="other_data.live.live_url"
          :rules="ruleValidate.httpUrl"
        >
          <Input
            v-model="formItem.other_data.live.live_url"
            placeholder="请输入直播链接"
          />
        </FormItem>
        <FormItem :key="1103" label="H5直播地址">
          <Input
            v-model="formItem.other_data.live.live_h5_url"
            placeholder="请输入H5直播地址"
          />
        </FormItem>
        <FormItem
          :key="1104"
          label="直播开始时间"
          prop="other_data.live.live_start_time"
        >
          <DatePicker
            v-model="formItem.other_data.live.live_start_time"
            type="datetime"
            format="yyyy-MM-dd HH:mm"
            placeholder="请选择"
            style="width: 300px"
          ></DatePicker>
        </FormItem>
        <FormItem
          :key="1105"
          label="直播结束时间"
          prop="other_data.live.live_end_time"
        >
          <DatePicker
            v-model="formItem.other_data.live.live_end_time"
            type="datetime"
            format="yyyy-MM-dd HH:mm"
            placeholder="请选择"
            style="width: 300px"
          ></DatePicker>
        </FormItem>
        <FormItem
          :key="1106"
          label="封面图"
          prop="other_data.live.live_img_url"
        >
          <CustomVueCropper
            id="live_img_url"
            :value="formItem.other_data.live.live_img_url"
            :fixed="true"
            :is-operation-location="true"
            :width="1440"
            :height="360"
            :fixed-number="[1440, 360]"
            @onUploadImage="onUploadPosterImage"
          />
        </FormItem>
        <FormItem :key="1107" label="录播视频">
          <VideoUpload
            id="video_source"
            :value="
              formItem.other_data.live.live_record_video.live_record_video_url
            "
            :fixed="true"
            :is-operation-location="true"
            @onUploadVideo="onLiveUploadVideo"
          />
          <!-- <span>视频格式支持MP4，大小限制是500MB。</span> -->
        </FormItem>
      </div>
      <!-- <div > -->
      <FormItem
        v-if="
          formItem.other_data.live_type === 3 ||
          formItem.other_data.live_type === ''
        "
        :key="1108"
        label="论坛视频"
      >
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.camera_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
        <Input
          v-model="formItem.other_data.camera_video.video_url"
          placeholder="请输入视频链接"
        />
        <Input
          v-model="formItem.other_data.camera_video.video_img_url"
          placeholder="请输入视频封面图"
        />
        <!-- <span>视频格式支持MP4，大小限制是500MB。</span> -->
      </FormItem>
      <!-- </div> -->

      <!-- <Select
        v-model="formItem.other_data.liveroom_id"
        placeholder="请选择直播ID"
      >
        <Option
          v-for="itemSchedule in liveRoomList"
          :key="String(itemSchedule.id)"
          :value="String(itemSchedule.id)"
          >{{ `${itemSchedule.name}` }}</Option
        >
      </Select> -->
      <FormItem label="论坛简介" prop="html_content">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          key="1"
          @ready="editorReady"
        />
      </FormItem>
      <h3 style="box-sizing: border-box; padding-left: 20px; line-height: 60px">
        日程安排
      </h3>
      <FormItem label="主持人">
        <Input
          v-model="formItem.other_data.schedule.compere"
          placeholder="请输入主持人"
        />
      </FormItem>
      <FormItem label="日程安排" :label-width="140">
        <Button
          v-if="formItem.other_data.schedule.plan.length === 0"
          @click="onformChildItemPlanAdd(0)"
          >添加</Button
        >
        <div
          v-for="(item, index) in formItem.other_data.schedule.plan"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">日程{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.schedule.plan.length - 1"
                class="btn"
                @click="onformChildItemPlanDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.schedule.plan.length - 1 &&
                  formItem.other_data.schedule.plan.length > 1 &&
                  index >= 1
                "
                class="btn"
                @click="onformChildItemPlanUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemPlanAdd(index)">向下添加</a>
              <a class="btn" @click="onformChildItemPlanDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="时间 "
              :label-width="100"
              :rules="ruleValidate.schedule_plan_time"
            >
              <Input
                v-model="item.time"
                placeholder="请输入时间如: 09:00 - 16:00"
                style="width: 400px"
              />

              <!-- <Time-picker
                type="time"
                placeholder="请选择时间"
                v-model="item.time"
              ></Time-picker> -->
            </FormItem>
            <FormItem
              label="描述"
              :label-width="100"
              :rules="ruleValidate.schedule_plan_info"
              style="margin-top: 20px"
            >
              <Input
                v-model="item.info"
                placeholder="请输入描述"
                style="width: 400px"
              />
            </FormItem>
          </div>
        </div>
      </FormItem>
      <h3
        v-if="formItem.other_data.guest.length > 0"
        style="box-sizing: border-box; padding-left: 20px; line-height: 60px"
      >
        特邀嘉宾
      </h3>
      <FormItem label="特邀嘉宾" :label-width="140">
        <Button
          v-if="formItem.other_data.guest.length === 0"
          @click="onformChildItemGuestAdd(0)"
          >添加</Button
        >
        <div
          v-for="(item, index) in formItem.other_data.guest"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">嘉宾{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.guest.length - 1"
                class="btn"
                @click="onformChildItemgGuestDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.guest.length - 1 &&
                  formItem.other_data.guest.length > 1 &&
                  index >= 1
                "
                class="btn"
                @click="onformChildItemGuestUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemGuestAdd(index)"
                >向下添加</a
              >
              <a class="btn" @click="onformChildItemGuestDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="嘉宾 "
              :label-width="100"
              :rules="ruleValidate.guestId"
            >
              <Select
                v-model="item.id"
                style="width: 400px"
                placeholder="请选择嘉宾"
                filterable
              >
                <Option
                  v-for="(itemGuest, idxGuest) in guestListData"
                  :key="idxGuest"
                  :value="itemGuest.value"
                  >{{ itemGuest.label }}</Option
                >
              </Select>
            </FormItem>
            <FormItem
              label="演讲主题"
              :label-width="100"
              :rules="ruleValidate.guestTheme"
              style="margin-top: 20px"
            >
              <Input
                v-model="item.speech_theme"
                placeholder="请输入演讲主题"
                style="width: 400px"
              />
            </FormItem>
            <FormItem
              label="是否置顶"
              :label-width="100"
              style="margin-top: 20px"
            >
              <Button
                type="primary"
                v-if="Number(item.is_top) === -1"
                @click="isTop(index, true)"
                >置顶</Button
              >
              <Button type="primary" v-else @click="isTop(index, false)"
                >取消置顶</Button
              >
            </FormItem>
          </div>
        </div>
      </FormItem>
      <h3 style="box-sizing: border-box; padding-left: 20px; line-height: 60px">
        详细介绍
      </h3>
      <FormItem label="详细介绍" style="position: relative">
        <vue-ueditor-wrap
          v-model="formItem.other_data.forum"
          :config="editorConfig"
          key="2"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem style="margin-top: 50px">
        <footerButton
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="
          box-sizing: border-box;
          padding: 0 80px;
          display: flex;
          justify-content: space-between;
        "
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from "vue-ueditor-wrap";
import showIframe from "../../../components/iframe";
import footerButton from "../../../components/content/fotterButton";
import CustomVueCropper from "@/components/imgUpload/CustomVueCropper";
import VideoUpload from "@/components/videoUpload";
import { getView } from "@/api/content";
import { getGuestList, getScheduleType, getLiveTypeList } from "@/api/common";
import util from "@/libs/util";
import Setting from "@/wau.config";
const CON_UEDITOR = {}; // TODO 1 添加编辑的大容器
const check_url = (rule, value, callback) => {
  console.log(/^(https):\/\/([\w.]+\/?)\S*/i.test(value));
  if (!/^(https):\/\/([\w.]+\/?)\S*/i.test(value)) {
    callback(new Error("链接必须以https://开头"));
  } else {
    callback();
  }
};
const check_time_url = (rule, value, callback) => {
  let isEmpty = false;
  value.map((items, idx) => {
    if (!items.date) {
      isEmpty = true;
    } else if (!items.time) {
      isEmpty = true;
    }
  });
  if (isEmpty) {
    callback(new Error("请选择论坛日期"));
  } else {
    callback();
  }
};

export default {
  components: {
    VueUeditorWrap,
    VideoUpload,
    showIframe,
    footerButton,
    CustomVueCropper,
  },
  props: {
    langEn: {
      type: String,
      default: "zh",
    },
  },
  data() {
    return {
      guestListData: [],
      scheduleTypeData: [],
      formItem: {
        title: "",
        weight: 999,
        head_img: "",
        html_content: "", // 论坛简介
        other_data: {
          vote_time: [],
          vote_start_time: "",
          vote_end_time: "",
          content_model: "schedule",
          schedule_type: "", // 论坛类型
          // live_toggle: -1,
          time: [
            {
              date: "",
              time: "",
            },
          ], // 论坛时间
          camera_video: {
            video_url: "", // 视频地址
            video_img_url: "", // 视频封面
          },
          organizer: "", // 主办单位
          forum: "", // 详细介绍
          schedule: {
            compere: "", // 主持人
            plan: [],
          },
          guest: [],
          live_type: "", // 直播类型 直播类型 1 直播ID 2 直播地址 3 无直播
          live: {
            live_id: "", // 直播id
            live_url: "", // 直播地址
            live_h5_url: "", // h5直播地址
            live_img_url: "", // 直播封面图
            live_record_video: {
              live_record_video_url: "", // '直播录播视频',
              live_record_video_img_url: "", // '直播录播视频封面地址',
            }, // 直播录播视频
            live_start_time: "", // 直播开始时间
            live_end_time: "", // 直播结束时间
          },
        },
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: "请输入论坛标题",
            trigger: "blur",
          },
        ],
        weight: [
          {
            required: true,
            message: "请输入排序值",
            trigger: "blur",
            type: "number",
          },
        ],
        head_img: [
          {
            required: true,
            message: "请选择封面图",
            trigger: "blur",
          },
        ],
        "other_data.schedule_type": [
          {
            required: true,
            message: "请输入论坛类型",
            trigger: "change",
          },
        ],
        "other_data.time": [
          {
            required: true,
            trigger: "blur",
            validator: check_time_url,
            type: "array",
          },
        ],
        schedule_plan_time: [
          {
            required: true,
            message: "请输入时间",
            trigger: "blur",
          }
          // { pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/, message: '请输入正确的时间格式！如：09:00-' }
        ],
        schedule_plan_info: [
          {
            required: true,
            message: "请输入描述",
            trigger: "blur",
          },
        ],
        guestId: [
          {
            required: true,
            message: "请输入嘉宾",
            trigger: "blur",
          },
        ],
        guestTheme: [
          {
            required: true,
            message: "请输入演讲主题",
            trigger: "blur",
          },
        ],
        "other_data.forum": [
          {
            required: true,
            message: "请输入详细介绍",
            trigger: "blur",
          },
        ],
        "other_data.schedule.plan": [
          {
            required: true,
            message: "请填写日程安排",
            trigger: "blur",
            type: "array",
          },
        ],
        "other_data.guest": [
          {
            required: true,
            message: "请填写特邀嘉宾",
            trigger: "blur",
            type: "array",
          },
        ],
        "other_data.live.live_id": [
          {
            required: true,
            message: "请填写直播ID",
            trigger: "blur",
          },
        ],
        "other_data.live.live_start_time": [
          {
            required: true,
            message: "请填写直播开始时间",
            trigger: "blur",
            type: "date",
          },
        ],
        "other_data.live.live_end_time": [
          {
            required: true,
            message: "请填写直播结束时间",
            trigger: "blur",
            type: "date",
          },
        ],
        "other_data.live.live_img_url": [
          {
            required: true,
            message: "请选择封面图",
            trigger: "blur",
          },
        ],
        httpUrl: [
          {
            required: true,
            validator: check_url,
            trigger: "blur",
          },
        ],
      },
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: "",
        type: "",
      },
      contentType: 1,
      tab_type: 1,
      p: 1,
      loading: false,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: "100%",
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl,
      },
      uEditor: "",
      showPreviewDialog: false,
      mobilePreviewUrl: "",
      pcPreviewUrl: "",
      liveRoomList: [],
      liveTypeList: [],
    };
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : "";
    this.tab_type = this.$route.query.tab_type * 1;
    this.p = this.$route.query.p * 1;
    this.contentType = this.$route.query.content_type * 1;
    this.getGuestListData();
    this.getScheduleTypeData();
    this.getLiveTypeList();
    // this.getLiveRoomList()
    const that = this;
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function (e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "image",
      };
    };
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function (e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: "editor",
        type: "video",
      };
    };
    if (this.id !== "") {
      this.loadInfo();
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true;
  },
  destroyed() {},
  methods: {
    // 嘉宾置顶
    isTop(index, top) {
      if (top) {
        const list = this.formItem.other_data.guest;
        list.forEach((it, ind) => {
          if (ind === index) {
            it.is_top = 1;
          } else {
            it.is_top = -1;
          }
        });
        this.formItem.other_data.guest = list;
      } else {
        this.formItem.other_data.guest[index].is_top = -1;
      }
    },
    timeChange(e) {
      this.formItem.other_data.vote_time = e;
      this.formItem.other_data.vote_start_time = e[0];
      this.formItem.other_data.vote_end_time = e[1];
    },
    // 论坛时间删除
    onOtherTimeDel(index) {
      this.formItem.other_data.time.splice(index, 1);
    },
    // 论坛时间添加
    onOtherTimeAdd(index) {
      console.log(index);
      const obj = {
        date: "",
        time: "",
      };
      this.formItem.other_data.time.splice(index + 1, 0, obj);
    },
    // 获取直播类型
    getLiveTypeList() {
      getLiveTypeList().then((res) => {
        console.log(res);
        this.liveTypeList = res.data;
      });
    },
    // 裁截图片后
    onUploadPosterImage(url, name) {
      console.log(name);
      if (name === "head_img") {
        this.formItem.head_img = url;
      } else {
        this.formItem.other_data.live.live_img_url = url;
      }
    },
    // // 获取直播Id列表
    // getLiveRoomList() {
    //   const params = {
    //     content_type: 36,
    //     tab_type: 1,
    //     p: 1,
    //     page_size: 3000
    //   }
    //   GetListData(params).then((res) => {
    //     console.log(res)
    //     this.liveRoomList = res.data
    //   })
    // },
    // 论坛时间变化（2021-05-21）
    onDateChange(index, e) {
      console.log(e);
      console.log(index);
      this.formItem.other_data.time[index].date = e;
      console.log(this.formItem.other_data.time[index]);
    },
    // 论坛时间变化（ 09:00-12:00）
    onTimeChange(index, e) {
      console.log(e);
      console.log(index);
      if (e[0] && e[0]) {
        this.formItem.other_data.time[index].time = e[0] + "-" + e[1];
      } else {
        this.formItem.other_data.time[index].time = "";
      }

      console.log(this.formItem.other_data.time[index]);
    },
    preview(val) {
      if (val) {
        window.open(val, "_blank");
      } else {
        this.$Message.error("暂不支持预览");
      }
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {};
      CON_UEDITOR[e.uid].uEditor = e;
    },
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.camera_video.video_url = url
        ? url[0].play_url
        : "";
      this.formItem.other_data.camera_video.video_img_url = url
        ? url[0].title_url
        : "";
    },
    // 获取录播视频后
    onLiveUploadVideo(url, name) {
      this.formItem.other_data.live.live_record_video.live_record_video_url =
        url ? url[0].play_url : "";
      this.formItem.other_data.live.live_record_video.live_record_video_img_url =
        url ? url[0].title_url : "";
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0];
      return arr;
    },
    // 嘉宾下移
    onformChildItemgGuestDown(index) {
      this.swapArray(this.formItem.other_data.guest, index, index + 1);
    },
    // 嘉宾上移
    onformChildItemGuestUp(index) {
      this.swapArray(this.formItem.other_data.guest, index, index - 1);
    },
    // 嘉宾添加
    onformChildItemGuestAdd(index) {
      const obj = {
        id: "",
        guestTheme: "",
        is_top: -1,
      };
      this.formItem.other_data.guest.splice(index + 1, 0, obj);
    },
    // 嘉宾删除
    onformChildItemGuestDel(index) {
      this.formItem.other_data.guest.splice(index, 1);
    },
    // 日程安排下移
    onformChildItemPlanDown(index) {
      this.swapArray(this.formItem.other_data.schedule.plan, index, index + 1);
    },
    // 日程安排上移
    onformChildItemPlanUp(index) {
      this.swapArray(this.formItem.other_data.schedule.plan, index, index - 1);
    },
    // 日程安排添加
    onformChildItemPlanAdd(index) {
      const obj = {
        info: "",
        time: "",
      };
      this.formItem.other_data.schedule.plan.splice(index + 1, 0, obj);
    },
    // 日程安排删除
    onformChildItemPlanDel(index) {
      this.formItem.other_data.schedule.plan.splice(index, 1);
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn,
      };
      console.log(this.formItem.other_data.schedule_type);
      const keys = Object.keys(this.ruleValidate);
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          if (key === "httpUrl") {
            this.ruleValidate[key][0].validator = check_url;
          }
          if (key === "other_data.time") {
            this.ruleValidate[key][0].validator = check_time_url;
          }
          if (
            key === "other_data.live.live_start_time" ||
            key === "other_data.live.live_end_time"
          ) {
            this.ruleValidate[key][0] = {
              required: true,
              message: "请填写时间",
              trigger: "blur",
              type: "date",
            };
          }
          this.ruleValidate[key][0].required = true;
        });
      } else {
        keys.forEach((key) => {
          if (this.ruleValidate[key][0]) {
            this.ruleValidate[key][0].required = key === "title";
            this.ruleValidate[key][0].validator = null;
          }
          if (
            key === "other_data.live.live_start_time" ||
            key === "other_data.live.live_end_time"
          ) {
            delete this.ruleValidate[key][0];
          }
        });
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          // param.other_data.time.map((items) => {
          //   items.date = new Date(items.date)
          // })
          let isDateEmpty = false;
          this.formItem.other_data.time.map((items) => {
            console.log(items.time);
            console.log(items.date);
            if (items.time && !items.date) {
              isDateEmpty = true;
              console.log("false");
            }
          });
          if (isDateEmpty) {
            this.$Message.error("论坛时间:时间段有值日期必选!");
            return;
          }
          util.editSaveContent(this, submitType, param);
        } else {
          this.$Message.error("请完善必填信息!");
        }
      });
    },
    // 获取详情信息
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : "";
          // res.data.other_data.live_toggle = res.data.other_data.live_toggle
          //   ? Number(res.data.other_data.live_toggle)
          //   : -1
          res.data.other_data.vote_time = [
            res.data.other_data.vote_start_time,
            res.data.other_data.vote_end_time,
          ];
          res.data.other_data.live_type = res.data.other_data.live_type
            ? parseInt(res.data.other_data.live_type)
            : "";
          if (!res.data.other_data.live) {
            res.data.other_data.live = {
              live_id: "", // 直播id
              live_url: "", // 直播地址
              live_h5_url: "", // h5直播地址
              live_img_url: "", // 直播封面图
              live_record_video: {
                live_record_video_url: "", // '直播录播视频',
                live_record_video_img_url: "", // '直播录播视频封面地址',
              }, // 直播录播视频
              live_start_time: "", // 直播开始时间
              live_end_time: "", // 直播结束时间
            };
          }
          if (!res.data.other_data.live.live_record_video) {
            res.data.other_data.live.live_record_video = {
              live_record_video_url: "", // '直播录播视频',
              live_record_video_img_url: "", // '直播录播视频封面地址',
            };
          }
          if (res.data.other_data.live.live_start_time) {
            res.data.other_data.live.live_start_time = new Date(
              res.data.other_data.live.live_start_time
            );
          }
          if (res.data.other_data.live.live_end_time) {
            res.data.other_data.live.live_end_time = new Date(
              res.data.other_data.live.live_end_time
            );
          }
          console.log(typeof res.data.other_data.time);
          // eslint-disable-next-line valid-typeof
          if (typeof res.data.other_data.time !== "object") {
            res.data.other_data.time = [
              {
                date: "",
                time: "",
              },
            ];
          }
          if (!res.data.other_data.guest) {
            res.data.other_data.guest = [];
          } else {
            const list = res.data.other_data.guest;
            list.forEach((item) => {
              if (item.is_top === undefined) {
                item.is_top = -1;
              }
            });
            res.data.other_data.guest = list;
          }
          if (!res.data.other_data.schedule.plan) {
            res.data.other_data.schedule.plan = [];
          }
          this.formItem = res.data;
        } else {
          this.$Message.error(res.msg || "读取数据错误");
        }
      });
    },
    // 获取特邀嘉宾
    getGuestListData() {
      getGuestList({
        tag: this.langEn,
      }).then((res) => {
        this.guestListData = res.data;
      });
    },
    // 获取论坛类型
    getScheduleTypeData() {
      getScheduleType({ level: 1 }).then((res) => {
        this.scheduleTypeData = res.data;
      });
    },
    // 选择文件
    selectFile(type, valObj) {
      const limit = 1;
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type,
      };
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      console.log(type, list);
      switch (type) {
        case "image":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "";
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
          }
          break;
        case "video":
          if (this.showIframeObj.valObj === "editor") {
            let insertHtml = "<span>&#12288;</span>";
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>';
            });
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              "insertHtml",
              insertHtml
            );
            console.log("妇女问的值");
            console.log(this.formItem.other_data.forum);
          }
          break;
        default:
          console.log("没有匹配的值");
          break;
      }
      this.showIframeObj.show = false;
    },
  },
};
</script>

<style lang="less">
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;
  .ivu-form-item-error-tip {
    left: 100px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.infoabs-box {
  display: block;
  font-size: 14px;
  color: #515a6e;
  position: absolute;
  top: 0;
  left: -70px;
}
</style>
