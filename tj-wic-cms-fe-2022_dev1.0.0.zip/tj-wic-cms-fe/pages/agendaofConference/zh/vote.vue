<!--
 * @Author: const_ytl
 * @Date: 2022-04-06 10:40:56
 * @LastEditors: const_ytl
 * @LastEditTime: 2022-04-08 09:50:26
 * @Description: 投票详情
-->
/* eslint-disable vue/valid-v-model */
<template>
    <div class="form-container">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="pagination.current_page"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
</template>

<script>
import { getVoteList } from '@/api/content';

export default {
  data() {
    return {
      // 表格数据加载
      tableLoading: true,
      tableColumns: [
        {
          title: '嘉宾头像',
          key: 'guest_head_img',
          align: 'center',
          render: (h, params) => {
            let imgSrc = params.row.guest_head_img
            if (!imgSrc) {
              return h('span', {})
            }
            // 修改图片文件名由于特殊符号引起的无法访问
            const urlArr = String(imgSrc).split('/')
            const url2 = urlArr[urlArr.length - 1]
            const url1 = String(imgSrc).replace(url2, '')
            imgSrc = url1 + encodeURIComponent(url2)
            return h('img', {
              attrs: {
                src: imgSrc + '?imageMogr2/thumbnail/!60x80r'
              },
              style: { cursor: 'pointer', maxWidth: '60px', maxHeight: '80px' },
              on: {
                // error: (e) => {
                //   e.target.src = nopicUrl
                //   e.target.iserror = true
                // },
                click: (e) => {
                  if (e.target.iserror !== true) {
                    const img = new Image(1, 1)
                    img.src = imgSrc
                    const viewer = new Viewer(img, {
                      toolbar: false,
                      title: false,
                      navbar: false,
                      hidden: () => {
                        viewer.destroy()
                      }
                    })
                    viewer.show()
                  }
                }
              }
            })
          }
        },
        { title: '嘉宾姓名', key: 'guest_name', align: 'center' },
        { title: '累计票数', key: 'guest_num', align: 'center', sortable: true },
        { title: '投票人数', key: 'vote_uid_num', align: 'center' },
      ],
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      listData: [],
      id: ''
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.getListData();
  },
  destroyed() {},
  methods: {
    getListData() {
      getVoteList({
        schedule_id: this.id,
        p: this.pagination.current_page,
        page_size: this.pagination.page_size,
      }).then(res => {
        setTimeout(() => {
          this.tableLoading = false;
        }, 500);
        this.listData = res.data.list;
        this.pagination = res.data.pagination;
        console.log('--------getVoteList------res', res);
      }).catch(err => {
        setTimeout(() => {
          this.tableLoading = false;
        }, 500);
        console.log('--------getVoteList------err', err);
      })
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.tableLoading = true;
      this.pagination.current_page = page;
      this.listData = [];
      this.getListData();
    },
    PageSizeChange(pageSize) {
      this.tableLoading = true;
      this.pagination.page_size = pageSize;
      this.pagination.current_page = 1;
      this.listData = [];
      this.getListData();
    },
  }
}
</script>

<style lang="less" scoped>
.form-container {
    clear: both;
    margin-top: 20px;
    &-page {
        margin: 10px 0;
        line-height: 32px;
    }
    }
    .demo-drawer-footer {
        width: 100%;
        /*position: absolute;*/
        /*bottom: 0;*/
        /*left: 0;*/
        border-top: 1px solid #e7e8eb;
        padding: 20px 16px;
        text-align: right;
        background: #fff;
    button {
        margin-left: 10px;
    }
}
</style>
