<!--
 * @Author: summer
 * @Date: 2021-02-25 10:47:11
 * @LastEditors: hyman
 * @LastEditTime: 2021-02-26 16:19:17
 * @Description: 请填写简介
-->
<template>
  <cooperateListPage :content-type="contentType" />
</template>
<script>
import cooperateListPage from '@/components/content/listPage'
export default {
  components: {
    cooperateListPage
  },
  data() {
    return {
      contentType: 4
    }
  },
  created() {},
  methods: {}
}
</script>
