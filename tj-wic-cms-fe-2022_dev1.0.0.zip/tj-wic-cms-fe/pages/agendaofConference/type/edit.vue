<!--
 * @Author: your name
 * @Date: 2021-02-25 10:13:39
 * @LastEditTime: 2021-02-25 10:15:57
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \tj-wic-cms-fe\pages\agendaofConference\type\edit.vue
-->
<template>
  <!-- 大会日程 -->
  <div class="">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="上级类型" prop="other_data.type">
        <Select v-model="formItem.other_data.type">
          <Option
            v-for="itemType in scheduleTypeData"
            :key="itemType.value"
            :value="itemType.value"
            >{{ itemType.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem label="论坛类型（中文）" prop="title">
        <Input
          v-model="formItem.title"
          placeholder="请输入中文论坛类型"
          maxlength="5"
          show-word-limit
        />
      </FormItem>
      <FormItem label="论坛类型（英文）" prop="en_title">
        <Input
          v-model="formItem.en_title"
          placeholder="请输入英文论坛类型"
          maxlength="15"
          show-word-limit
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span class="color_grey"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem style="margin-top:50px">
        <footerButton
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
          @submitPreview="submitPreview"
        />
      </FormItem>
    </Form>
  </div>
</template>

<script>
import footerButton from '../../../components/content/fotterButton'
import { getView } from '@/api/content'
import { getScheduleType } from '@/api/common'
import util from '@/libs/util'
export default {
  components: {
    footerButton
  },
  data() {
    return {
      scheduleTypeData: [],
      formItem: {
        title: '',
        en_title: '',
        weight: 999,
        other_data: {
          type_name: '',
          type: '',
          content_model: ''
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入中文论坛类型',
            trigger: 'blur'
          }
        ],
        'other_data.type': [
          {
            required: true,
            message: '请选择上级类型',
            trigger: 'change',
            type: 'number'
          }
        ],
        en_title: [
          {
            required: true,
            message: '请输入英文论坛类型',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ]
      },
      contentType: 1,
      p: 1,
      tab_type: 1,
      loading: false
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    if (this.id !== '') {
      this.loadInfo()
    }
    this.getScheduleTypeData()
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
  },
  methods: {
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required =
            key === 'title' || key === 'en_title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 预览
    submitPreview(formName) {
      console.log('预览预览。。。。')
    },
    // 获取详情信息
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          res.data.other_data.type = res.data.other_data.type
            ? Number(res.data.other_data.type)
            : ''
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 获取上级类型
    getScheduleTypeData() {
      getScheduleType({ level: 0 }).then((res) => {
        console.log('获取到的数据')
        console.log(res)
        this.scheduleTypeData = res.data
      })
    }
  }
}
</script>

<style lang="less">
.color_grey {
  color: #ccc;
  margin-left: 10px;
}
</style>
