<template>
  <contentEditPage />
</template>
<script>
import contentEditPage from './edit'
export default {
  components: {
    contentEditPage
  },
  data() {
    return {}
  },
  beforeDestroy() {},
  created() {},

  methods: {}
}
</script>
