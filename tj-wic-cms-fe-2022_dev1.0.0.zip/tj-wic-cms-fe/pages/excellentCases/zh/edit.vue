<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="标题" prop="title">
        <Input v-model="formItem.title" placeholder="请输入活动标题" />
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="340"
          :height="147"
          :fixed-number="[340, 147]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem label="案例视频">
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.case_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
      </FormItem>
        <!-- 添加优秀案例单选 -->
         <Form-item label="案例类型" prop="other_data.type">
            <Select v-model="formItem.other_data.type" style="width:150px" placeholder="请选择案例类型">
                <Option value="1">优秀案例</Option>
                <Option value="2">入围案例</Option>
               
            </Select>
        </Form-item>

      <FormItem label="赛道名称">
        <Input
          v-model="formItem.other_data.track_name"
          placeholder="请输入赛道名称"
        />
      </FormItem>
      <FormItem label="案例介绍">
        <vue-ueditor-wrap
          v-model="formItem.other_data.introduce"
          :config="editorConfig"
          @ready="editorReady1"
        />
        <!-- <Input
          v-model="formItem.other_data.introduce"
          type="textarea"
          :autosize="{ minRows: 2, maxRows: 5 }"
          placeholder="请输入案例介绍"
        /> -->
      </FormItem>
      <FormItem label="案例详情">
        <Button
          v-if="formItem.other_data.intro.length === 0"
          @click="onformChildItemAdd(0)"
          >添加</Button
        >
        <div
          v-for="(items, index) in formItem.other_data.intro"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.intro.length - 1"
                class="btn"
                @click="onformChildItemDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.intro.length - 1 &&
                    formItem.other_data.intro.length > 1 &&
                    index >= 1
                "
                class="btn"
                @click="onformChildItemUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemAdd(index)">向下添加</a>
              <a class="btn" @click="onformChildItemDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="标题"
              :label-width="80"
              :rules="ruleValidate.childtitle"
            >
              <Input
                v-model="items.title"
                placeholder="请输入"
                style="width:80%;" 
              />
              <!-- :maxlength="langEn === 'zh' ? 10 : 30"
                show-word-limit -->
            </FormItem>
            <FormItem
              label="内容"
              style="margin-top:20px;position:relative;"
              :rules="ruleValidate.childinfo"
            >
              <vue-ueditor-wrap
                style="margin-left:80px;width:80%;"
                :key="index + 1"
                v-model="items.content"
                :config="editorConfig"
                @ready="editorReady"
              />
            </FormItem>
          </div>
        </div>
      </FormItem>
      <FormItem style="margin-top:50px;">
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import showIframe from '../../../components/iframe'
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import VideoUpload from '@/components/videoUpload'
import { getView } from '@/api/content'
// import { getExperienceMapList } from '@/api/common'
import util from '@/libs/util'
import Setting from '@/wau.config'
const CON_UEDITOR = {} // TODO 1 添加编辑的大容器

export default {
  components: {
    showIframe,
    CustomVueCropper,
    footerButton,
    VueUeditorWrap,
    VideoUpload
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      formItem: {
        title: '', // 标题
        head_img: '', // 封面图
        weight: 999, // 排序
        other_data: {
          content_model: 'cloud_activity',
          case_video: {
            video_img_url: '',
            video_url: ''
          },
          type:0,
          track_name: '',
          intro: [],
          introduce: '', // 概要介绍
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],   
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        childtitle: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        childinfo: [
          {
            required: true,
            message: '请输入内容',
            trigger: 'blur'
          }
        ],
        'other_data.intro': [
          {
            required: true,
            message: '请填写系列活动介绍',
            trigger: 'blur',
            type: 'array'
          }
        ],
        'other_data.case_video.video_url': [
          {
            required: true,
            message: '请选择体验视频',
            trigger: 'blur'
          }
        ],
          'other_data.type': [
          {
            required: true,
            message: '请选择案例类型',
            trigger: 'change'
          }
        ],
        'other_data.track_name': [
          {
            required: true,
            message: '请输入赛道名称',
            trigger: 'blur'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 0,
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      loading: false,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: '',
      isPcPointShow: false,
      pcPointLeft: 0,
      pcPointTop: 0,
      h5PointLeft: 0,
      h5PointTop: 0,
      pcMapList: [],
      h5MapList: []
    }
  },
  created() {
    const that = this
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    if (this.id !== '') {
      this.loadInfo()
    }
  },
  methods: {
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.case_video.video_url = url
        ? url[0].play_url
        : ''
      this.formItem.other_data.case_video.video_img_url = url
        ? url[0].title_url
        : ''
    },
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 富文本组件初始化
    editorReady1(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {}
      CON_UEDITOR[e.uid].uEditor = e
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {}
      CON_UEDITOR[e.uid].uEditor = e
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.intro, index, index + 1)
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.intro, index, index - 1)
    },
    // 添加
    onformChildItemAdd(index) {
      const obj = {
        title: '',
        info: ''
      }
      this.formItem.other_data.intro.splice(index + 1, 0, obj)
      // console.log( this.formItem.other_data.type>>>0)
    },
    // 删除
    onformChildItemDel(index) {
      this.formItem.other_data.intro.splice(index, 1)
    },
    // 点击按钮
    submitForm(submitType) {
      // this.formItem.other_data.type =+this.formItem.other_data.type>>>0
      // console.log( typeof (this.formItem.other_data.type>>>0))
    console.log( this.formItem.other_data.type)
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          console.log(key)
          this.ruleValidate[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 获取详情数据
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'excellent_cases'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          if (!res.data.other_data.intro) {
            res.data.other_data.intro = []
          }
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem[name] = url
    }
  }
}
</script>

<style lang="less">
.color_grey {
  color: #999;
}
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;

  .ivu-form-item-error-tip {
    left: 80px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.img-choose-box {
  .content-box {
    // width: 519px;
    // height: 807px;
    width: 480px;
    height: 748px;
    position: relative;
    .img_back {
      width: 100%;
      height: 100%;
    }
    .img_address {
      width: 30px;
      height: 30px;
      position: absolute;
      top: 0;
      left: 0;
    }
    .border-box {
      width: 22px;
      height: 22px;
      position: absolute;
      border-radius: 50%;
      opacity: 0.7;
      background: rgba(56, 109, 231, 0.5);
      background: radial-gradient(
        ellipse at center,
        rgba(56, 109, 231, 0) 0,
        rgba(56, 109, 231, 0.5) 100%
      );
      .dot {
        position: absolute;
        left: 50%;
        top: 50%;
        width: 7px;
        height: 7px;
        margin: -3.5px 0 0 -4px;
        border-radius: 50%;
        background: #366be7;
        z-index: 1;
      }
    }
  }
}
</style>
