<template>
  <div>
    <Form
      ref="formItem"
      :model="formItem"
      :rules="ruleValidate"
      :label-width="140"
      label-colon
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="日期" prop="publish_time">
        <DatePicker
          v-model="formItem.publish_time"
          type="date"
          placeholder="请选择日期"
          style="width: 168px"
          :clearable="false"
        ></DatePicker>
      </FormItem>
      <FormItem label="大会日程" :label-width="140">
        <Button
          v-if="formItem.other_data.schedule.length === 0"
          @click="onformChildItemPlanAdd(0)"
          >添加</Button
        >
        <div
          v-for="(item, index) in formItem.other_data.schedule"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">日程{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.schedule.length - 1"
                class="btn"
                @click="onformChildItemPlanDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.schedule.length - 1 &&
                    formItem.other_data.schedule.length > 1 &&
                    index >= 1
                "
                class="btn"
                @click="onformChildItemPlanUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemPlanAdd(index)">向下添加</a>
              <a class="btn" @click="onformChildItemPlanDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="时间 "
              :label-width="100"
              :rules="ruleValidate.schedule_plan_time"
            >
              <Input
                v-model="item.time"
                placeholder="请输入时间"
                style="width: 400px"
              />
            </FormItem>
            <FormItem
              label="描述"
              :label-width="100"
              :rules="ruleValidate.schedule_plan_info"
              style="margin-top:20px;"
            >
              <div
                v-for="(lists, idx) in formItem.other_data.schedule[index].info"
                :key="idx"
                :style="idx === 0 ? '' : 'margin-left:100px;'"
              >
                <Input
                  v-model="formItem.other_data.schedule[index].info[idx]"
                  placeholder="请输入描述"
                  style="width: 400px"
                />
                <Button
                  type="primary"
                  v-if="idx !== 0"
                  @click="onDescDel(index, idx)"
                  >-</Button
                >
                <Button type="primary" @click="onDescAdd(index, idx)">+</Button>
              </div>
            </FormItem>
          </div>
        </div>
      </FormItem>
      <FormItem style="margin-top: 50px">
        <footerButton
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
  </div>
</template>

<script>
import footerButton from '../../../components/content/fotterButton'
import { getView } from '@/api/content'
import util from '@/libs/util'
const check_url = (rule, value, callback) => {
  if (value.includes('')) {
    callback(new Error('描述不能为空'))
  } else {
    callback()
  }
}

export default {
  components: {
    footerButton
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      guestListData: [],
      scheduleTypeData: [],
      formItem: {
        publish_time: '', // 时间
        other_data: {
          content_model: 'meeting_schedule',
          schedule: [
            {
              time: '',
              info: ['']
            }
          ]
        }
      },
      ruleValidate: {
        publish_time: [
          {
            required: true,
            message: '请选择日期',
            trigger: 'blur',
            type: 'date'
          }
        ],
        schedule_plan_time: [
          {
            required: true,
            message: '请输入时间',
            trigger: 'blur'
          }
        ],
        schedule_plan_info: [
          {
            required: true,
            message: '请输入描述',
            trigger: 'blur',
            type: 'array',
            validator: check_url
          }
        ],
        'other_data.schedule': [
          {
            required: true,
            message: '请填写大会日程',
            trigger: 'blur',
            type: 'array'
          }
        ]
      },
      contentType: 1,
      tab_type: 1,
      p: 1,
      loading: false
    }
  },
  created() {
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    if (this.id !== '') {
      this.loadInfo()
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
  },
  destroyed() {},
  methods: {
    // 描述添加
    onDescAdd(index, idx) {
      console.log(index, idx)
      this.formItem.other_data.schedule[index].info.splice(idx + 1, 0, '')
    },
    // 描述删除
    onDescDel(index, idx) {
      console.log(index, idx)
      this.formItem.other_data.schedule[index].info.splice(idx, 1)
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    // 日程安排下移
    onformChildItemPlanDown(index) {
      this.swapArray(this.formItem.other_data.schedule, index, index + 1)
    },
    // 日程安排上移
    onformChildItemPlanUp(index) {
      this.swapArray(this.formItem.other_data.schedule, index, index - 1)
    },
    // 日程安排添加
    onformChildItemPlanAdd(index) {
      const obj = {
        info: [''],
        time: ''
      }
      this.formItem.other_data.schedule.splice(index + 1, 0, obj)
    },
    // 日程安排删除
    onformChildItemPlanDel(index) {
      this.formItem.other_data.schedule.splice(index, 1)
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      console.log('表单数据')
      console.log(this.formItem)
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
          if (key === 'schedule_plan_info') {
            this.ruleValidate[key][0].validator = check_url
          }
        })
      } else {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = key === 'publish_time'
          this.ruleValidate[key][0].validator = null
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 获取详情信息
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id
      }).then((res) => {
        if (res.ret === 0) {
          this.dateVal = res.data.other_data.time
            ? res.data.other_data.time.split(' ')[0]
            : ''
          this.timeVal =
            res.data.other_data.time && res.data.other_data.time.split(' ')[1]
              ? res.data.other_data.time.split(' ')[1].split('-')
              : ''
          res.data.other_data.schedule = res.data.other_data.schedule
            ? res.data.other_data.schedule
            : [{ time: '', info: [''] }]
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    }
  }
}
</script>

<style lang="less">
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;
  .ivu-form-item-error-tip {
    left: 100px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.infoabs-box {
  display: block;
  font-size: 14px;
  color: #515a6e;
  position: absolute;
  top: 0;
  left: -70px;
}
</style>
