<template>
  <div class="tip-page-index">
    <h2>
      <Alert banner type="error" show-icon
        ><Icon slot="icon" type="ios-cafe-outline" size="20"></Icon
        >请选择左侧菜单进行内容管理~</Alert
      >
    </h2>
  </div>
</template>

<script>
export default {
  components: {}
}
</script>

<style lang="less">
.tip-page-index {
  width: 242px;
  height: 160px;
  position: absolute;
  text-align: center;
  left: 50%;
  top: 50%;
  margin-left: 0px;
  margin-top: -100px;
  img {
    opacity: 0.7;
    width: 220px;
  }
  h2 {
    opacity: 0.6;
    margin-top: 40px;
    width: 242px;
    .ivu-alert {
      padding-right: 0;
    }
  }
}
</style>
