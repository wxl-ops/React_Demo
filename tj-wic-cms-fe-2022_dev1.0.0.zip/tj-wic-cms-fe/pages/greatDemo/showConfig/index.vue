<template>
  <div class="pcconfig-page">
    <div class="pcconfig-form-box">
      <Form ref="formItem" :model="formItem">
        <div>
          <div
            v-for="(items, index) in formItem.other_data.plan"
            :key="index"
            class="pcconfig-subevents-list"
          >
            <div class="titleandbtn-box">
              <div class="title-box">
                页面呈现配置
              </div>
            </div>
            <div class="subevents-form-box">
              <div class="demo-box">
                <div class="demo-txt">优秀案例</div>
                <div style="padding: 20px;">
                  <FormItem
                    class="demo1-txt"
                    label="页面效果"
                    :label-width="80"
                    :prop="`other_data.plan[${index}].page_effect`"
                    :rules="ruleValidate.page_effect"
                  >
                    <Button
                      class="demo-item"
                      :type="index === currentIndex ? p : 'text'"
                      @click="changeDemo(index)"
                      :key="item"
                      v-for="(item, index) in page_effect"
                      >{{ item }}</Button
                    >
                  </FormItem>
                  <FormItem
                    class="demo1-txt"
                    label="云路演"
                    :label-width="80"
                  >
                    <VideoUpload
                      id="video_source"
                      :value="formItem.other_data.video.video_url"
                      :fixed="true"
                      :is-operation-location="true"
                      @onUploadVideo="onUploadVideo"
                    />
                    <!-- <span>视频格式支持MP4，大小限制是500MB。</span> -->
                  </FormItem>
                  <FormItem
                    class="demo1-txt"
                    label="颁奖典礼"
                    :label-width="80"
                  >
                  <Button
                    v-if="formItem.other_data.offline_show.length === 0"
                    @click="onformChildItemAdd(0)"
                    >添加</Button
                  >
                  <div
                    v-for="(items, index) in formItem.other_data.offline_show"
                    :key="index"
                    class="subevents-list"
                    v-if="formItem.other_data.offline_show.length > 0"
                  >
                    <div class="titleandbtn-box">
                      <div class="title-box">{{ index + 1 }}</div>
                      <div class="btn-box">
                        <a
                          v-if="index < formItem.other_data.offline_show.length - 1"
                          class="btn"
                          @click="onformChildItemDown(index)"
                          >下移</a
                        >
                        <a
                          v-if="
                            index <= formItem.other_data.offline_show.length - 1 &&
                              formItem.other_data.offline_show.length > 1 &&
                              index >= 1
                          "
                          class="btn"
                          @click="onformChildItemUp(index)"
                          >上移</a
                        >
                        <a class="btn" @click="onformChildItemAdd(index)">向下添加</a>
                        <a class="btn" @click="onformChildItemDel(index)">删除</a>
                      </div>
                    </div>
                    <div class="subevents-form-box" style="height: auto;">
                      <FormItem
                        label="上传类型"
                        :label-width="80"
                      >
                        <Radio-group v-model="items.type">
                          <Radio label="1">上传图片</Radio>
                          <Radio label="2">上传视频</Radio>
                        </Radio-group>
                        <!-- <Input
                          v-model="items.img_title"
                          placeholder="请输入"
                          style="width:80%;" 
                        /> -->
                        <!-- :maxlength="langEn === 'zh' ? 10 : 30"
                          show-word-limit -->
                      </FormItem>
                      <FormItem
                        v-if="items.type == 1"
                        label="图片上传"
                        style="margin-top:20px;position:relative;"
                      >
                        <CustomVueCropper
                          :id="String(index)"
                          :value="items.img_url"
                          :fixed="true"
                          :is-operation-location="true"
                          width="277"
                          height="344"
                          @onUploadImage="onUploadImage"
                        />
                      </FormItem>
                      <FormItem
                        v-if="items.type == 2"
                        label="视频上传"
                        style="margin-top:20px;position:relative;"
                      >
                        <VideoUpload
                          id="video_source"
                          :value="items.video_url"
                          :fixed="true"
                          :is-operation-location="true"
                          @onUploadVideo="onUploadVideo1(index, $event)"
                        />
                      </FormItem>
                    </div>
                  </div>
                  </FormItem>
                </div>
              </div>
              <div class="demo-btn">
                <Button type="primary" @click="goPublish()">发布</Button>
              </div>
            </div>
          </div>
        </div>
      </Form>
    </div>
  </div>
</template>

<script>
import VueUeditorWrap from "vue-ueditor-wrap";
import VideoUpload from "@/components/videoUpload";
import showIframe from "../../../components/iframe";
import CustomVueCropper from "@/components/imgUpload/CustomVueCropper";
import listDialog from "@/components/listDialog";
import { GetListData, saveContent } from "@/api/content";
import Setting from "@/wau.config"; // TODO 1 添加编辑的大容器
const CON_UEDITOR = {};

export default {
  components: {
    CustomVueCropper,
    VueUeditorWrap,
    listDialog,
    showIframe,
    VideoUpload,
  },
  data() {
    return {
      demoItem: false,
      currentIndex: 0,
      typeIndex: 1,
      p: "primary",
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: "",
        type: "",
      },
      page_effect: ["案例评选", "敬请期待", "列表"], //1 2 3
      formItem: {
        title: "",
        other_data: {
          content_model: "page_show_config",
          column: "", // 高峰论坛：summit；平行论坛：parallel；智能赛事：match；智能体验：experience；
          plan: [
            {
              fun_id: "",
              fun_img: "",
              time: [],
              title: "",
              //新模块新闻呈现
              page_effect: 1, //1 2 3
            },
          ],
          video: {
            video_url: '',
            video_img_url: ''
          },
          offline_show: []
        },
      },
      ruleValidate: {
        page_effect: [
          {
            required: false,
            message: "",
            trigger: "blur",
          },
        ],
      },
      contentType: 1,
      isDialogShow: false,
      searchType: 1,
      maxLength: 2,
      column: "",
      fixedWidth: 386,
      fixedHeight: 228,
    };
  },
  mounted() {
    this.initData();
  },
  methods: {
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.video.video_url = url
        ? url[0].play_url
        : "";
      this.formItem.other_data.video.video_img_url = url
        ? url[0].title_url
        : "";
    },
    // 获取视频后
    onUploadVideo1(index, url, name) {
      console.log('获取视频后----------', url, name, index);
      this.formItem.other_data.offline_show[index].video_url = url
        ? url[0].play_url
        : "";
      this.formItem.other_data.offline_show[index].video_img_url = url
        ? url[0].title_url
        : "";
    },
    initData() {
      GetListData({
        content_type: 39,
        column: 'excellent_cases',
        tab_type: 1,
        lang_tag: 'zh',
      }).then((res) => {
        if (res && res.ret === 0) {
          this.formItem = res.data || {
            title: '',
            other_data: {
              content_model: 'page_show_config',
              column: 'excellent_cases',
              plan: [
                {
                  fun_id: '',
                  fun_img: '',
                  time: [],
                  title: '',
                  page_effect: 1
                }
              ]
            },
            tag: ["zh"],
            tag_str: "中文",
            draft_status: 0,
            video: {
              video_url: '',
              video_img_url: ''
            },
            offline_show: []
          }

          if (res.data) {
            this.currentIndex = (res.data.other_data.plan[0].page_effect) - 1;
          } else {
            this.currentIndex = 0;
          }
        }
      })
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem.other_data.offline_show[name].img_url = url;
    },
    changeDemo(index) {
      this.currentIndex = index;
      console.log('changeDemo---------', index);
      this.formItem.other_data.plan[0].page_effect = Number(index + 1);
    },
    onformChildItemAdd(index) {
      const obj = {
        img_title: '',
        img_url: '',
        type: '1',
        video_url: '',
        video_img_url: ''
      };
      this.formItem.other_data.offline_show.splice(
        this.formItem.other_data.offline_show.length,
        0,
        obj
      );
    },
    // 删除
    onformChildItemDel(index) {
      // if (this.formItem.other_data.offline_show.length > 1) {
      this.formItem.other_data.offline_show.splice(index, 1);
      // } else {
      //   this.$Message.error("最少一条数据！");
      // }
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0];
      return arr;
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.offline_show, index, index + 1);
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.offline_show, index, index - 1);
    },
    goPublish() {
      this.formItem.draft_status = 0;
      const param = {
        ...this.formItem,
        content_type: 39,
      };
      saveContent(param).then((res) => {
        if (res.ret === 0) {
          this.$Message.success('发布成功');
        }
      })
    },
  },
};
</script>

<style lang="less" scoped>
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;
}

.pcconfig-subevents-list {
  border-radius: 8px;
  border: 1px solid #dcdee2;
  margin-bottom: 20px;

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #dcdee2;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    position: relative;
    box-sizing: border-box;
    padding: 25px 15px;
    // height: 500px;

    .demo-box {
      border-radius: 3px;
      border: 1px solid rgb(139, 138, 138);
      .demo-txt {
        height: 30px;
        line-height: 30px;
        border-bottom: 1px solid rgb(139, 138, 138);
        padding-left: 12px;
        font-weight: 600;
      }
      // .demo2-txt {
      //   height: 30px;
      //   line-height: 30px;
      //   padding-left: 32px;
      //   padding-top: 18px;
      //   top: -15px;
      //   left: -40px;
      //   position: absolute;
      //   display: flex;

        .demo-item {
          padding: 6px 20px;
          border-radius: 3px;
          border: 1px solid rgb(139, 138, 138);
        }
      // }
    }

    .demo-btn {
      position: absolute;
      text-align: center;
      left: 50%;
      bottom: 50px;
      margin-left: -32px;
    }
  }
}
.btn-add {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-radius: 8px;
  border: 1px solid #dcdee2;
  box-sizing: border-box;
  padding: 10px;

  &-info {
    font-size: 14px;
  }
}
</style>
