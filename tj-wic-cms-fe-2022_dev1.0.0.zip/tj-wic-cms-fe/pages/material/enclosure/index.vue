<template>
  <iframe
    :src="iframeSrc"
    frameborder="0"
    width="100%"
    style="height: 100%"
    class="content-list-page"
  ></iframe>
</template>

<script>
import axios from 'axios'
// import util from '@/libs/util'
import Setting from '@/wau.config'
export default {
  name: 'ShowIframe',
  props: {
    showObj: {
      type: Object,
      default() {
        return {
          limit: 1,
          show: false,
          valObj: '',
          type: 'attachment'
        }
      }
    }
  },
  data() {
    return {
      showCropper: false,
      cropperImg: '',
      iframeTitle: '',
      iframeSrc: '',
      iframeWidth: 1000,
      iframeHeight: 600,
      showTime: 0
    }
  },
  created() {
    this.showObjs(this.showObj)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resize)
    window.removeEventListener('message', this.getMessage, false)
  },
  mounted() {
    this.resize()
    window.addEventListener('resize', this.resize)
    window.addEventListener('message', this.getMessage, false)
  },
  methods: {
    showObjs(val) {
      const currTime = Date.parse(new Date())
      // const w_uid = util.cookies.get('w_uid')
      this.showTime = currTime
      this.$store.currShowTime = currTime
      const that = this
      axios
        .get('https://' + `${Setting.material[0]}media2/admin-api/media_url`)
        .then(function(res) {
          if (res.data.ret === 0) {
            // that.iframeSrc =
            //   String(res.data.data.host).replace('image', val.type) +
            const source_id = res.data.data.host
              .split('source_id=')[1]
              .split('&')[0]
            that.iframeSrc = `https://${Setting.material[1]}media/index/${
              Setting.material[2] ? val.type : 'type/'
            }?type=${val.type}&source_id=${source_id}`
            // '&limit=' +
            // that.showObj.limit +
            // (w_uid !== '' ? '&w_uid=' + w_uid : '')
            // (subtype !== '' ? '&subtype=' + subtype : '') +
            // (attachmenttype !== '' ? '&attachmenttype=' + attachmenttype : '')
          } else {
            that.$Message.error('获取媒体库失败')
          }
        })
        .catch(() => {
          that.$Message.error('获取媒体库失败')
        })
    },
    resize() {
      this.iframeHeight = window.innerHeight - 200
      this.iframeWidth = window.innerWidth * 0.75
      if (this.iframeHeight > 1000) {
        this.iframeHeight = 1000
      }
      if (this.iframeHeight < 400) {
        this.iframeHeight = 400
      }
      if (this.iframeWidth > 1200) {
        this.iframeWidth = 1200
      }
      if (this.iframeWidth < 600) {
        this.iframeWidth = 600
      }
    },
    onCancel() {
      this.iframeSrc = ''
      this.showObj.show = false
    },
    getMessage(e) {
      if (this.$store.currShowTime === this.showTime) {
        if (e.data.type !== 'cancel') {
          if (e.data.list.length > 0) {
            this.iframeSrc = ''
            this.$emit('getSelectFile', this.showObj.type, e.data.list)
          }
        } else {
          this.iframeSrc = ''
          this.onCancel()
        }
      }
    }
  }
}
</script>
<style lang="less" scoped>
.content-list-page {
  padding-bottom: 40px;
  padding: 0px !important;
}
.vertical-center-modal {
  display: flex;
  align-items: center;
  justify-content: center;

  .ivu-modal {
    top: 0;
  }
  .ivu-modal-body {
    padding: 0;
  }
}
</style>
