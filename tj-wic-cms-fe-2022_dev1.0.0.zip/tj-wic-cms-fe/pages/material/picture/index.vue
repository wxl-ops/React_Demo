<template>
  <iframe
    :src="iframeSrc"
    frameborder="0"
    width="100%"
    style="height: 100%"
    allowfullscreen="true"
    class="content-list-page"
  ></iframe>
</template>

<script>
import axios from 'axios'
// import util from '@/libs/util'
import Setting from '@/wau.config'
export default {
  name: 'ShowIframe',
  props: {
    showObj: {
      type: Object,
      default() {
        return {
          limit: 1,
          show: false,
          valObj: '',
          type: 'image'
        }
      }
    }
  },
  data() {
    return {
      showCropper: false,
      cropperImg: '',
      iframeTitle: '',
      iframeSrc: '',
      iframeWidth: 1000,
      iframeHeight: 600,
      showTime: 0
    }
  },
  created() {
    this.showObjs(this.showObj)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resize)
    window.removeEventListener('message', this.getMessage, false)
  },
  mounted() {
    this.resize()
    window.addEventListener('resize', this.resize)
    window.addEventListener('message', this.getMessage, false)
  },
  methods: {
    showObjs(val) {
      const currTime = Date.parse(new Date())
      // const w_uid = util.cookies.get('uid')
      this.showTime = currTime
      this.$store.currShowTime = currTime
      const that = this
      // let subtype = ''
      // let attachmenttype = ''
      // switch (val.type) {
      //   case 'audio':
      //     this.iframeTitle = '选择音频'
      //     subtype = 'mp3,mpeg'
      //     break
      //   case 'image':
      //     this.iframeTitle = '选择图片'
      //     break
      //   case 'cover':
      //     this.iframeTitle = '图片上传'
      //     break
      //   case 'video':
      //     this.iframeTitle = '选择视频'
      //     break
      //   case 'attachment':
      //     this.iframeTitle = '选择附件'
      //     attachmenttype = encodeURIComponent(
      //       'application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/x-xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/x-ppt,text/plain,application/x-gzip,application/x-gtar,application/x-7z-compressed,application/x-rar-compressed,application/zip,application/x-rar,application/x-7z-compressed,application/octet-stream,.rar,.7z'
      //     )
      //     break
      // }
      axios
        .get('https://' + `${Setting.material[0]}media2/admin-api/media_url`)
        .then(function(res) {
          if (res.data.ret === 0) {
            // that.iframeSrc =
            //   String(res.data.data.host).replace('image', val.type) +
            const source_id = res.data.data.host
              .split('source_id=')[1]
              .split('&')[0]
            that.iframeSrc = `https://${Setting.material[1]}media/index/${
              Setting.material[2] ? val.type : 'type/'
            }?type=${val.type}&source_id=${source_id}`
            // '&limit=' +
            // that.showObj.limit +
            // (w_uid !== '' ? '&w_uid=' + w_uid : '')
            // (subtype !== '' ? '&subtype=' + subtype : '') +
            // (attachmenttype !== '' ? '&attachmenttype=' + attachmenttype : '')
          } else {
            that.$Message.error('获取媒体库失败')
          }
        })
        .catch(() => {
          that.$Message.error('获取媒体库失败')
        })
    },
    resize() {
      this.iframeHeight = window.innerHeight - 200
      this.iframeWidth = window.innerWidth * 0.75
      if (this.iframeHeight > 1000) {
        this.iframeHeight = 1000
      }
      if (this.iframeHeight < 400) {
        this.iframeHeight = 400
      }
      if (this.iframeWidth > 1200) {
        this.iframeWidth = 1200
      }
      if (this.iframeWidth < 600) {
        this.iframeWidth = 600
      }
    },
    onCancel() {
      this.iframeSrc = ''
      this.showObj.show = false
    },
    getMessage(e) {
      if (this.$store.currShowTime === this.showTime) {
        if (e.data.type !== 'cancel') {
          if (e.data.list.length > 0) {
            this.iframeSrc = ''
            this.$emit('getSelectFile', this.showObj.type, e.data.list)
          }
        } else {
          this.iframeSrc = ''
          this.onCancel()
        }
      }
    }
  }
}
</script>
<style lang="less" scoped>
.content-list-page {
  padding-bottom: 40px;
  padding: 0px !important;
  // padding-right: 20px !important;
  padding-left: 20px !important;
}
// .media-list {
//   padding-right: 20px !important;
// }
.vertical-center-modal {
  display: flex;
  align-items: center;
  justify-content: center;

  .ivu-modal {
    top: 0;
  }
  .ivu-modal-body {
    padding: 0;
  }
}
</style>
