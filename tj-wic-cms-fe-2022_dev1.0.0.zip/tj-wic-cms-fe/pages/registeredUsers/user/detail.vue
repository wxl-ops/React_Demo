<template>
  <div>
    <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
      基本信息
    </h3>
    <div class="table-box">
      <div class="items-box">
        <div class="label-box">
          姓名
        </div>
        <div class="info-box">
          {{ userDetail.name }}
          <!-- kashdkasdklkjcbzxcbzxbcjkzbjkahwdhaosdaksnxkznxnzbjkcakjdkjdanksalkdjalkdjka -->
        </div>
      </div>
      <div class="items-box" v-if="userDetail.type_title === '观众'">
        <div class="label-box">
          公司
        </div>
        <div class="info-box">
          {{ userDetail.company.name }}
        </div>
      </div>
      <div class="items-box" v-if="userDetail.type_title === '媒体'">
        <div class="label-box">
          职业名称
        </div>
        <div class="info-box">
          {{ userDetail.job }}
        </div>
      </div>
      <div class="items-box">
        <div class="label-box">
          电话号码
        </div>
        <div class="info-box">
          {{ userDetail.mobile }}
        </div>
      </div>
      <div class="items-box" v-if="userDetail.type_title === '观众'">
        <div class="label-box">
          感兴趣的行业
        </div>
        <div class="info-box">
          <span v-for="(items, index) in userDetail.trade" :key="index">{{
            items.name + (index === userDetail.trade.length - 1 ? '' : '、')
          }}</span>
        </div>
      </div>
      <div class="items-box" v-if="userDetail.type_title === '媒体'">
        <div class="label-box">
          身份证号码
        </div>
        <div class="info-box">
          {{ userDetail.idcard }}
        </div>
      </div>
      <div class="items-box">
        <div class="label-box">
          用户类型
        </div>
        <div class="info-box">
          {{ userDetail.type_title }}
        </div>
      </div>
      <div class="items-box">
        <div class="label-box">
          注册时间
        </div>
        <div class="info-box">
          {{ userDetail.register_time }}
        </div>
      </div>
      <div class="items-box">
        <div class="label-box">
          邮箱
        </div>
        <div class="info-box">
          {{ userDetail.email }}
        </div>
      </div>
      <div class="items-box">
        <div class="label-box">
          最后登录时间
        </div>
        <div class="info-box">
          {{ userDetail.login_time }}
        </div>
      </div>
      <div v-if="userDetail.type_title === '媒体'" class="items-box">
        <div class="label-box">
          媒体单位名称
        </div>
        <div class="info-box">
          {{ userDetail.company.name }}
        </div>
      </div>
      <div v-if="userDetail.type_title === '媒体'" class="items-box">
        <div class="label-box"></div>
        <div class="info-box"></div>
      </div>
    </div>
    <div class="btn-box">
      <Button @click="goBack">返回</Button>
    </div>
  </div>
</template>
<script>
import { getUsersDetail } from '@/api/registeredUsers'
export default {
  components: {},
  data() {
    return {
      p: '',
      userDetail: {
        name: '',
        company: [],
        pure_mobile: '',
        trade: [],
        type: '',
        register_time: '',
        email: '',
        login_time: ''
      }
    }
  },
  beforeDestroy() {},
  created() {
    this.p = this.$route.query.p || 1
    this.id = this.$route.query.id
    if (this.id !== '') {
      this.getInfo()
    }
  },

  methods: {
    getInfo() {
      console.log('获取详情')
      getUsersDetail({ _id: this.id }).then((res) => {
        if (res.ret === 0) {
          console.log(res.data)
          this.userDetail = res.data
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // 返回
    goBack() {
      // const goPath = {
      //   name: 'registeredUsers-user',
      //   query: {
      //     p: this.p
      //   }
      // }
      this.$router.back()
    }
  }
}
</script>

<style lang="less">
.table-box {
  display: flex;
  flex-wrap: wrap;
  box-sizing: border-box;
  margin: 0 20px;
  border-top: 1px solid #ccc;
  border-left: 1px solid #ccc;
  border-right: 1px solid #ccc;
  .items-box {
    width: 50%;
    display: flex;
    min-height: 60px;
    align-items: center;
    border-bottom: 1px solid #ccc;

    &:nth-child(2n) {
      .label-box {
        border-left: 1px solid #ccc;
      }
    }

    .label-box {
      height: 100%;
      text-align: right;
      background: #eee;
      width: 30%;
      border-right: 1px solid #ccc;
      display: flex;
      align-items: center;
      box-sizing: border-box;
      padding-right: 10px;
      justify-content: flex-end;
    }
    .info-box {
      width: 70%;
      box-sizing: border-box;
      padding-left: 10px;
      word-wrap: break-word;
    }
  }
}
.btn-box {
  box-sizing: border-box;
  padding: 20px;
}
</style>
