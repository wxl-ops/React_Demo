<template>
  <div class="content-list-page">
    <div class="search-container">
      <div class="sc-left">
        <Input
          v-model="queryData.search_title"
          :maxlength="100"
          class="inputList inputList2"
          placeholder="请输入关键字"
          style="width: 300px;"
        />
        <!-- <Select
          v-model="queryData.search_type"
          style="width:300px"
          placeholder="请选择用户类型"
        >
          <Option
            v-for="(item, index) in typeList"
            :key="index"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select> -->
      </div>
      <div class="sc-right">
        <Button
          type="primary"
          style="margin-left: 10px;"
          @click="onPageSearch()"
          >查询</Button
        >
        <Button @click="clearSearch()">重置</Button>
      </div>
    </div>
    <div class="form-container">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="Number(pagination.current_page)"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import 'viewerjs/dist/viewer.css'
import { getRegisteredUsersList, getUsersTypeList } from '@/api/registeredUsers'
export default {
  name: 'ContentListPage',
  data() {
    return {
      // 表格数据加载
      tableLoading: false,
      // 查询相关
      queryData: {
        p: 1,
        page_size: 10,
        search_type: '',
        search_title: ''
      },
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      // 列表数据
      listData: [],
      tableColumns: [
        {
          title: '姓名',
          key: 'name',
          minWidth: 160
        },
        { title: '手机号码', key: 'mobile', width: 160 },
        { title: '邮箱', key: 'email', align: 'center', width: 150 },
        // { title: '用户类型', key: 'type_title', align: 'center', width: 150 },
        {
          title: '注册时间',
          key: 'register_time',
          align: 'center',
          width: 150
        },
        {
          title: '最后登录时间',
          key: 'login_time',
          align: 'center',
          width: 150
        },
        {
          title: '操作',
          key: 'action',
          fixed: 'right',
          align: 'center',
          width: 250,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: 'inline-block'
                  },
                  on: {
                    click: () => {
                      this.goDetailPage(params.row._id)
                    }
                  }
                },
                '查看详情'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: params.row.isquestionnaire
                      ? 'inline-block'
                      : 'none'
                  },
                  on: {
                    click: () => {
                      this.goNairePage(params.row._id)
                    }
                  }
                },
                '查看问卷'
              )
            ])
          }
        }
      ],
      typeList: [
        {
          label: '用户1',
          value: '1'
        },
        {
          label: '用户2',
          value: '1'
        },
        {
          label: '用户3',
          value: '1'
        }
      ]
    }
  },
  watch: {},
  beforeDestroy() {},
  created() {
    const { p } = this.$route.query
    this.queryData.p = p || 1
    // this.getUserTypeList()
    this.resize()
  },

  methods: {
    // 获取用户类型
    getUserTypeList() {
      getUsersTypeList({ all: 1 }).then((res) => {
        if (res.ret === 0) {
          this.typeList = res.data
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // 查询事件
    onPageSearch() {
      this.queryData.p = 1
      this.getListData()
    },
    // 跳转详情页面
    goDetailPage(id) {
      const goPath = {
        name: 'registeredUsers-user-detail',
        query: {
          p: this.queryData.p,
          id
        }
      }
      this.$router.push(goPath)
    },
    // 跳转调查问卷
    goNairePage(id) {
      const goPath = {
        name: 'questionnaire-naire-detail',
        query: {
          p: this.queryData.p,
          id,
          fromorigin: 'user'
        }
      }
      this.$router.push(goPath)
    },
    // 获取表格数据
    getListData() {
      this.tableLoading = true
      this.listData = []
      const params = {
        p: this.queryData.p,
        page_size: this.queryData.page_size,
        keyword: this.queryData.search_title,
        type: this.queryData.search_type
      }
      // 获取列表数据
      getRegisteredUsersList(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          this.listData = res.data.list
          this.pagination = res.data.pagination
        }
      })
    },
    // 清空表单状态
    clearSearch() {
      this.queryData.p = 1
      this.queryData.page_size = this.pageSizeOpts[0]
      this.queryData.search_title = ''
      this.queryData.search_type = ''
      this.getListData()
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.queryData.p = page
      this.getListData()
    },
    PageSizeChange(pageSize) {
      this.queryData.page_size = pageSize
      this.queryData.p = 1
      this.getListData()
    },
    // 自适应大小
    resize() {
      const listHeight = 74
      const searchHeight = 335
      let listNum = ((window.innerHeight - searchHeight) / listHeight) >> 0
      if (listNum < 3) {
        listNum = 3
      }
      this.pageSizeOpts[0] = listNum
      this.pageSizeOpts[1] = listNum * 2
      this.pageSizeOpts[2] = listNum * 3
      this.queryData.page_size = listNum
      this.getListData()
    }
  }
}
</script>
<style lang="less">
.content-list-page {
  padding-bottom: 40px;
  padding-top: 0px !important;
  .search-container {
    margin-top: 20px;
    height: 32px;
    .sc-left {
      float: left;
      width: calc(~'100% - 170px');
      .inputList {
        width: calc(~'100% - 245px');
        margin-right: 10px;
      }
      .inputList2 {
        width: calc(~'100% - 469px');
        margin-right: 10px;
      }
    }
    .sc-right {
      float: right;
      button {
        margin-left: 20px;
      }
    }
  }
  .form-container {
    clear: both;
    margin-top: 20px;
    &-page {
      margin: 10px 0;
      line-height: 32px;
    }
  }
}
</style>
