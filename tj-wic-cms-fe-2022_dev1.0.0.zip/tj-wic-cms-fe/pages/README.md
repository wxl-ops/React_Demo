<!-- # PAGES

This directory contains your Application Views and Routes.
The framework reads all the `*.vue` files inside this directory and creates the router of your application.

More information about the usage of this directory in [the documentation](https://nuxtjs.org/guide/routing). -->

registrationAgreement   注册协议配置
agendaofConference  大会日程
conferenceGuests  大会嘉宾
homoSapiens  智人智语
cloudEvents 云赛事
eventIntroduction 赛事介绍文章
cloudSeriesActivities 云系列活动
cloudIntelligentExperience 云智能体验
newsInformation  新闻资讯
