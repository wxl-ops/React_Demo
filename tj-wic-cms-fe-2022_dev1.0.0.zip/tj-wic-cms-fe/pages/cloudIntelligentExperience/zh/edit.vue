<template>
  <div class="page-index">
    <Form
      ref="formItem"
      :model="formItem"
      :label-width="140"
      :rules="ruleValidate"
    >
      <h3 style="box-sizing:border-box;padding-left:20px;line-height:60px;">
        基本信息
      </h3>
      <FormItem label="标题" prop="title">
        <Input v-model="formItem.title" placeholder="请输入活动标题" />
      </FormItem>
      <FormItem label="封面图">
        <CustomVueCropper
          id="head_img"
          :value="formItem.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="340"
          :height="147"
          :fixed-number="[340, 147]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem label="排序">
        <InputNumber
          v-model="formItem.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px;display:inline-block;"
        />
        <span
          style="color: #ccc; line-height: 32px; display: inline-block;margin-left: 10px;"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <!-- <FormItem label="举办单位">
        <Input
          v-model="formItem.other_data.organizer"
          placeholder="请输入举办单位"
        />
      </FormItem> -->
      <FormItem label="PC经纬度">
        <Input
          v-model="formItem.other_data.lat_long"
          placeholder="请选择经纬度,以逗号分割"
        />
        <!-- <Button type="primary" @click="isPcPointShow = true">选择</Button> -->
      </FormItem>
      <FormItem label="PC点位位置">
        <RadioGroup v-model="formItem.other_data.direction">
          <Radio :label="1">上</Radio>
          <Radio :label="2">下</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="H5经纬度">
        <Input
          v-model="formItem.other_data.h5_lat_long"
          placeholder="请输入经纬度,以逗号分割"
        />
        <!-- <Button type="primary" @click="isH5PointShow = true">选择</Button> -->
      </FormItem>
      <FormItem label="体验地址">
        <Input
          v-model="formItem.other_data.experience_address"
          placeholder="请输入智能体验地址"
        />
      </FormItem>
      <FormItem label="体验视频">
        <VideoUpload
          id="video_source"
          :value="formItem.other_data.experience_video.video_url"
          :fixed="true"
          :is-operation-location="true"
          @onUploadVideo="onUploadVideo"
        />
      </FormItem>
      <FormItem label="举办单位">
        <Input
          v-model="formItem.other_data.organizer"
          placeholder="请输入举办单位"
        />
      </FormItem>
      <FormItem label="概要介绍">
        <vue-ueditor-wrap
          v-model="formItem.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FormItem label="详情页">
        <RadioGroup v-model="formItem.other_data.detail_page">
          <Radio :label="1">开启</Radio>
          <Radio :label="-1">关闭</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="体验详情">
        <Button
          v-if="formItem.other_data.intro.length === 0"
          @click="onformChildItemAdd(0)"
          >添加</Button
        >
        <div
          v-for="(items, index) in formItem.other_data.intro"
          :key="index"
          class="subevents-list"
        >
          <div class="titleandbtn-box">
            <div class="title-box">{{ index + 1 }}</div>
            <div class="btn-box">
              <a
                v-if="index < formItem.other_data.intro.length - 1"
                class="btn"
                @click="onformChildItemDown(index)"
                >下移</a
              >
              <a
                v-if="
                  index <= formItem.other_data.intro.length - 1 &&
                    formItem.other_data.intro.length > 1 &&
                    index >= 1
                "
                class="btn"
                @click="onformChildItemUp(index)"
                >上移</a
              >
              <a class="btn" @click="onformChildItemAdd(index)">向下添加</a>
              <a class="btn" @click="onformChildItemDel(index)">删除</a>
            </div>
          </div>
          <div class="subevents-form-box">
            <FormItem
              label="标题"
              :label-width="80"
              :rules="ruleValidate.childtitle"
            >
              <Input
                v-model="items.title"
                placeholder="请输入"
                style="width:80%;"
                :maxlength="langEn === 'zh' ? 25 : 50"
                show-word-limit
              />
            </FormItem>
            <FormItem
              label="内容"
              style="margin-top:20px;position:relative;"
              :rules="ruleValidate.childinfo"
            >
              <vue-ueditor-wrap
                style="margin-left:80px;width:80%;"
                :key="index + 1"
                v-model="items.info"
                :config="editorConfig"
                @ready="editorReady"
              />
            </FormItem>
          </div>
        </div>
      </FormItem>
      <FormItem style="margin-top:50px;">
        <footerButton
          :id="id"
          :loading="loading"
          :form="formItem"
          :content-type="contentType"
          :tab-type="tab_type"
          :p="p"
          @submitForm="submitForm"
        />
      </FormItem>
    </Form>
    <Modal v-model="showPreviewDialog" title="选择要预览的界面">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button type="primary" @click="preview(mobilePreviewUrl)"
          >移动端界面</Button
        >
        <Button type="primary" @click="preview(pcPreviewUrl)">pc端界面</Button>
      </div>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
    <Modal
      v-model="isPcPointShow"
      title="PC经纬度选择"
      :footer-hide="true"
      :width="500"
    >
      <div class="img-choose-box">
        <div
          class="content-box"
          @mousemove="onMapImgMouseMove($event)"
          @mouseout="onMapImgMouseOut($event)"
        >
          <img class="img_back" src="../../../static/images/mappc.jpg" alt="" />
          <img
            :style="
              formItem.other_data.lat_long
                ? `left:${formItem.other_data.lat_long.split(',')[1]}px;top:${
                    formItem.other_data.lat_long.split(',')[0]
                  }px;`
                : ''
            "
            class="img_address J_glass"
            src="../../../static/images/ic_address.png"
            @click="ononMapImgMouseClick($event)"
          />
          <div
            :style="`left:${items.left}px;top:${items.top}px;`"
            class="border-box"
            v-for="(items, index) in pcMapList"
            :key="index"
          >
            <div class="dot"></div>
          </div>
        </div>
      </div>
    </Modal>
    <Modal
      v-model="isH5PointShow"
      title="H5经纬度选择"
      :footer-hide="true"
      :width="420"
    >
      <div class="img-choose-box">
        <div
          style="width:388px;height:604px;"
          class="content-box"
          @mousemove="onMapH5ImgMouseMove($event)"
          @mouseout="onMapH5ImgMouseOut($event)"
        >
          <img class="img_back" src="../../../static/images/maph5.jpg" alt="" />
          <img
            :style="
              formItem.other_data.h5_lat_long
                ? `left:${
                    formItem.other_data.h5_lat_long.split(',')[1]
                  }px;top:${formItem.other_data.h5_lat_long.split(',')[0]}px;`
                : ''
            "
            class="img_address J_h5glass"
            src="../../../static/images/ic_address.png"
            @click="ononMapH5ImgMouseClick($event)"
          />
          <div
            :style="`left:${items.left}px;top:${items.top}px;`"
            class="border-box"
            v-for="(items, index) in h5MapList"
            :key="index"
          >
            <div class="dot"></div>
          </div>
        </div>
      </div>
    </Modal>
  </div>
</template>

<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import showIframe from '../../../components/iframe'
import footerButton from '../../../components/content/fotterButton'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import VideoUpload from '@/components/videoUpload'
import { getView } from '@/api/content'
// import { getExperienceMapList } from '@/api/common'
import util from '@/libs/util'
import Setting from '@/wau.config'
const CON_UEDITOR = {} // TODO 1 添加编辑的大容器

export default {
  components: {
    showIframe,
    CustomVueCropper,
    footerButton,
    VueUeditorWrap,
    VideoUpload
  },
  props: {
    langEn: {
      type: String,
      default: 'zh'
    }
  },
  data() {
    return {
      formItem: {
        title: '', // 标题
        head_img: '', // 封面图
        weight: 999, // 排序
        html_content: '', // 概要介绍
        other_data: {
          content_model: 'cloud_activity',
          experience_address: '', // 体验地址
          direction: 1,
          experience_video: {
            video_img_url: '',
            video_url: ''
          },
          lat_long: '', // 经纬度
          // organizer: '', // 举办单位
          intro: [],
          detail_page: 1
        }
      },
      ruleValidate: {
        title: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        head_img: [
          {
            required: true,
            message: '请选择封面图',
            trigger: 'blur'
          }
        ],
        weight: [
          {
            required: true,
            message: '请输入排序值',
            trigger: 'blur',
            type: 'number'
          }
        ],
        childtitle: [
          {
            required: true,
            message: '请输入标题',
            trigger: 'blur'
          }
        ],
        childinfo: [
          {
            required: true,
            message: '请输入内容',
            trigger: 'blur'
          }
        ],
        'other_data.intro': [
          {
            required: true,
            message: '请填写系列活动介绍',
            trigger: 'blur',
            type: 'array'
          }
        ],
        'other_data.experience_address': [
          {
            required: true,
            message: '请输入体验地址',
            trigger: 'blur'
          }
        ],
        'other_data.lat_long': [
          {
            required: true,
            message: '请输入经纬度',
            trigger: 'blur'
          }
        ],
        'other_data.experience_video.video_url': [
          {
            required: true,
            message: '请选择体验视频',
            trigger: 'blur'
          }
        ],
        'other_data.organizer': [
          {
            required: true,
            message: '请输入举办单位',
            trigger: 'blur'
          }
        ],
        'other_data.direction': [
          {
            required: true,
            message: '请选择点位位置',
            trigger: 'blur',
            type: 'number'
          }
        ]
      },
      id: '',
      tab_type: 1,
      p: 1,
      contentType: 0,
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      loading: false,
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null,
      showPreviewDialog: false,
      mobilePreviewUrl: '',
      pcPreviewUrl: '',
      isPcPointShow: false,
      pcPointLeft: 0,
      pcPointTop: 0,
      isH5PointShow: false,
      h5PointLeft: 0,
      h5PointTop: 0,
      pcMapList: [],
      h5MapList: []
    }
  },
  created() {
    const that = this
    // 初始化值
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.cmsSelectImg = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.editorVideoSelect = function(e) {
      // TODO 3，点击的按钮的时候，传入当b编辑器UID
      that.showIframeObj = {
        uid: e,
        limit: 1,
        show: true,
        valObj: 'editor',
        type: 'video'
      }
    }
    // eslint-disable-next-line nuxt/no-globals-in-created
    window.isEditIng = true
    this.id = this.$route.query.id ? this.$route.query.id : ''
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.contentType = this.$route.query.content_type * 1
    if (this.id !== '') {
      this.loadInfo()
    }
    // getExperienceMapList({
    //   content_model: 'cloud_experience_coordinate',
    //   tab_type: 'list_online',
    //   tag: 'zh',
    //   tree_id: this.id
    // }).then((res) => {
    //   console.log('请求到的结果')
    //   console.log(res)
    //   if (res.ret === 0) {
    //     this.pcMapList = res.data
    //   }
    // })
    // getExperienceMapList({
    //   content_model: 'cloud_experience_coordinate',
    //   tab_type: 'list_online',
    //   tag: 'zh',
    //   tree_id: this.id,
    //   type: 'h5'
    // }).then((res) => {
    //   console.log('请求到的结果')
    //   console.log(res)
    //   if (res.ret === 0) {
    //     this.h5MapList = res.data
    //   }
    // })
  },
  methods: {
    // 选点确定，鼠标单击
    ononMapH5ImgMouseClick() {
      this.formItem.other_data.h5_lat_long =
        parseInt(this.h5PointTop) + ',' + parseInt(this.h5PointLeft)
      this.isH5PointShow = false
    },
    // 鼠标移出图片区域，取消放大镜效果
    onMapH5ImgMouseOut(event) {
      event.stopPropagation()
    },
    // 鼠标在图片区域内移动事件
    onMapH5ImgMouseMove(event) {
      event.stopPropagation()
      const glassBlock = document.querySelector('.J_h5glass')

      // 取图片容器的大小及其相对于视口的位置，需要实时取，所以放在move事件里
      const clientRect = event.currentTarget.getBoundingClientRect()

      // 获取距鼠标距的上和左的坐标
      const leftX = event.clientX - clientRect.left
      const leftY = event.clientY - clientRect.top

      // 动态设置遮罩块的left和top位置 这里需要减去遮罩层的一半，因为鼠标位于遮罩块中心点
      let pointerLeft = leftX - 15
      let pointerTop = leftY - 15

      // 如果鼠标坐标移动超出原始图片区域边缘 则取消放大镜效果 因为这里存在快速移动鼠标到大图区域时，鼠标仍处在外层的图片区域内，并不会触发mouseout事件(虽然中间隔了小小的间距，但是快速移动仍能产生这个bug,如代码下面的图所示)
      if (
        pointerLeft + 15 > clientRect.width ||
        pointerLeft < 0 - 15 ||
        pointerTop + 15 > clientRect.height ||
        pointerTop < 0 - 15
      ) {
        return !1
      }

      // 遮罩块在最左边的时候，鼠标仍在图片区域内，可在遮罩块左边缘至中心线区域内移动，且这时遮罩块为距左0像素
      if (pointerLeft < 0) {
        pointerLeft = 0
      }

      // 同上 右边限制
      if (pointerLeft > clientRect.width - 30) {
        pointerLeft = clientRect.width - 30
      }

      // 同上 顶部限制
      if (pointerTop < 0) {
        pointerTop = 0
      }

      // 同上 底部限制
      if (pointerTop > clientRect.height - 30) {
        pointerTop = clientRect.height - 30
      }

      // 设置遮罩块的位置
      glassBlock.style.left = pointerLeft + 'px'
      glassBlock.style.top = pointerTop + 'px'
      this.h5PointLeft = pointerLeft
      this.h5PointTop = pointerTop
    },
    // 选点确定，鼠标单击
    ononMapImgMouseClick() {
      this.formItem.other_data.lat_long =
        parseInt(this.pcPointTop) + ',' + parseInt(this.pcPointLeft)
      this.isPcPointShow = false
    },
    // 鼠标移出图片区域，取消放大镜效果
    onMapImgMouseOut(event) {
      event.stopPropagation()
    },
    // 鼠标在图片区域内移动事件
    onMapImgMouseMove(event) {
      event.stopPropagation()
      const glassBlock = document.querySelector('.J_glass')

      // 取图片容器的大小及其相对于视口的位置，需要实时取，所以放在move事件里
      const clientRect = event.currentTarget.getBoundingClientRect()

      // 获取距鼠标距的上和左的坐标
      const leftX = event.clientX - clientRect.left
      const leftY = event.clientY - clientRect.top

      // 动态设置遮罩块的left和top位置 这里需要减去遮罩层的一半，因为鼠标位于遮罩块中心点
      let pointerLeft = leftX - 15
      let pointerTop = leftY - 15

      // 如果鼠标坐标移动超出原始图片区域边缘 则取消放大镜效果 因为这里存在快速移动鼠标到大图区域时，鼠标仍处在外层的图片区域内，并不会触发mouseout事件(虽然中间隔了小小的间距，但是快速移动仍能产生这个bug,如代码下面的图所示)
      if (
        pointerLeft + 15 > clientRect.width ||
        pointerLeft < 0 - 15 ||
        pointerTop + 15 > clientRect.height ||
        pointerTop < 0 - 15
      ) {
        return !1
      }

      // 遮罩块在最左边的时候，鼠标仍在图片区域内，可在遮罩块左边缘至中心线区域内移动，且这时遮罩块为距左0像素
      if (pointerLeft < 0) {
        pointerLeft = 0
      }

      // 同上 右边限制
      if (pointerLeft > clientRect.width - 30) {
        pointerLeft = clientRect.width - 30
      }

      // 同上 顶部限制
      if (pointerTop < 0) {
        pointerTop = 0
      }

      // 同上 底部限制
      if (pointerTop > clientRect.height - 30) {
        pointerTop = clientRect.height - 30
      }

      // 设置遮罩块的位置
      glassBlock.style.left = pointerLeft + 'px'
      glassBlock.style.top = pointerTop + 'px'
      this.pcPointLeft = pointerLeft
      this.pcPointTop = pointerTop
    },
    // 获取视频后
    onUploadVideo(url, name) {
      this.formItem.other_data.experience_video.video_url = url
        ? url[0].play_url
        : ''
      this.formItem.other_data.experience_video.video_img_url = url
        ? url[0].title_url
        : ''
    },
    preview(val) {
      if (val) {
        window.open(val, '_blank')
      } else {
        this.$Message.error('暂不支持预览')
      }
    },
    // 富文本组件初始化
    editorReady(e) {
      // TODO 2，按照id初始化编辑器
      CON_UEDITOR[e.uid] = CON_UEDITOR[e.uid] || {}
      CON_UEDITOR[e.uid].uEditor = e
    },
    swapArray(arr, index1, index2) {
      arr[index1] = arr.splice(index2, 1, arr[index1])[0]
      return arr
    },
    // 下移
    onformChildItemDown(index) {
      this.swapArray(this.formItem.other_data.intro, index, index + 1)
    },
    // 上移
    onformChildItemUp(index) {
      this.swapArray(this.formItem.other_data.intro, index, index - 1)
    },
    // 添加
    onformChildItemAdd(index) {
      const obj = {
        title: '',
        info: ''
      }
      this.formItem.other_data.intro.splice(index + 1, 0, obj)
    },
    // 删除
    onformChildItemDel(index) {
      this.formItem.other_data.intro.splice(index, 1)
    },
    // 点击按钮
    submitForm(submitType) {
      const param = {
        ...this.formItem,
        draft_status: submitType, // 保存:-1;0:提交 2:预览
        tab_type: this.tab_type,
        content_type: this.contentType,
        tag: this.langEn
      }
      const keys = Object.keys(this.ruleValidate)
      if (submitType === 0 || submitType === 2) {
        keys.forEach((key) => {
          this.ruleValidate[key][0].required = true
        })
      } else {
        keys.forEach((key) => {
          console.log(key)
          this.ruleValidate[key][0].required = key === 'title'
        })
      }
      this.$refs.formItem.validate((valid) => {
        if (valid) {
          util.editSaveContent(this, submitType, param)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 获取详情数据
    loadInfo() {
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        content_model: 'cloud_activity'
      }).then((res) => {
        if (res.ret === 0) {
          res.data.weight = res.data.weight ? parseInt(res.data.weight) : ''
          res.data.other_data.direction = res.data.other_data.direction
            ? parseInt(res.data.other_data.direction)
            : ''
          res.data.other_data.detail_page = res.data.other_data.detail_page
            ? Number(res.data.other_data.detail_page)
            : 1
          if (!res.data.other_data.intro) {
            res.data.other_data.intro = []
          }
          this.formItem = res.data
        } else {
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 监听上传后的值
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<p><img src="' + item.img_url + '" /></p>'
            })
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = '<span>&#12288;</span>'
            list.map((item) => {
              insertHtml +=
                '<p><video controls="controls" controlsList="nodownload"   disablePictureInPicture src="' +
                item.play_url +
                '" poster="' +
                item.title_url +
                '"></video></p>'
            })
            // TODO 4，按照UID插入自己的编辑器
            CON_UEDITOR[this.showIframeObj.uid].uEditor.execCommand(
              'insertHtml',
              insertHtml
            )
          }
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 上传图片
    selectFile(type, valObj) {
      const limit = 1
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 裁截图片后
    onUploadImage(url, name) {
      this.formItem[name] = url
    }
  }
}
</script>

<style lang="less">
.color_grey {
  color: #999;
}
.subevents-list {
  border-radius: 4px;
  border: 1px solid #ccc;
  margin-bottom: 20px;

  .ivu-form-item-error-tip {
    left: 80px;
  }

  .titleandbtn-box {
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
    height: 60px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #ccc;

    .title-box {
      font-size: 22px;
      font-weight: 800;
      flex: 1;
    }
    .btn-box {
      display: flex;

      .btn {
        display: block;
        color: #2d8cf0;
        margin-right: 10px;
      }
    }
  }
  .subevents-form-box {
    box-sizing: border-box;
    padding: 25px 15px;
  }
}
.img-choose-box {
  .content-box {
    // width: 519px;
    // height: 807px;
    width: 480px;
    height: 748px;
    position: relative;
    .img_back {
      width: 100%;
      height: 100%;
    }
    .img_address {
      width: 30px;
      height: 30px;
      position: absolute;
      top: 0;
      left: 0;
    }
    .border-box {
      width: 22px;
      height: 22px;
      position: absolute;
      border-radius: 50%;
      opacity: 0.7;
      background: rgba(56, 109, 231, 0.5);
      background: radial-gradient(
        ellipse at center,
        rgba(56, 109, 231, 0) 0,
        rgba(56, 109, 231, 0.5) 100%
      );
      .dot {
        position: absolute;
        left: 50%;
        top: 50%;
        width: 7px;
        height: 7px;
        margin: -3.5px 0 0 -4px;
        border-radius: 50%;
        background: #366be7;
        z-index: 1;
      }
    }
  }
}
</style>
