import request from '@/plugins/request'

// 大会日程编辑，特邀嘉宾列表获取
export function getGuestList(params) {
  return request({
    url: '/cms/oss/common/guest-data',
    method: 'get',
    params
  })
}
// 大会日程编辑，日程类型获取
export function getScheduleType(params) {
  return request({
    url: '/cms/oss/common/schedule-type',
    method: 'get',
    params
  })
}

export function getNewsType(params) {
  return request({
    url: '/cms/oss/common/hot_news_type',
    method: 'get',
    params
  })
}

export function getDataUrl(params) {
  return request({
    url: '/cms/oss/datatalk/url',
    method: 'get',
    params
  })
}

// 获取直播类型接口
export function getLiveTypeList(params) {
  return request({
    url: '/cms/oss/common/live-type',
    method: 'get',
    params
  })
}

// 获取cos配置
export function getCosConfigData(params) {
  return request({
    url: '/cms/oss/api/get_ticket',
    method: 'get',
    params
  })
}
// // 获取登陆地址
// export function getLoginUrl(params) {
//   return request({
//     url: '/cms/oss/index/get_login',
//     method: 'get',
//     params
//   })
// }

// // 获取语言版本
// export function GetLangData(params) {
//   return request({
//     url: '/cms/oss/common/lang',
//     method: 'get',
//     params
//   })
// }
// // 获取企业类型
// export function GetEnterpriseType(params, contentType, lag) {
//   console.log(contentType, lag, '+++++++++++++++++++')
//   if (contentType === 32) {
//     params = { ...params, content_model: 'resident_business_company', tag: lag }
//   } else if (contentType === 23) {
//     params = { ...params, content_model: 'exhibition_company', tag: lag }
//   } else if (contentType === 33) {
//     params = {
//       ...params,
//       content_model: 'resident_business_company_type',
//       tag: lag
//     }
//   } else if (contentType === 29) {
//     params = {
//       ...params,
//       content_model: 'footbridge_company',
//       tag: lag
//     }
//   }
//   return request({
//     url: '/cms/oss/common/company_type',
//     method: 'get',
//     params
//   })
// }
// // 获取跳转类型
// export function GetJumpType(params) {
//   return request({
//     url: '/cms/oss/common/exhibition_company_link_type',
//     method: 'get',
//     params
//   })
// }
// // 获取届数
// export function getSessionList(params) {
//   return request({
//     url: '/cms/oss/common/session-list',
//     method: 'get',
//     params
//   })
// }

// // 获取展示区域下拉
// export function getShowZone(params) {
//   return request({
//     url: '/cms/oss/common/show-zone',
//     method: 'get',
//     params
//   })
// }

// // 获取跳转展区下拉联动
// export function getExhibitor(params) {
//   return request({
//     url: '/cms/oss/common/exhibitor',
//     method: 'get',
//     params
//   })
// }

// // 获取跨境电商-综试区跳转类型下来
// export function getlinkType(params) {
//   return request({
//     url: '/cms/oss/common/partner-global-zone-link-type',
//     method: 'get',
//     params
//   })
// }

// // 获取关于天津智能大会跳转类型
// export function getOperateLinkType(params) {
//   return request({
//     url: '/cms/oss/common/content_operate_link_type',
//     method: 'get',
//     params
//   })
// }

// // 获取内容类型
// export function getContentType(params) {
//   return request({
//     url: '/cms/oss/common/partner-global-zone-link-type',
//     method: 'get',
//     params
//   })
// }

// // 官方活动与运营-官方直播-活动类型下拉
// export function getActivityType(params) {
//   return request({
//     url: '/cms/oss/common/official-activity-live-type',
//     method: 'get',
//     params
//   })
// }

// // 获取报道类型
// export function getReportType(params) {
//   return request({
//     url: '/cms/oss/common/report-type',
//     method: 'get',
//     params
//   })
// }

// // 获取区域
// export function getAboutRegion(params) {
//   return request({
//     url: '/cms/oss/common/content_operate_area',
//     method: 'get',
//     params
//   })
// }

// // 采购商-参会指引-栏目列表
// export function GetPurchaserColumnList(params) {
//   return request({
//     url: '/cms/oss/common/buyer_meeting_guide_column',
//     method: 'get',
//     params
//   })
// }

// // 参展商-参展指引-栏目列表
// export function GetExhibitorColumnList(params) {
//   return request({
//     url: '/cms/oss/common/exhibitor_guide_column',
//     method: 'get',
//     params
//   })
// }

// // 新闻资讯管理系统-新闻中心运营位-栏目下拉
// export function GetNewsColumnList(params) {
//   return request({
//     url: '/cms/oss/common/news_center_column',
//     method: 'get',
//     params
//   })
// }

// // 广告运营位-首页-广告位置下拉
// export function getAdPosition(params) {
//   let url = ''
//   switch (params.contentType) {
//     case 40:
//       url = '/cms/oss/common/ad_index_position'
//       break
//     case 41:
//       url = '/cms/oss/common/ad_exhibitor_live_position'
//       break
//     case 42:
//       url = '/cms/oss/common/ad_exhibitor_polymeric_position'
//       break
//     case 43:
//       url = '/cms/oss/common/ad_exhibitor_search_position'
//       break
//   }
//   return request({
//     url,
//     method: 'get',
//     params
//   })
// }

// // 展品类型
// export function GetProductTypeList(params) {
//   return request({
//     url: '/cms/oss/common/ad_polymeric_type',
//     method: 'get',
//     params
//   })
// }

// // 新闻资讯管理系统-新闻中心运营位-文章链接下拉
// export function GetNewsConterSelect(data) {
//   return request({
//     url: '/cms/oss/common/news_center_select',
//     method: 'post',
//     data
//   })
// }
// // 首页运营-新闻与活动-卡片类型
// export function GetCardType(data) {
//   return request({
//     url: '/cms/oss/common/card-type',
//     method: 'post',
//     data
//   })
// }
// // 首页运营-活动运营-卡片类型
// export function GetOperateCardType(data) {
//   return request({
//     url: '/cms/oss/common/card-type-operation',
//     method: 'post',
//     data
//   })
// }

// 大会嘉宾类型
export function getGuestTypeList(params) {
  return request({
    url: '/cms/oss/common/guest-type',
    method: 'get',
    params
  })
}

// 智能体验获取已经配置的地图点
export function getExperienceMapList(params) {
  return request({
    url: '/cms/oss/content/list',
    method: 'get',
    params
  })
}
