import request from '@/plugins/request'
const modelArr = [
  'register_agreement', // 1 'registrationAgreement-zh', // 注册协议-中文
  'register_agreement', // 2 'registrationAgreement-en', // 注册协议-英文
  'schedule_type', // 3 'schedule_type', // 大会日程-类型
  'schedule', // 4 'agendaofConference-zh', // 大会日程-中文
  'schedule', // 5 'agendaofConference-en', // 大会日程-英文
  'guest', // 6 'conferenceGuests-zh', // 大会嘉宾-中文
  'guest', // 7 'conferenceGuests-en', // 大会嘉宾-英文
  'sapiens_wise', // 8 'homoSapiens-zh', // 智人智语-中文
  'sapiens_wise', // 9 'homoSapiens-en', // 智人智语-英文
  'cloud_match', // 10 'cloudEvents-zh', // 云赛事-中文
  'cloud_match', // 11 'cloudEvents-en', // 云赛事-英文
  'cloud_match_article', // 12 'eventIntroduction-zh', // 赛事介绍文章-中文
  'cloud_match_article', // 13 'eventIntroduction-en', // 赛事介绍文章-英文
  '', // 14 '', // 云系列活动直播配置
  '', // 15 '',
  'cloud_activity_type', // 16 'cloudSeriesActivities-type', // 云系列活动-类型
  'cloud_activity', // 17 'cloudSeriesActivities-zn', // 云系列活动-中文
  'cloud_activity', // 18 'cloudSeriesActivities-en', // 云系列活动-英文
  'cloud_experience', // 19 'cloudIntelligentExperience-zh', // 云智能体验-中文
  'cloud_experience', // 20 'cloudIntelligentExperience-en', // 云智能体验-英文
  'news_info_type', // 21 'newsInformation-type', // 新闻资讯-类型
  'news_info', // 22 'newsInformation-zh', // 新闻资讯-中文
  'news_info', // 23 'newsInformation-en', // 热点新闻-英文
  'hot_news', // 24 'newsInformation-hotzh', // 热点新闻-英文
  'hot_news', // 25  'newsInformation-hoten',
  'cooperative_partner_type', // 26
  'cooperative_partner', // 27
  'cooperative_partner', // 28
  'hot_news_type', // 29
  'web_index_operate', // 30 pc首页配置
  'wap_index_operate', // 31 移动端首页配置
  'meeting_schedule', // 32 大会日程
  'meeting_schedule',
  'participant_guide', // 34 酒店协议
  'participant_guide',
  'live_room', // 36 直播Id列表
  'excellent_cases', // 37 wic优秀案例
  'excellent_cases',
  'page_show_config', // 39 页面呈现配置
]
const typeArr = [
  'list_online',
  'list_offline',
  'list_wait_online',
  'list_draft',
  'list_del'
]
// 获取列表数据
export function GetListData(data) {
  data.content_model = modelArr[data.content_type - 1]
  if (data.tree_id) {
    data.content_model = data.content_model.replace('_tree', '')
  }
  data.tab_type = typeArr[data.tab_type - 1]
  data.tag = data.lang_tag
  delete data.lang_tag
  delete data.content_type
  return request({
    url: '/cms/oss/content/list',
    method: 'get',
    params: data
  })
}
// 验证是否可以下架
export function verificationType(id, type) {
  const data = { _id: id, content_model: modelArr[type - 1] }
  console.log(id, type, data, '参数是否有问题+++++++++++')
  return request({
    url: '/cms/oss/common/enable_offline_company_type',
    method: 'post',
    data
  })
}
// 设置下架,删除状态
export function setStatus(data, type) {
  return request({
    url: '/cms/oss/content/update?operation_type=' + type,
    method: 'post',
    data
  })
}

// 获取新闻详情
export function getView(data) {
  data.tab_type = typeArr[data.tab_type - 1]
  return request({
    url: '/cms/oss/content/view',
    method: 'get',
    params: data
  })
}

// 删除新闻
export function deleteContent(data) {
  data.tab_type = typeArr[data.tab_type - 1]
  return request({
    url: '/cms/oss/content/delete',
    method: 'post',
    data
  })
}

// 编辑保存预览新闻
export function saveContent(data) {
  data.other_data.content_model = modelArr[data.content_type - 1]
  delete data.content_type
  if (data.other_data.tree_id) {
    data.other_data.content_model = data.other_data.content_model.replace(
      '_tree',
      ''
    )
  }
  return request({
    url: '/cms/oss/content/create',
    method: 'post',
    data
  })
}

// 预览接口地址
export function getPreview(data) {
  data.content_model = modelArr[data.content_type - 1]
  delete data.content_type
  if (data.tree_id) {
    data.content_model = data.content_model.replace('_tree', '')
  }
  data.tab_type = typeArr[data.tab_type - 1]
  return request({
    url: '/cms/oss/content/preview',
    method: 'post',
    data
  })
}

// 获取树结构
export function GetTreeList(data) {
  data.content_model = modelArr[data.content_type - 1]
  data.tab_type = typeArr[data.tab_type - 1]
  data.tag = data.lang_tag
  delete data.lang_tag
  delete data.content_type
  return request({
    url: '/cms/oss/tree/list',
    method: 'get',
    params: data
  })
}

// 添加子级
export function addTreeChildren(data) {
  if (!data.other_data) {
    data.other_data = {}
  }
  data.other_data.content_model = modelArr[data.content_type - 1]
  data.tab_type = typeArr[data.tab_type - 1]
  delete data.content_type
  return request({
    url: '/cms/oss/tree/create',
    method: 'post',
    data
  })
}

// 修改栏目名称
export function editTree(data) {
  if (!data.other_data) {
    data.other_data = {}
  }
  data.other_data.content_model = modelArr[data.content_type - 1]
  data.tab_type = typeArr[data.tab_type - 1]
  delete data.content_type
  return request({
    url: '/cms/oss/tree/create',
    method: 'post',
    data
  })
}

// 删除栏目
export function deleteTree(data) {
  if (!data.other_data) {
    data.other_data = {}
  }
  data.other_data.content_model = modelArr[data.content_type - 1]
  data.tab_type = typeArr[data.tab_type - 1]
  delete data.content_type
  return request({
    url: '/cms/oss/tree/delete',
    method: 'post',
    data
  })
}

// 上移下移栏目
export function moveTree(data) {
  if (!data.other_data) {
    data.other_data = {}
  }
  data.other_data.content_model = modelArr[data.content_type - 1]
  data.tab_type = typeArr[data.tab_type - 1]

  return request({
    url: '/cms/oss/tree/up_or_down',
    method: 'post',
    data
  })
}

// 上移下移栏目
export function pushTree(data) {
  data.content_model = modelArr[data.content_type - 1]
  delete data.content_type
  return request({
    url: '/cms/oss/tree/update?operation_type=1',
    method: 'post',
    data
  })
}

export function questionnaire(params) {
  return request({
    url: '/cms/oss/questionnaire/list',
    method: 'get',
    params
  })
}

export function questionnaireDetail(params) {
  return request({
    url: '/cms/oss/questionnaire/detail',
    method: 'get',
    params
  })
}

export function questionnaireDelete(params) {
  return request({
    url: '/cms/oss/questionnaire/delete',
    method: 'get',
    params
  })
}

export function enterprise(params) {
  return request({
    url: '/cms/oss/questionnaire/list_enterprise',
    method: 'get',
    params
  })
}

// 峰会论坛投票列表
export function getVoteList(params) {
  return request({
    url: '/cms/oss/vote/list',
    method: 'get',
    params
  })
}
