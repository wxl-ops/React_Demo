import request from '@/plugins/request'

export function AccountLogin(data) {
  return request({
    url: '/api/login',
    method: 'post',
    data
  })
}

export function getLoginUrl(data) {
  return request({
    url: '/merchant/login-api/login_url',
    method: 'get',
    data
  })
}

export function AccountRegister(data) {
  return request({
    url: '/api/register',
    method: 'post',
    data
  })
}

export function AccountLogout(data) {
  return request({
    url: '/cms/oss/user/logout',
    method: 'get',
    data
  })
}

// 获取用户权限
export function GetPermission(params) {
  return request({
    url: '/cms/permission/index',
    method: 'get',
    params
  })
}
