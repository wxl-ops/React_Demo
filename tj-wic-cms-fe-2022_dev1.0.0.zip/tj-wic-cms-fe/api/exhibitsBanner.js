import request from '@/plugins/request'

// 获取列表数据
export function GetListData(data) {
  return request({
    url: '/cms/exhibits-banner/list',
    method: 'get',
    params: data
  })
}

// 获取列表数据
export function setStatus(data, type) {
  return request({
    url: '/cms/exhibits-banner/update?operation_type=' + type,
    method: 'post',
    data
  })
}

// 获取详情
export function getInfoData(data) {
  return request({
    url: '/cms/exhibits-banner/view',
    method: 'get',
    params: data
  })
}

// 创建
export function createData(data) {
  return request({
    url: '/cms/exhibits-banner/create',
    method: 'post',
    data
  })
}

// 编辑
export function saveData(data) {
  return request({
    url: '/cms/exhibits-banner/update?operation_type=1',
    method: 'post',
    data
  })
}
