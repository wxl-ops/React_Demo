import request from '@/plugins/request'

// 邀请码列表
export function getInvitationCodeList(params) {
  return request({
    url: '/cms/oss/invitationcode/list',
    method: 'get',
    params
  })
}
// 添加/修改
export function updateInvitationCode(data) {
  return request({
    url: '/cms/oss/invitationcode/save',
    method: 'post',
    data
  })
}

// 导入
export function importInvitationCode(params) {
  return request({
    url: '/cms/oss/invitationcode/import',
    method: 'get',
    params
  })
}

// 导出
export function exportInvitationCode(params) {
  return request({
    url: '/cms/oss/invitationcode/export',
    method: 'get',
    params
  })
}

// 获取邀请码状态
export function getInvitationStatusList(params) {
  return request({
    url: '/cms/oss/common/invitation_code_status',
    method: 'get',
    params
  })
}

// 删除邀请码
export function delInvitationCode(data) {
  return request({
    url: '/cms/oss/invitationcode/delete',
    method: 'post',
    data
  })
}
