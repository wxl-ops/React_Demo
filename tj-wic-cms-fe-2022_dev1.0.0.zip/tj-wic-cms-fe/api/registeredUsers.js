import request from '@/plugins/request'

// 注册用户列表
export function getRegisteredUsersList(params) {
  return request({
    url: '/cms/oss/user/list',
    method: 'get',
    params
  })
}

// 用户类型列表
export function getUsersTypeList(params) {
  return request({
    url: '/cms/oss/common/user_type',
    method: 'get',
    params
  })
}

// 注册用户详情
export function getUsersDetail(params) {
  return request({
    url: '/cms/oss/user/show',
    method: 'get',
    params
  })
}
