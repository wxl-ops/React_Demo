import Vue from 'vue'
import plugins from './plugins'

Vue.use(plugins)
