import api from '@/wau/api/index'
import wauComponents from '@/wau/components'

export default {
  install(Vue) {
    Vue.prototype.$api = {
      wau: {
        ...api
      }
    }
    Object.keys(wauComponents).forEach((key) => {
      Vue.component(key, wauComponents[key])
    })
  }
}
