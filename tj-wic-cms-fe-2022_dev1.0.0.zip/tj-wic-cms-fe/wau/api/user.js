import request from '@/plugins/request'

export default {
  list(data) {
    return request({
      url: `/api/user/list`,
      method: 'post',
      data
    })
  },
  info(data) {
    return request({
      url: `/api/user/info`,
      method: 'post',
      data
    })
  },
  create(data) {
    return request({
      url: `/api/user/add`,
      method: 'post',
      data
    })
  },
  update(data) {
    return request({
      url: `/api/user/update`,
      method: 'post',
      data
    })
  },
  delete(data) {
    return request({
      url: `/api/user/delete`,
      method: 'post',
      data
    })
  }
}
