import request from '@/plugins/request'

export default {
  list(data) {
    return request({
      url: `/api/dict/list`,
      method: 'post',
      data
    })
  },
  info(data) {
    return request({
      url: `/api/dict/info`,
      method: 'post',
      data
    })
  },
  create(data) {
    return request({
      url: `/api/dict/add`,
      method: 'post',
      data
    })
  },
  update(data) {
    return request({
      url: `/api/dict/update`,
      method: 'post',
      data
    })
  },
  delete(data) {
    return request({
      url: `/api/dict/delete`,
      method: 'post',
      data
    })
  },
  generate(data) {
    return request({
      url: `/api/dict/generate`,
      method: 'post',
      data
    })
  }
}
