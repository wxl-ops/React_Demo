import user from './user'
import dict from './dict'

export default {
  user,
  dict
}
