<template>
  <Modal v-model="model" title="删除" @on-ok="ok" @on-cancel="cancel">
    <Alert type="warning" show-icon
      >是否确认删除 <b>{{ value.content }}</b> ?</Alert
    >
  </Modal>
</template>
<script>
export default {
  name: 'WDeleteModal',
  props: {
    value: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  data() {
    return {
      model: false
    }
  },
  watch: {
    value(val) {
      if (this.value.show) {
        this.model = true
      }
    }
  },
  methods: {
    ok() {
      this.$emit('on-ok', this.value)
    },
    cancel() {
      // this.$Message.info('Clicked cancel');
    }
  }
}
</script>
