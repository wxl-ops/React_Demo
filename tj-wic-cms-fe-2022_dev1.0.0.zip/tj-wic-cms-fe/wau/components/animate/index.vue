<template>
  <transition name="fade">
    <slot></slot>
  </transition>
</template>
<script>
export default {
  name: 'WAnimate'
}
</script>
<style lang="less" scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
