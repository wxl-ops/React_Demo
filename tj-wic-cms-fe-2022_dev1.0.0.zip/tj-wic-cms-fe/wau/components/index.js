import WImage from './image'
import WPhotoSwipe from './photo-swipe'
import WPageHeader from './page-header'
import WPageContent from './page-content'
import WIframe from './iframe'
import WAnimate from './animate'
// import WCodeEditor from './code-editor' // 尽量不要在全局引入
import WUpload from './upload'
import WDeleteModal from './delete-modal'
import WAuth from './auth'

export default {
  WImage,
  WPhotoSwipe,
  WPageHeader,
  WPageContent,
  WIframe,
  WAnimate,
  // WCodeEditor,
  WUpload,
  WDeleteModal,
  WAuth
}
