<template>
  <div class="w-page-header" :class="{ 'no-tab': !hasTab }">
    <Row>
      <i-col span="12" class="w-page-header-title">
        <div class="w-page-header-titlebar">
          <slot v-if="back" name="back">
            <Icon type="md-arrow-back" @click="handleBack" />
            <Divider type="vertical" />
          </slot>
          <slot name="title"></slot>
        </div>
      </i-col>
      <i-col span="12" class="ivu-text-right w-page-header-action">
        <slot name="action"></slot>
      </i-col>
    </Row>
    <Row>
      <i-col span="12" class="w-page-header-content">
        <slot name="content"></slot>
      </i-col>
      <i-col span="12" class="ivu-text-right w-page-header-extra">
        <slot name="extra"></slot>
      </i-col>
    </Row>
    <Row>
      <Tabs
        v-if="tabList.length > 0"
        :value="tabActiveKey"
        @on-click="handleTab"
      >
        <TabPane
          v-for="(tab, index) in tabList"
          :key="index"
          class="ivu-mb-0"
          :label="tab.label"
          :name="tab.name"
        ></TabPane>
      </Tabs>
    </Row>
  </div>
</template>

<script>
export default {
  name: 'WPageHeader',
  props: {
    back: {
      type: Boolean,
      default: false
    },
    tabList: {
      type: Array,
      default() {
        return []
      }
    },
    tabActiveKey: {
      type: String,
      default: ''
    }
  },
  data() {
    return {}
  },
  computed: {
    hasTab() {
      return this.tabList.length > 0
    }
  },
  methods: {
    handleBack() {
      this.$emit('on-back')
    },
    handleTab(tabName) {
      this.$emit('on-tab-click', tabName)
    }
  }
}
</script>

<style lang="less">
.w-page-header {
  padding: 16px 32px 0 32px;
  line-height: 30px;
  background-color: #fff;
  border-bottom: 1px solid #dcdee2;
  &.no-tab {
    // padding-bottom: 16px;
  }
  &-titlebar {
    position: relative;
    h2 {
      font-size: 20px;
    }
    // margin-bottom: 8px;
    .ivu-icon-md-arrow-back {
      position: relative;
      top: 5px;
      font-size: 20px;
      cursor: pointer;
    }
    .ivu-divider {
      position: relative;
      top: 10px;
    }
    height: 30px;
    line-height: 30px;
    display: flex;
  }
  &-title {
    margin-bottom: 16px;
  }
  .ivu-tabs-bar {
    border-bottom: 0;
    margin-bottom: 0px;
  }
}
.wau-content-crumb {
  .w-page-header {
    margin-top: 0;
  }
}
</style>
