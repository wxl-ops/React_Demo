<template>
  <div class="w-page-content">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'WPageContent'
}
</script>

<style lang="less">
.w-page-content {
  margin: 16px;
}
</style>
