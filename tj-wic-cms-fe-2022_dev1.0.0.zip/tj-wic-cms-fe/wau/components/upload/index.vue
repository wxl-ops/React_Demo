<template>
  <div class="r-upload">
    <Uploader
      v-if="!readonly"
      ref="upload"
      :style="{ display: isApk && apkResult ? 'none' : 'initial' }"
      :upto="upto"
      :show-upload-list="false"
      :default-file-list="defaultList"
      :on-success="handleSuccess"
      :format="format"
      :max-size="maxSize"
      :on-format-error="handleFormatError"
      :on-exceeded-size="handleMaxSize"
      :before-upload="handleBeforeUpload"
      :on-custom="handleCustom"
      :multiple="multiple"
      :type="type"
      :name="name"
      :data="currentParams"
      :qcloud="qcloud"
      :action="action"
    >
      <Button class="upload-btn" :icon="icon">{{ text }}</Button>
      <div
        ref="noticeText"
        class="notice-text"
        :title="notice"
        :style="{ width: noticeWidth }"
      >
        {{ notice }}
      </div>
    </Uploader>
    <span v-if="readonly && compValue.length === 0">{{ placeholder }}</span>
    <input v-if="compValue.length === 0" type="hidden" :name="name" value="" />
    <div v-if="preview" :style="styles">
      <div
        v-for="(item, index) in compValue"
        :key="index"
        class="r-upload-list"
      >
        <template v-if="item.status === 'finished'">
          <div v-if="fileType === 'image'">
            <img class="r-upload-img" :src="item.url" :alt="name" />
            <input
              v-if="shouldSubmitId"
              v-model="item.combo"
              type="hidden"
              :name="name"
            />
            <input v-else v-model="item.url" type="hidden" :name="name" />
            <div class="r-upload-list-cover">
              <Icon
                type="ios-eye-outline"
                @click.native="handleView(index)"
              ></Icon>
              <Icon
                v-if="!readonly"
                type="ios-trash-outline"
                @click.native="handleRemove(item, index)"
              ></Icon>
            </div>
          </div>
          <div v-if="fileType === 'video'">
            <video class="r-upload-video" :src="item.url"></video>
            <input v-model="item.url" type="hidden" :name="name" />
            <div class="r-upload-list-cover">
              <Icon
                type="ios-eye-outline"
                @click.native="handlePlay(index)"
              ></Icon>
              <Icon
                v-if="!readonly"
                type="ios-trash-outline"
                @click.native="handleRemove(item, index)"
              ></Icon>
            </div>
          </div>
          <div v-if="fileType === 'audio'">
            <img
              class="r-upload-audio"
              src="https://fe-1252759886.cos.ap-guangzhou.myqcloud.com/icons/audio_file.png"
            />
            <input v-model="item.url" type="hidden" :name="name" />
            <div class="r-upload-list-cover">
              <Icon
                type="ios-eye-outline"
                @click.native="handlePlay(index)"
              ></Icon>
              <Icon
                v-if="!readonly"
                type="ios-trash-outline"
                @click.native="handleRemove(item, index)"
              ></Icon>
            </div>
          </div>
          <div v-else-if="fileType === 'file'">
            <r-image
              class="r-upload-img"
              value="http://rocket.qinmudi.cn/filetype/file.png"
            ></r-image>
            <input v-model="item.url" type="hidden" :name="name" />
            <div class="r-upload-list-cover">
              <Icon
                type="ios-trash-outline"
                @click.native="handleRemove(item, index)"
              ></Icon>
            </div>
          </div>
        </template>
        <template v-else>
          <Progress
            v-if="item.showProgress"
            :percent="item.percentage"
            hide-info
          ></Progress>
        </template>
      </div>
    </div>
    <!-- 上传单个文件结果 -->
    <div v-if="isApk">
      <div :style="{ display: apkResult ? 'none' : 'initial' }">
        <div v-for="(item, index) in compValue" :key="index">
          <input v-model="item.url" type="hidden" :name="name" />
          <Progress
            v-if="item.showProgress"
            :percent="item.percentage"
            hide-info
          ></Progress>
        </div>
      </div>
      <div v-if="apkResult" class="r-texts">
        <div class="notice-text">已上传</div>
        <div v-for="(item, idx) in apkResult" :key="idx">{{ item }}</div>
        <button
          type="button"
          class="upload-btn ivu-btn ivu-btn-default"
          @click="handleRemove(compValue[0], 0)"
        >
          删除文件
        </button>
      </div>
    </div>
  </div>
</template>
<script>
import Uploader from './upload'
// import { isEmpty } from 'lodash'
import { formatImageData, searchPool } from '@/libs/utils'
import formItem from '@/mixins/formItem'
let timer = -1

export default {
  name: 'WUpload',
  components: {
    Uploader
  },
  mixins: [formItem],
  props: {
    isApk: {
      type: Boolean,
      default: false
    },
    preview: {
      type: Boolean,
      default: true
    },
    icon: {
      type: String,
      default: 'ios-cloud-upload-outline'
    },
    type: {
      type: String,
      default: 'select'
    },
    action: {
      type: String,
      default: ''
    },
    multiple: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: true
    },
    name: {
      type: String,
      default: name
    },
    format: {
      type: Array,
      default() {
        return []
      }
    },
    maxSize: {
      type: Number,
      default: 2048
    },
    maxCount: {
      type: Number,
      default: 1
    },
    styles: {
      type: String,
      default: ''
    },
    text: {
      type: String,
      default: '上传图片'
    },
    noticeWidth: {
      type: String,
      default: ''
    },
    notice: {
      type: String,
      default: '建议尺寸750px*400px*，上传与展示顺序一致'
    },
    upto: {
      type: String,
      default: 'qcloud'
    },
    fileType: {
      type: String,
      default: 'image'
    },
    value: {
      type: [String, Array],
      default() {
        return []
      }
    },
    apkResult: {
      type: Array,
      default() {
        return []
      }
    },
    poolValue: {
      type: String,
      default: 'image'
    },
    readonly: {
      type: Boolean,
      default: false
    },
    qcloud: {
      type: Object,
      default() {
        return {
          appId: '',
          bucket: '',
          region: '',
          folder: '',
          authUrl: ''
        }
      }
    },
    params: {
      type: Object,
      default() {
        return {}
      }
    },
    placeholder: {
      type: String,
      default: ''
    },
    shouldSubmitId: Boolean
  },
  data() {
    return {
      defaultList: [],
      visible: false,
      uploadList: [],
      currentValue: [],
      currentParams: this.params
    }
  },
  computed: {
    compValue() {
      return this.uploadList
    }
  },
  watch: {
    currentValue(valList) {
      if (typeof valList === 'string') {
        valList = [valList]
      }
      if (this.upto !== 'mp') {
        const resList =
          valList &&
          valList.map((item) => {
            return { name: `${Date.now()}`, url: item, status: 'finished' }
          })
        this.defaultList = resList || []
        this.uploadList = resList || []
      } else {
        // 只有upto为mp，上传到数据中心的情况下会用到shouldSubmitId
        const { shouldSubmitId } = this
        this.uploadList = []
        valList &&
          valList.map((item) => {
            if (item) {
              const file = { name: `${Date.now()}`, status: 'finished' }
              if (shouldSubmitId) {
                file.url = item.url
                file.id = item.id
                file.combo =
                  '__combo:' + JSON.stringify({ id: item.id, url: item.url })
              } else {
                file.url = item
              }
              this.uploadList.push(file)
            }
          })
      }
    }
  },
  mounted() {
    if (this.value) {
      this.currentValue = this.value
    }
    if (this.upto !== 'mp') {
      this.uploadList = this.$refs.upload.fileList
    } else {
      this.$bus.on('iframe.choosen', ({ channel, type, list }) => {
        if (this.rid === channel) {
          this.selected(type, list)
        }
      })
    }
  },
  destroyed() {
    this.$bus.off('iframe.choosen')
    this.uploadList = []
  },
  methods: {
    handleView(index) {
      const files = this.uploadList.map((file) => {
        return {
          name: file.name,
          src: file.url
        }
      })
      formatImageData(files, (imgs) => {
        this.$bus.emit('photoswipe.shown', imgs, index)
      })
    },
    handlePlay(index) {
      const videos = this.uploadList.map((file) => {
        return {
          name: file.name,
          src: file.url
        }
      })
      const { src } = videos[index]
      if (this.fileType === 'video') {
        this.$Modal.info({
          width: 750,
          draggable: true,
          render: (h) => {
            return [
              h('r-player', {
                props: {
                  autoplay: true,
                  value: {
                    play_url: src
                  },
                  width: '100%',
                  height: '400'
                }
              })
            ]
          }
        })
      } else {
        this.$Modal.info({
          width: 500,
          draggable: true,
          render: (h) => {
            return [
              h('audio', {
                style: {
                  width: '100%'
                },
                attrs: {
                  controls: 'controls',
                  autoplay: true,
                  src
                }
              })
            ]
          }
        })
      }
    },
    handleRemove(file, index) {
      if (this.upto !== 'mp') {
        debugger
        const fileList = this.$refs.upload.fileList
        this.uploadList.splice(fileList.indexOf(file), 1)
        // this.value.splice(index, 1)
        // this.compValue.splice(fileList.indexOf(file), 1)
        const imgs = this.uploadList.map(({ url, id }) => {
          return this.shouldSubmitId ? { url, id } : url
        })
        this._aysncData(this.name, imgs)
        if (this.isApk) {
          this.apkResult = null
        }
      } else {
        this.uploadList.splice(index, 1)
        // this.value.splice(index, 1)
        const imgs = this.uploadList.map(({ url, id }) => {
          return this.shouldSubmitId ? { url, id } : url
        })
        this._aysncData(this.name, imgs)
      }
    },
    handleSuccess({ data, msg }, file) {
      if (!data) {
        const errorMessage = msg || '文件上传失败！'
        this.$Message.error(errorMessage)
        if (this.isApk) {
          this.handleRemove(this.compValue[0], 0)
        }
        return
      }
      file.name = data.name
      file.url = data.url
      file.id = data.id
      this.$bus.emit('upload.success', data)
      const imgs = this.uploadList.map(({ url, id }) => {
        return this.shouldSubmitId ? { url, id } : url
      })
      this._aysncData(this.name, imgs)
      if (!this.preview) {
        const message = msg || '文件上传成功！'
        this.$Message.success(message)
        const result = data && data.result
        // this.apkResult = typeof result === 'string' ? [result] : result
        this.apkResult = result
      }
    },
    handleFormatError(file) {
      this.$Notice.warning({
        title: '文件格式不正确',
        desc: `${file.name}的文件格式不正确，请仔细检查是否正确！`
      })
    },
    handleMaxSize(file) {
      this.$Notice.warning({
        title: '文件大小超出限制',
        desc: `文件${file.name}大小超出限制！`
      })
    },
    handleBeforeUpload() {
      this.uploadList = this.$refs.upload.fileList
      const check = this.uploadList.length < this.maxCount
      if (!check) {
        this.$Notice.warning({
          title: `最多可以上传${this.maxCount}个文件!`
        })
      }
      return check
    },
    handleCustom() {
      this.$emit('click')
    },
    selected(type, list) {
      // console.log(`------------${this.rid}---------------`)
      // console.log(JSON.stringify(list), type)
      // if (type === 'image') {
      /* eslint camelcase: 0 */
      list.some(({ id, url, file_id, name, cover_url, play_url }) => {
        const check = this.uploadList.length < this.maxCount
        if (!check) {
          this.$Notice.warning({
            title: `最多可以上传${this.maxCount}个文件!`
          })
          return true
        } else {
          // console.log(`url->${url}`)
          // hack 给value加上__combo: 前缀
          const file = { id, name: `${Date.now()}`, url, status: 'finished' }
          if (this.shouldSubmitId) {
            file.combo = '__combo:' + JSON.stringify({ id, url })
          }
          if (this.fileType !== 'image') {
            file.file_id = file_id
            file.name = name
            file.cover_url = cover_url
            file.url = play_url
          }
          this.uploadList.push(file)
          if (this.name.includes('[]')) {
            const imgs = this.uploadList.map(({ url, id }) => {
              return this.shouldSubmitId ? { url, id } : url
            })
            this._aysncData(this.name, imgs)
          } else {
            const url = this.uploadList[0].url
            const id = this.uploadList[0].id
            this._aysncData(this.name, this.shouldSubmitId ? { url, id } : url)
          }
        }
      })
      // }
    },
    _aysncData(name, value) {
      this.$bus.emit('form.change', name, value)
      if (searchPool(this.poolValue)) {
        this.$bus.emit('pool/' + searchPool(this.poolValue).pool + '/set', {
          params: { [searchPool(this.poolValue).value]: value }
        })
      }
    },
    _appendValue({ params }) {
      // clearTimeout(timer)
      // timer = setTimeout(() => {
      const { channel, type, list } = params
      if (channel === this.rid) {
        // console.log('append', type, list)
        clearTimeout(timer)
        timer = setTimeout(() => {
          if (['image', 'video', 'audio'].includes(type)) {
            this.selected(type, list)
          }
        }, 300)
      }
      // }, 300)
    }
  }
}
</script>
<style lang="less">
.r-upload {
  @color_1: #fff;
  .upload-btn {
    margin-bottom: 15px;
  }
  &.upload-inline {
    float: left;
    .ivu-upload-select {
      display: inline;
    }
  }
  .notice-text {
    display: inline-block;
    // margin-left: 10px;
    // width: calc(100% - 90px);
    width: 100%;
    overflow: hidden;
  }
  .r-upload-list {
    display: inline-block;
    width: 140px;
    height: 80px;
    text-align: center;
    line-height: 80px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    // margin-top: 20px;
    margin-right: 4px;
    img {
      width: 100%;
      height: 100%;
    }
    .r-upload-img,
    .r-upload-video,
    .r-upload-audio {
      width: 140px;
      height: 80px;
    }
    &:hover {
      .r-upload-list-cover {
        display: block;
      }
    }
  }
  .ivu-upload + .r-upload-list {
    margin-top: 20px;
  }
  .r-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
    i {
      color: @color_1;
      font-size: 20px;
      cursor: pointer;
      margin: 0 2px;
    }
  }
}
.r-preview-title {
  margin-bottom: 10px;
  font-size: 14px;
  font-weight: bolder;
}
.delete-btn {
  cursor: pointer;
}
</style>
