import { mapState, mapMutations } from 'vuex'
import { get } from 'lodash'

export default {
  data() {
    return {
      selectedData: []
    }
  },
  computed: {
    ...mapState('wau/page', ['pager']),
    limitData() {
      const data = [...this.list]
      // 判断是否有选中的数据
      const selectedNames = this.selectedData.map((item) => item.id)
      data.map((item) => {
        item._checked = selectedNames.includes(item.id)
        return item
      })
      return data
    },
    dataWithPage() {
      const data = this.limitData
      return data
    },
    totalSelectedCount() {
      let count = 0
      this.selectedData.forEach((item) => {
        count += item.count
      })
      return count
    }
  },
  methods: {
    ...mapMutations('wau/page', ['changePager']),
    async getList({ condition = {}, apiName }) {
      this.$router.push({ query: condition })
      this._setPageLoading(true)
      const { current, pageSize } = this.pager
      const data = {
        offset: (current - 1) * pageSize,
        count: pageSize,
        ...condition
      }
      const api = get(this.$api, apiName)
      const { list = [], total = 0 } = await api(data)
      this._setPageLoading(false)
      this.changePager({ total })
      return list
    },
    // 点击排序按钮时触发
    handleSortChange({ key, order }) {
      this.sortColumns = key
      this.sortType = order
      this.getList()
    },
    // 选中一项，将数据添加至已选项中
    handleSelect(selection, row) {
      this.selectedData.push(row)
    },
    // 取消选中一项，将取消的数据从已选项中删除
    handleSelectCancel(selection, row) {
      const index = this.selectedData.findIndex((item) => item.id === row.id)
      this.selectedData.splice(index, 1)
    },
    // 当前页全选时，判断已选数据是否存在，不存在则添加
    handleSelectAll(selection) {
      selection.forEach((item) => {
        if (this.selectedData.findIndex((i) => i.id === item.id) < 0) {
          this.selectedData.push(item)
        }
      })
    },
    // 取消当前页全选时，将当前页的数据（即 dataWithPage）从已选项中删除
    handleSelectAllCancel() {
      const selection = this.dataWithPage
      selection.forEach((item) => {
        const index = this.selectedData.findIndex((i) => i.id === item.id)
        if (index >= 0) {
          this.selectedData.splice(index, 1)
        }
      })
    },
    // 清空所有已选项
    handleClearSelect() {
      this.selectedData = []
    },
    getSelectedField(name) {
      const result = []

      this.selectedData.forEach((item) => {
        result.push(item[name])
      })
      return result
    },
    changePage(current) {
      this.changePager({ current })
      this.getData(this.$route.query)
    },
    changePageSize(pageSize) {
      this.changePager({ pageSize })
      this.getData(this.$route.query)
    },
    refresh() {
      this.handleClearSelect()
      this.getData(this.$route.query)
    }
  }
}
