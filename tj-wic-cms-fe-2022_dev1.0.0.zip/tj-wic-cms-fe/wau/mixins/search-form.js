export default {
  mounted() {
    const { query } = this.$route
    this.searchData = query
  }
}
