import { get } from 'lodash'
import statusMix from '@/wau/mixins/status'

export default {
  mixins: [statusMix],
  computed: {
    labelWidth() {
      return 140
    },
    labelPosition() {
      return 'right'
    }
  },
  methods: {
    getAction(id) {
      if (id) {
        return { action: 'update', content: '更新成功，2s后返回列表！' }
      } else {
        return { action: 'create', content: '创建成功，2s后返回列表！' }
      }
    },
    getAPI(api) {
      if (typeof api === 'string') {
        return get(this.$api, api)
      } else {
        return api
      }
    },
    addOrUpdate(id, apiName) {
      return new Promise((resolve, reject) => {
        this.$refs.form.validate(async (valid) => {
          if (valid) {
            this._setPageLoading(true)
            const { action, content } = this.getAction(id)
            const api = this.getAPI(apiName)
            await api[action](this.form)
            this.$Message.success({
              background: true,
              content,
              onClose: () => {
                resolve()
              }
            })
            this._setPageLoading(false)
          }
        })
      })
    }
  }
}
