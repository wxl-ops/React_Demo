import { mapState, mapMutations } from 'vuex'

export default {
  computed: {
    ...mapState('wau/status', ['pageCreating'])
  },
  methods: {
    ...mapMutations('wau/status', ['setLoadingStatus']),
    _setPageLoading(status) {
      this.setLoadingStatus({
        field: 'pageCreating',
        status
      })
    }
  }
}
