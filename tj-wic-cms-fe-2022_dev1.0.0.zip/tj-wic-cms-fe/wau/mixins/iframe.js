import { IframePost } from '@/libs/iframe/index'
export default {
  created() {
    this.$bus.off('wau.iframe.resize')
    this.$bus.off('wau.iframe.Message')
    this.$bus.off('wau.iframe.Notice')
    this.$bus.off('wau.iframe.Modal')
  },
  mounted() {
    const iframe = new IframePost.Model({
      test: (data) => {
        console.log(data)
        // data = JSON.parse(data)
        // if(data.id){
        //   iframe.callBack[data.id][data.callName]()
        // }
      }
    })
    iframe.mid = 1
    iframe.callBack = {}
    function getMid() {
      return iframe.mid++
    }
    this.$bus.on('wau.iframe.resize', () => {
      iframe.then((parent) => {
        parent.emit(
          'iframe.resize',
          document.height || document.body.offsetHeight
        )
        parent.emit('wau.post.test', { id: 1, name: 'erikqin' })
      })
    })

    this.$bus.on('wau.iframe.Message', (data) => {
      iframe.then((parent) => {
        parent.emit('wau.post.Message', data)
        parent.emit('wau.post.test', { id: 1, name: 'erikqin' })
      })
    })

    this.$bus.on('wau.iframe.Notice', (data) => {
      iframe.then((parent) => {
        parent.emit('wau.post.Notice', data)
        parent.emit('wau.post.test', { id: 1, name: 'erikqin' })
      })
    })

    this.$bus.on('wau.iframe.Modal', (data) => {
      data.id = getMid()
      if (data.callback) {
        iframe.callBack[data.id] = data.callback
        console.log(iframe.callBack[data.id], 'iframe.callBack')
        // 不需要传，callback 也不能传
        delete data.callback
      }
      iframe.then((parent) => {
        parent.emit('wau.post.Modal', data)
        parent.emit('wau.post.test', { id: 1, name: 'erikqin' })
      })
    })
  }
}
