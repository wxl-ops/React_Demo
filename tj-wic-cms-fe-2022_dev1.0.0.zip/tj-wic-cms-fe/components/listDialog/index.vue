<template>
  <Modal
    v-model="isDialogShow"
    title="选择"
    :width="900"
    :closable="false"
    :mask-closable="false"
  >
    <div class="listdiaog-search-box">
      <Input v-model="queryData.keyWord" placeholder="请输入关键字" />
      <div class="btn-box">
        <Button type="primary" class="btn" @click="onSearch">检索</Button>
        <Button @click="onReset">清空</Button>
      </div>
    </div>
    <div class="listdiaog-table">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
        highlight-row
        @on-current-change="onCurrentColChange"
      ></Table>
      <div class="listdiaog-table-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="pagination.current_page"
            @on-change="changePage"
          ></Page>
        </div>
      </div>
    </div>

    <div slot="footer">
      <Button @click="onCancel">取消</Button>
      <Button type="primary" @click="onSubmit">确定</Button>
    </div>
  </Modal>
</template>

<script>
import { GetListData } from '@/api/content'
export default {
  components: {},
  props: {
    contentType: {
      type: Number,
      default: 1
    },
    show: {
      type: Boolean,
      default: false
    },
    searchType: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      tableLoading: false,
      tableColumns: [
        {
          title: '序号',
          type: 'index',
          width: 80,
          align: 'center'
        },
        { title: '论坛标题', key: 'title', minWidth: 160 },
        {
          title: '论坛时间',
          key: 'schedule_time',
          align: 'center',
          width: 200
        },
        {
          title: '最后发布时间',
          key: 'publish_time',
          align: 'center',
          width: 200
        }
      ],
      listData: [],
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      queryData: {
        page_size: 10,
        keyWord: '',
        p: 1
      },
      isDialogShow: false,
      content_type: 1,
      chooseColumn: '',
      search_type: 1
    }
  },
  watch: {
    searchType(newValue, oldValue) {
      this.search_type = newValue
    },
    contentType(newValue, oldValue) {
      this.content_type = newValue
    },
    show(newValue, oldValue) {
      this.isDialogShow = newValue
      if (this.isDialogShow) {
        this.getListData()
      }
    }
  },

  methods: {
    onSearch() {
      this.queryData.p = 1
      this.getListData()
    },
    onReset() {
      this.queryData.p = 1
      this.queryData.keyWord = ''
      this.getListData()
    },
    // 当前行发生变化
    onCurrentColChange(currentRow, oldCurrentRow) {
      this.chooseColumn = currentRow
    },
    // 取消
    onCancel() {
      this.queryData.p = 1
      this.$emit('cancel')
    },
    // 确定
    onSubmit() {
      if (this.chooseColumn === '') {
        this.$Message.error('请单击行选择一条数据')
        return false
      }
      this.queryData.p = 1
      this.$emit('sure', this.chooseColumn)
    },
    // 页数变化
    changePage(page) {
      this.queryData.p = page
      this.getListData()
    },
    // 拉取列表数据
    getListData() {
      this.tableLoading = true
      this.listData = []
      this.chooseColumn = ''
      this.tableColumns = [
        {
          title: '序号',
          type: 'index',
          width: 80,
          align: 'center'
        },
        { title: '论坛标题', key: 'title', minWidth: 160 },
        {
          title: '论坛时间',
          key: 'schedule_time',
          align: 'center',
          width: 200,
          render: (h, params) => {
            const text =
              typeof params.row.schedule_time === 'object'
                ? params.row.schedule_time.map((items, index) => {
                    return (
                      <p>
                        {items.date + ' ' + items.time}
                        {index === params.row.schedule_time.length - 1
                          ? ''
                          : ','}
                      </p>
                    )
                  })
                : ''
            return h('div', {}, text)
          }
        },
        {
          title: '最后发布时间',
          key: 'publish_time',
          align: 'center',
          width: 200
        }
      ]
      const params = {
        content_type: this.content_type,
        tab_type: 1,
        search_title: this.queryData.keyWord,
        p: this.queryData.p,
        page_size: this.queryData.page_size,
        lang_tag: 'zh'
      }
      if (this.content_type === 5 || this.content_type === 4) {
        params.schedule_type = this.search_type
      }
      GetListData(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          if (this.content_type === 10) {
            this.tableColumns[1].title = '赛事标题'
            this.tableColumns.splice(2, 1)
          }
          if (this.content_type === 19) {
            this.tableColumns[1].title = '体验标题'
            this.tableColumns.splice(2, 1)
          }
          if (this.content_type === 22) {
            const item = {
              title: '封面图',
              key: 'head_img',
              width: 100,
              align: 'center',
              render: (h, params) => {
                return h('img', {
                  attrs: {
                    src: params.row.head_img
                  },
                  style: {
                    maxWidth: '60px',
                    maxHeight: '80px'
                  },
                  on: {}
                })
              }
            }
            this.tableColumns.splice(1, 0, item)
            this.tableColumns[2].title = '资讯标题'
            this.tableColumns[3].title = '资讯简介'
            this.tableColumns[3].key = 'news_content'
          }
          this.listData = res.data.list
          this.pagination = res.data.pagination
        }
      })
    }
  }
}
</script>

<style lang="less">
.listdiaog-search-box {
  box-sizing: border-box;
  padding: 10px 5px;
  display: flex;
  justify-content: space-between;

  input {
    width: 300px;
  }
  .btn-box {
    flex: 1;
    display: flex;
    align-items: center;
    .btn {
      margin-right: 10px;
    }
  }
}
.listdiaog-table {
  clear: both;
  margin-top: 20px;

  &-page {
    height: 50px;
    margin: 10px 0;
    line-height: 50px;
  }
}
</style>
