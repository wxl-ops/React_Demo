## 说明

### 提示

```
组件获取 cos 配置的域名为 config.js => AXIOS_DEFAULT_CONFIG.baseURL

使用中根据实际情况进行调整
```

### 使用方式

```js
yarn add cos-js-sdk-v5

import CosVideoUpload from 'Components/commonVideoUpload';

components: {
  CosVideoUpload;
}

<CosVideoUpload v-model='form.video' />;
```

### 配置参数

```json
{
  // 视频地址，支持双向绑定
  "value": {
    "type": String
  },
  // cos配置获取地址
  "cosConfigUrl": {
    "type": String,
    "default": "/common/image"
  },
  // 可上传视频文件类型 传 * 代表不限制文件类型，默认mp4
  "videoType": {
    "type": String,
    "default": "video/mp4"
  },
  // 最大可上传的文件大小 默认为0-不限制大小
  "maxSize": {
    "type": Number,
    "default": 0
  }
}
```
