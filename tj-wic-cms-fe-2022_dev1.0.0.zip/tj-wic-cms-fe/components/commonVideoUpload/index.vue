<template>
  <div class="video-upload">
    <el-upload
      ref="uploader"
      action="string"
      :accept="videoType"
      :auto-upload="false"
      :show-file-list="false"
      :on-change="handleCrop"
    >
      <el-button
        type="primary"
        plain
        :loading="uploadLoading"
        v-if="uploadLoading"
      >
        {{ uploadProgress }}%
      </el-button>
      <Button type="primary" :loading="uploadLoading" v-else>
        {{ value ? '重新上传' : '点击上传' }}
      </Button>
    </el-upload>
    <div class="video" v-if="value">
      <video :src="value" controls="controls" width="146px" height="146px" />
      <div class="delete-video" @click="clickRemove()">
        <i class="el-icon-delete" />
      </div>
    </div>
  </div>
</template>

<script>
// import axios from 'axios'
// import { AXIOS_DEFAULT_CONFIG } from 'Config/index'
import CosCloud from 'cos-js-sdk-v5'
// import Setting from '@/wau.config'
import MD5 from '@/libs/md5'
import { getCosConfigData } from '@/api/common'

export default {
  name: 'VideoUpload',
  props: {
    // 视频地址，支持双向绑定
    value: {
      type: String
    },
    // cos配置获取地址
    cosConfigUrl: {
      type: String,
      default: 'cms/api/get-ticket'
    },
    // 可上传视频文件类型 传 * 代表不限制文件类型，默认mp4
    videoType: {
      type: String,
      default: 'video/mp4'
    },
    // 最大可上传的文件大小 默认为0-不限制大小  单位MB
    maxSize: {
      type: Number,
      default: 500
    }
  },
  model: {
    prop: 'value', // 绑定的值，通过父组件传递
    event: 'update' // 自定义事件名
  },
  data() {
    return {
      cos: null, // cos对象
      cosData: {}, // cos配置
      uploadLoading: false, // 是否正在上传
      initCosSuccess: false, // cos是否初始化完毕
      uploadProgress: 0 // 上传进度
    }
  },
  methods: {
    // 视频选择
    handleCrop(file) {
      const type = file.raw.type
      console.log('上传文件格式 -> ', type)
      // 校验文件格式
      if (this.videoType !== '*' && !this.videoType.includes(type)) {
        this.$message.error(`请上传${this.videoType}格式的文件`)
        return false
      }
      // 校验文件大小
      // if (this.maxSize !== 0) {
      //   const isLtMax = file.size / 1024 / 1024 <= this.maxSize
      //   if (!isLtMax) {
      //     this.$message.error(`上传视频大小不能超过${this.maxSize}MB哦!`)
      //     return false
      //   }
      // }
      this.uploadLoading = true
      if (this.initCosSuccess) {
        this.uploadFile(file)
      } else {
        this.getCosConfig(file)
      }
    },
    // 获取cos配置
    getCosConfig(file) {
      const _this = this
      const time = new Date().valueOf()
      // axios.defaults.baseURL = Setting.material[1]
      // const action = `${this.cosConfigUrl}?time=${time}&sign=${MD5.hex_md5(
      //   `${time}cos_sign`
      // )}`
      // const nowLoginInfo = localStorage.jwtObj
      //   ? JSON.parse(localStorage.jwtObj)
      //   : ''
      // const { token_type, access_token } = nowLoginInfo
      // const Authorization = token_type + access_token
      // const _options = {
      //   Authorization,
      //   groupid: sessionStorage.getItem('group') || ''
      // }
      // axios.defaults.headers.common = _options
      getCosConfigData({
        time,
        sign: MD5.hex_md5(`${time}cos_sign`)
      })
        .then((res) => {
          if (res.ret === 0) {
            const cosInfo = res.data
            _this.initCos(cosInfo, file)
          } else {
            _this.uploadLoading = false
            this.$message.error(res.message || '获取cos配置失败!')
          }
        })
        .catch((err) => {
          _this.uploadLoading = false
          console.log('getCosConfig -> err', err)
        })
    },
    // 初始化cos
    initCos(cosInfo, file) {
      const _this = this
      this.cosData = cosInfo
      this.cos = new CosCloud({
        getAuthorization(options, callback) {
          // eslint-disable-next-line standard/no-callback-literal
          callback({
            TmpSecretId: _this.cosData.credentials.tmpSecretId,
            TmpSecretKey: _this.cosData.credentials.tmpSecretKey,
            XCosSecurityToken: _this.cosData.credentials.sessionToken,
            ExpiredTime: _this.cosData.expiredTime
          })
        }
      })
      this.$nextTick(() => {
        this.initCosSuccess = true
        this.uploadFile(file)
      })
    },
    // 上传文件
    uploadFile(file) {
      const _this = this
      const name = `/${this.cosData.folder}/${new Date().valueOf()}${file.name}`
      console.log('上传文件名称 -> ', name)
      console.log('uploadFile -> this.cosData', this.cosData)
      this.cos.sliceUploadFile(
        {
          Bucket: _this.cosData.bucket,
          Region: _this.cosData.region,
          Key: `${name}`,
          Dir: _this.cosData.folder,
          Body: file.raw,
          onHashProgress(progressData) {
            console.log('校验中', JSON.stringify(progressData))
          },
          onProgress(progressData) {
            console.log('上传中', progressData)
            _this.uploadProgress = parseInt(progressData.percent * 100)
          }
        },
        function(err, data) {
          if (err) {
            console.log('上传失败 -> err', err)
            _this.uploadProgress = 0
            _this.uploadLoading = false
            _this.initCosSuccess = false
            _this.$message.error('cos上传失败!')
            return
          }
          console.log('文件上传成功!')
          console.log('uploadFile -> data', data)
          const videoLocation = _this.cosData.image_domain + name
          _this.uploadProgress = 0
          _this.uploadLoading = false
          _this.$emit('update', videoLocation)
        }
      )
    },
    clickRemove() {
      this.$emit('update', '')
    }
  }
}
</script>

<style lang="less" scoped>
.video-upload {
  /deep/.el-button {
    padding: 12px 21px !important;
  }
}

.video {
  position: relative;
  width: 246px;
  height: 146px;
  margin-bottom: 22px;

  .delete-video {
    position: absolute;
    top: 0;
    right: 0;
    z-index: 99;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    color: #f56c6c;
    cursor: pointer;
    background-color: #fff;
    border-radius: 5px;
  }
}
</style>
