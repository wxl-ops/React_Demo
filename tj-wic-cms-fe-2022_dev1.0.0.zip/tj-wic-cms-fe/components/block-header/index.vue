<template>
  <div class="gl-block-container">
    <!--<div class="banner-list" v-for="(item, index) in list" :key="index">-->
    <div class="banner-list">
      <div class="banner-list-title">
        <div class="title-txt">{{ title }}{{ getIndex + 1 }}</div>
        <div class="btn-container">
          <div
            v-if="isMove & (index !== 0)"
            class="move-up-btn"
            :class="{
              noClick: !isChild
                ? index === 0 || disabled
                : childIndex === 0 || disabled
            }"
            @click="handleMoveUp(index, childIndex)"
          >
            上移
          </div>
          <div
            v-if="isMove & (index !== length - 1)"
            class="move-down-btn"
            :class="{
              noClick: !isChild
                ? index === length - 1 || disabled
                : childIndex === length - 1 || disabled
            }"
            @click="handleMoveDown(index, childIndex)"
          >
            下移
          </div>

          <div
            v-if="isAdd"
            class="move-add-btn"
            :class="{
              noClick: !isChild
                ? index === length - 1 || disabled
                : childIndex === length - 1 || disabled
            }"
            @click="handleAdd(index, childIndex)"
          >
            向下添加
          </div>
          <!-- <div
            v-if="isSetTop"
            class="del-btn"
            :class="{
              noClick: !isChild
                ? index === 0 || disabled
                : childIndex === 0 || disabled
            }"
            @click="handleSetTop(index, childIndex)"
          >
            置顶
          </div> -->
          <!-- <div
            v-if="isFold"
            class="del-btn"
            @click="handleFold(index, childIndex)"
          >
            收起/展开
          </div> -->

          <div
            v-if="!notDel"
            class="del-btn"
            :class="{ noClick: disabled }"
            @click="handleDel(index, childIndex)"
          >
            删除
          </div>
        </div>
      </div>
      <div v-if="onOff" class="banner-list-content">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'GlobalBlockHeader',
  props: {
    rid: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: '内容'
    },
    index: {
      type: Number,
      default: 0
    },
    childIndex: {
      type: Number,
      default: 0
    },
    length: {
      type: Number,
      default: 0
    },
    isMove: {
      type: [Boolean, String]
    },
    isAdd: {
      type: [Boolean, String]
    },
    isSetTop: {
      type: [Boolean, String]
    },
    isFold: {
      type: [Boolean, String]
    },
    disabled: {
      type: [Boolean, String]
    },
    isChild: {
      type: [Boolean, String]
    },
    notDel: {
      type: [Boolean, String]
    }
  },
  data() {
    return {
      onOff: true
    }
  },
  computed: {
    getIndex() {
      return this.isChild ? this.childIndex : this.index
    }
  },
  methods: {
    toggleFold() {
      this.onOff = !this.onOff
    },
    handleMoveUp(index, childIndex) {
      if (!this.isChild) {
        if (index === 0 || this.disabled) return false
      } else if (childIndex === 0 || this.disabled) return false
      if (this.rid) {
        this.$bus.$emit('moveUp', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('moveUp', index)
      }
    },
    handleMoveDown(index, childIndex) {
      if (!this.isChild) {
        if (index === this.length - 1 || this.disabled) return false
      } else if (childIndex === this.length - 1 || this.disabled) return false
      if (this.rid) {
        this.$bus.$emit('moveDown', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('moveDown', index)
      }
    },
    handleAdd(index, childIndex) {
      if (!this.isChild) {
        if (index === this.length - 1 || this.disabled) return false
      } else if (childIndex === this.length - 1 || this.disabled) return false
      if (this.rid) {
        this.$bus.$emit('moveAdd', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('moveAdd', index)
      }
    },
    handleSetTop(index, childIndex) {
      if (!this.isChild) {
        if (index === 0 || this.disabled) return false
      } else if (childIndex === 0 || this.disabled) return false
      if (this.rid) {
        this.$bus.$emit('setTop', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('setTop', index)
      }
    },
    handleDel(index, childIndex) {
      // if (this.disabled || this.length === 1) return false
      if (this.disabled) return false
      if (this.rid) {
        this.$bus.$emit('del', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('del', index)
      }
    },
    handleFold(index, childIndex) {
      if (this.rid) {
        this.$bus.$emit('fold', { index, childIndex, rid: this.rid })
      } else {
        this.$bus.$emit('fold', index)
      }
    }
  }
}
</script>

<style scoped lang="less">
.gl-block-container {
  .banner-list {
    width: 100%;
    /*max-width: 900px;*/
    margin-bottom: 21px;
    border-radius: 2px;
    border: 1px solid rgb(220, 222, 226);
    .banner-list-title {
      height: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgb(248, 248, 249);
      .title-txt {
        margin-left: 21px;
        font-size: 14px;
        font-family: PingFangSC-Medium;
        color: #464c5b;
      }
      .btn-container {
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }
      .del-btn,
      .move-up-btn,
      .move-down-btn,
      .move-add-btn {
        height: 40px;
        line-height: 40px;
        margin-right: 20px;
        font-size: 12px;
        font-family: PingFangSC-Regular;
        color: #0252db;
        &:hover {
          cursor: pointer;
        }
        &.noClick {
          color: #9ea7b4;
          &:hover {
            cursor: no-drop;
          }
        }
      }
    }
    .banner-list-content {
      padding: 20px 20px 0 0;
      .advise-size {
        position: absolute;
        top: 0;
        left: 115px;
        font-size: 14px;
        font-family: PingFangSC-Regular;
        color: #9ea7b4;
      }
      .notice-txt {
        margin-left: 10px;
      }
      .color-block-wrapper {
        display: flex;
        justify-content: flex-start;
        .color-block {
          width: 50px;
          height: 50px;
          margin-right: 10px;
          border-radius: 4px;
        }
        .input-color-wrapper {
          margin-left: 20px;
          span {
            margin-right: 10px;
          }
        }
      }
    }
  }
}
</style>
