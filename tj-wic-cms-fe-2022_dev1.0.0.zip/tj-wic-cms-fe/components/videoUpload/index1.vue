<template>
  <div class="custom-vue-cropper">
    <div class="l-tabbar-upload-box">
      <div class="hint">
        <div class="upload">
          <Button type="primary" @click="selectFile">视频上传</Button>
        </div>
      </div>
      <div
        v-if="value"
        class="l-tabbar-upload-box-img"
        ondragstart="return false"
        oncontextmenu="return false"
        onselectstart="return false"
      >
        <video
          id="video"
          :src="value"
          width="328px"
          height="183px"
          controls="controls"
          controlslist="nodownload"
          :disablePictureInPicture="true"
        ></video>
        <Icon type="md-trash" size="18" @click="deleteImg" />
      </div>
    </div>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import showIframe from '@/components/iframe'
export default {
  name: 'CustomVueCropper',
  components: { showIframe },
  props: {
    value: {
      type: String,
      default: ''
    },
    imageArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    id: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      video_url: '',
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: 'video'
      }
    }
  },

  mounted() {
    // const video = document.getElementById('video')
    // console.log(video, '++++++++++')
    // video.disablePictureInPicture = true
    // console.log(video.disablePictureInPicture)
  },
  beforeDestroy() {},
  methods: {
    // 选择文件
    selectFile() {
      this.showIframeObj = {
        limit: 1,
        show: true,
        valObj: this.id,
        type: 'video'
      }
    },
    // 获取选择后的文件列表
    getSelectFile(type, list) {
      console.log(list, '获取到的视频地址+++++++++++++++')
      this.setParsntSrc(list)
      this.showIframeObj.show = false
    },
    // 删除视频
    deleteImg() {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该视频吗?`,
        closable: true,
        onOk: () => {
          that.setParsntSrc('')
        }
      })
    },
    setParsntSrc(picSrc) {
      this.video_url = picSrc
      this.$emit('onUploadVideo', this.video_url, this.id)
      // if (this.index !== -1) {
      //   const item = {
      //     video_url: this.video_url,
      //     index: this.index
      //   }
      //   this.$emit('onUploadImage', item, this.id)
      // } else {
      // }
    }
  }
}
</script>

<style lang="less" scoped>
.custom-vue-cropper {
  display: inline-block;
}
.cropper {
  width: auto;
}
.l-tabbar-upload-box {
  .hint {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    .size {
      margin-left: 10px;
    }
    .upload {
      position: relative;
    }
  }
  &-img {
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
}
</style>
<style>
video::-internal-media-controls-download-button {
  display: none;
}
video::-webkit-media-controls-enclosure {
  overflow: hidden;
}
video::-webkit-media-controls-panel {
  width: calc(100% + 30px);
}
</style>
