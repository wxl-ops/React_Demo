<template>
  <div class="custom-vue-cropper">
    <div class="l-tabbar-upload-box">
      <div class="hint">
        <div class="upload">
          <Button type="primary" @click="isChooseShow = true">视频上传</Button>
          <span style="margin-left:10px;"
            >视频格式支持MP4，大小限制是500MB。超过500M的视频请选择本地上传</span
          >
          <span style="color:red;font-weight:600;"
            >，视频名称仅支持中文、英文、数字，其他字符可能会有浏览器兼容问题！</span
          >
        </div>
      </div>
      <div
        v-if="value"
        class="l-tabbar-upload-box-img"
        ondragstart="return false"
        oncontextmenu="return false"
        onselectstart="return false"
      >
        <video
          id="video"
          :src="value"
          width="328px"
          height="183px"
          controls="controls"
          controlslist="nodownload"
          :disablePictureInPicture="true"
        ></video>
        <Icon type="md-trash" size="18" @click="deleteImg" />
      </div>
    </div>
    <Modal v-model="isChooseShow" title="请选择">
      <div
        class="btns"
        style="box-sizing:border-box;padding:0 80px;display:flex;justify-content:space-between;"
      >
        <Button
          type="primary"
          @click=";(isChooseShow = false), selectFile('video', id)"
          >素材中台</Button
        >
        <Button
          type="primary"
          @click=";(isChooseShow = false), (isLocalDialogShow = true)"
          >本地上传</Button
        >
      </div>
      <div slot="footer"></div>
    </Modal>
    <Modal
      v-model="isLocalDialogShow"
      title="本地上传"
      :width="650"
      :closable="false"
    >
      <Form
        ref="formItemDialog"
        :model="formItemDialog"
        :rules="ruleValidateDialog"
        :label-width="100"
        label-colon
      >
        <FormItem label="视频" prop="play_url">
          <CosVideoUpload
            v-model="formItemDialog.play_url"
            @update="onVideoUpdate"
          />
        </FormItem>
        <FormItem label="视频封面图" prop="title_url">
          <div style="display:flex;">
            <Button @click="selectFile('image', id)" type="primary"
              >点击上传</Button
            >
            <span
              style="display:inline-block;font-size:12px;color:#999;margin-left:20px;"
              >图片格式支持jpg、jpeg、png、gif
              ，大小限制是10MB。（图片推荐大小不超过2M，否则可能影响程序展示）</span
            >
          </div>
          <div style="display:flex;align-items:flex-end;">
            <img
              v-if="formItemDialog.title_url"
              :src="formItemDialog.title_url"
              alt=""
              style="display:block;height:200px;margin-right:10px;"
            />
            <Icon
              v-if="formItemDialog.title_url"
              type="md-trash"
              size="18"
              @click="formItemDialog.title_url = ''"
            />
          </div>
        </FormItem>
        <FormItem>
          <Button
            @click=";(formItemDialog = {}), (isLocalDialogShow = false)"
            style="margin-right:20px;"
            >取消</Button
          >
          <Button @click="onLocalUploadSubmit" type="primary">确定</Button>
        </FormItem>
      </Form>
      <div slot="footer"></div>
    </Modal>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import showIframe from '@/components/iframe'
import CosVideoUpload from '@/components/commonVideoUpload'
export default {
  name: 'CustomVueCropper',
  components: { showIframe, CosVideoUpload },
  props: {
    value: {
      type: String,
      default: ''
    },
    imageArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    id: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      video_url: '',
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: 'video'
      },
      isChooseShow: false,
      isLocalDialogShow: false,
      formItemDialog: {
        play_url: '',
        title_url: ''
      },
      ruleValidateDialog: {
        play_url: [
          {
            required: true,
            message: '请选择视频',
            trigger: 'blur'
          }
        ],
        title_url: [
          {
            required: true,
            message: '请选择视频封面图',
            trigger: 'blur'
          }
        ]
      }
    }
  },

  mounted() {
    // const video = document.getElementById('video')
    // console.log(video, '++++++++++')
    // video.disablePictureInPicture = true
    // console.log(video.disablePictureInPicture)
  },
  beforeDestroy() {},
  methods: {
    // 视频中间上传更新
    onVideoUpdate(val) {
      console.log(val)
      this.formItemDialog.play_url = val
    },
    // 本地上传确定
    onLocalUploadSubmit() {
      console.log('本地上传点击确定')
      this.$refs.formItemDialog.validate((valid) => {
        if (valid) {
          // 提交
          this.isLocalDialogShow = false
          this.$emit('onUploadVideo', [this.formItemDialog], this.id)
        } else {
          this.$Message.error('请完善必填信息!')
        }
      })
    },
    // 选择文件
    selectFile(type, valObj) {
      this.showIframeObj = {
        limit: 1,
        show: true,
        valObj,
        type
      }
    },
    // 获取选择后的文件列表
    getSelectFile(type, list) {
      switch (type) {
        case 'image':
          console.log('本地图片封面图')
          console.log(list[0].img_url)
          this.formItemDialog.title_url = list[0].img_url
          break
        case 'video':
          console.log(list, '获取到的视频地址+++++++++++++++')
          this.setParsntSrc(list)
          break
        default:
          console.log('没有匹配的值')
          break
      }
      this.showIframeObj.show = false
    },
    // 删除视频
    deleteImg() {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该视频吗?`,
        closable: true,
        onOk: () => {
          that.setParsntSrc('')
        }
      })
    },
    setParsntSrc(picSrc) {
      this.video_url = picSrc
      this.$emit('onUploadVideo', this.video_url, this.id)
      // if (this.index !== -1) {
      //   const item = {
      //     video_url: this.video_url,
      //     index: this.index
      //   }
      //   this.$emit('onUploadImage', item, this.id)
      // } else {
      // }
    }
  }
}
</script>

<style lang="less" scoped>
.custom-vue-cropper {
  display: inline-block;
}
.cropper {
  width: auto;
}
.l-tabbar-upload-box {
  .hint {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    .size {
      margin-left: 10px;
    }
    .upload {
      position: relative;
    }
  }
  &-img {
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
}
</style>
<style>
video::-internal-media-controls-download-button {
  display: none;
}
video::-webkit-media-controls-enclosure {
  overflow: hidden;
}
video::-webkit-media-controls-panel {
  width: calc(100% + 30px);
}
</style>
