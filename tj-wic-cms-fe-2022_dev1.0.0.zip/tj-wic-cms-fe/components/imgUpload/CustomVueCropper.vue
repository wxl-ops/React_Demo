<template>
  <div class="custom-vue-cropper">
    <div class="l-tabbar-upload-box">
      <div class="hint">
        <div class="upload">
          <Button type="primary" @click="selectFile">图片上传</Button>
        </div>
        <span v-if="fixed" class="size"
          >建议尺寸{{ width }}px*{{ height }}px(或同等比例)</span
        >
        <span v-if="fixed" style="color:red;font-weight:600;"
          >，图片名称仅支持中文、英文、数字，其他字符可能会有浏览器兼容问题！</span
        >
        <span v-else class="size">建议尺寸{{ width }}px*{{ height }}px</span>
      </div>
      <div v-if="value" class="l-tabbar-upload-box-img">
        <img :src="value" />
        <Icon type="md-trash" size="18" @click="deleteImg" />
      </div>
    </div>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import showIframe from '@/components/iframe'
export default {
  name: 'CustomVueCropper',
  components: { showIframe },
  props: {
    value: {
      type: String,
      default: ''
    },
    moreImage: {
      type: Boolean,
      default: false
    },
    imageArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    imageNumber: {
      type: Number,
      default: 0
    },
    isOperationLocation: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: -1
    },
    id: {
      type: String,
      default: ''
    },
    fixedBox: {
      type: Boolean,
      default: false
    },
    fixed: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number,
      default: 400
    },
    height: {
      type: Number,
      default: 300
    },
    fixedNumber: {
      type: Array,
      default: () => {
        return [1, 1]
      }
    }
  },
  data() {
    return {
      image_url: '',
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: '',
        width: '',
        height: ''
      }
    }
  },
  watch: {
    value: {
      handler(newVal) {
        if (newVal) {
          this.image_url = newVal
        }
      },
      deep: true,
      immediate: true
    }
  },

  beforeDestroy() {},
  methods: {
    // 选择文件
    selectFile() {
      this.showIframeObj = {
        limit: 1,
        show: true,
        valObj: this.id,
        type: 'cover',
        width: this.width,
        height: this.height
      }
      console.log(this.showIframeObj, '选择文件后的数据++++++++++++++++++')
    },
    // 获取选择后的文件列表
    getSelectFile(type, list) {
      this.setParsntSrc(list[0].img_url)
      this.showIframeObj.show = false
    },
    // 删除图片
    deleteImg() {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该图片吗?`,
        closable: true,
        onOk: () => {
          that.setParsntSrc('')
        }
      })
    },
    setParsntSrc(picSrc) {
      this.image_url = picSrc
      if (this.index !== -1) {
        const item = {
          image_url: this.image_url,
          index: this.index
        }
        this.$emit('onUploadImage', item, this.id)
      } else {
        this.$emit('onUploadImage', this.image_url, this.id)
      }
    }
  }
}
</script>

<style lang="less" scoped>
.custom-vue-cropper {
  display: inline-block;
}
.cropper {
  width: auto;
}
.l-tabbar-upload-box {
  .hint {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    .size {
      margin-left: 10px;
    }
    .upload {
      position: relative;
    }
  }
  &-img {
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
}
</style>
