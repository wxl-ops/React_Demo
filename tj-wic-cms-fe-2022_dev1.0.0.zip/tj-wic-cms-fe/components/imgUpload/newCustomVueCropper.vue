<template>
  <div class="custom-vue-cropper">
    <div class="l-tabbar-upload-box">
      <div class="hint">
        <div class="upload">
          <Button type="primary" @click="selectFile">图片上传</Button>
        </div>
        <span v-if="fixed" class="size"
          >建议尺寸{{ width }}px*{{ height }}px(或同等比例)</span
        >
        <span v-else class="size">建议尺寸{{ width }}px*{{ height }}px</span>
      </div>
      <div class="l-tabbar-upload-box-img">
        <div v-for="(item, idx) in value" :key="idx" class="newImage">
          <img :src="item" />
          <Icon type="md-trash" size="18" @click="deleteImg(idx)" />
        </div>
      </div>
    </div>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>

<script>
import showIframe from '@/components/iframe'
export default {
  name: 'CustomVueCropper',
  components: { showIframe },
  props: {
    value: {
      type: Array,
      default: () => {
        return []
      }
    },
    moreImage: {
      type: Boolean,
      default: false
    },
    imageArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    imageNumber: {
      type: Number,
      default: 0
    },
    isOperationLocation: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: -1
    },
    id: {
      type: String,
      default: ''
    },
    fixedBox: {
      type: Boolean,
      default: false
    },
    fixed: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number,
      default: 400
    },
    height: {
      type: Number,
      default: 300
    },
    fixedNumber: {
      type: Array,
      default: () => {
        return [1, 1]
      }
    }
  },
  data() {
    return {
      image_url: '',
      subscript: '',
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: '',
        width: '',
        height: ''
      }
    }
  },
  watch: {
    value: {
      handler(newVal) {
        if (newVal) {
          this.image_url = newVal
        }
      },
      deep: true,
      immediate: true
    }
  },

  beforeDestroy() {},
  methods: {
    // 选择文件
    selectFile() {
      this.showIframeObj = {
        limit: 1,
        show: true,
        valObj: this.id,
        type: 'cover',
        width: this.width,
        height: this.height
      }
      console.log(this.showIframeObj, '选择文件后的数据++++++++++++++++++')
    },
    // 获取选择后的文件列表
    getSelectFile(type, list) {
      this.setParsntSrc(list[0].img_url)
      this.showIframeObj.show = false
    },
    // 删除图片
    deleteImg(idx) {
      const that = this
      that.subscript = idx
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该图片吗?`,
        closable: true,
        onOk: () => {
          console.log(that.subscript)
          that.setParsntSrc(that.subscript)
        }
      })
    },
    setParsntSrc(picSrc) {
      console.log(picSrc)
      console.log(typeof picSrc, '判断是删除还是赋值')
      if (typeof picSrc === 'number') {
        this.value.splice(picSrc, 1)
      } else {
        // this.image_url = picSrc
        this.value.push(picSrc)
      }
      this.$emit('onUploadImage', this.value, this.id)
      // if (this.index !== -1) {
      //   const item = {
      //     image_url: this.image_url,
      //     index: this.index
      //   }
      //   this.$emit('onUploadImage', item, this.id)
      // } else {
      //   this.$emit('onUploadImage', this.value, this.id)
      // }
    }
  }
}
</script>

<style lang="less" scoped>
.l-tabbar-upload-box-img {
  display: flex;
  justify-content: start;
  flex-wrap: wrap;
  .newImage {
    margin-top: 10px;
    margin-right: 5px;
    // width: 32%;
    height: 100%;
  }
}
.custom-vue-cropper {
  display: inline-block;
}
.cropper {
  width: auto;
}
.l-tabbar-upload-box {
  .hint {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    .size {
      margin-left: 10px;
    }
    .upload {
      position: relative;
    }
  }
  &-img {
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
}
</style>
