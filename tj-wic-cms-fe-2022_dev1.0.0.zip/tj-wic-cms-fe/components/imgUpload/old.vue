<template>
  <div class="custom-vue-cropper">
    <div v-if="isOperationLocation" class="l-tabbar-upload-box">
      <div class="hint">
        <div class="upload">
          <Button type="primary">图片上传</Button>
          <input
            v-if="showInput"
            :id="id"
            type="file"
            name="file"
            class="el-upload__input"
            @change="uploadImg"
          />
        </div>
        <span v-if="fixed" class="size"
          >建议尺寸{{ width }}px*{{ height }}px(或同等比例)</span
        >
        <span v-else class="size">建议尺寸{{ width }}px*{{ height }}px</span>
      </div>
      <div v-if="value" class="l-tabbar-upload-box-img">
        <img :src="value" />
        <Icon type="md-trash" size="18" @click="deleteImg" />
      </div>
    </div>

    <div v-else class="l-upload-box">
      <div class="hint">
        <span class="txt">请选择要上传的图片</span>
        <span class="size">尺寸{{ width }}px*{{ height }}px</span>
        <span v-if="moreImage" class="size"
          >，图片最多上传{{ imageNumber }}个</span
        >
      </div>
      <!-- 上传多张图片 -->
      <div v-if="moreImage" class="l-pic l-image-list">
        <div v-for="(img, idx) in imageArr" :key="idx" class="upload-img">
          <img class="up-img" :src="img" />
          <div class="up-delete" @click="deleteImage(idx)">
            <Icon type="md-close" size="24" />
          </div>
        </div>
        <div v-if="imageArr.length < imageNumber" class="up-block">
          <Icon type="ios-add" size="25" />
          <input
            v-if="showInput"
            :id="id"
            class="up-input"
            type="file"
            @change="uploadImg"
          />
        </div>
      </div>
      <!-- 上传一张图片 -->
      <div v-else class="l-pic">
        <div v-if="image_url" class="upload-img">
          <img class="up-img" :src="image_url" />
          <div class="up-change">
            <div>修改图片</div>
            <input
              v-if="showInput"
              :id="id"
              class="up-input"
              type="file"
              @change="uploadImg"
            />
          </div>
        </div>
        <div v-else class="up-block">
          <Icon type="ios-add" size="25" />
          <input
            v-if="showInput"
            :id="id"
            class="up-input"
            type="file"
            @change="uploadImg"
          />
        </div>
      </div>
    </div>

    <Modal
      v-model="dialogVisible"
      :width="modalWidth"
      :mask-closable="false"
      append-to-body
      center
      title="图片剪裁"
    >
      <div class="cropper-content">
        <div
          class="cropper"
          :style="`text-align:center;height:${modalHeight}px`"
        >
          <vueCropper
            v-if="vueCropperShow"
            ref="cropper"
            :img="option.img"
            :output-size="option.outputSize"
            :output-type="option.outputType"
            :info="option.info"
            :full="option.full"
            :can-move-box="option.canMoveBox"
            :original="option.original"
            :auto-crop="option.autoCrop"
            :fixed="option.fixed"
            :fixed-number="option.fixedNumber"
            :auto-crop-width="width"
            :auto-crop-height="height"
            :center-box="option.centerBox"
            :info-true="option.infoTrue"
            :fixed-box="option.fixedBox"
          ></vueCropper>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <Button @click="closeDialog">取 消</Button>
        <Button
          :loading="loading"
          :disabled="loading"
          type="primary"
          @click="finish"
          >确认</Button
        >
      </div>
    </Modal>
  </div>
</template>

<script>
import axios from 'axios'
import { VueCropper } from 'vue-cropper'
import initUploadObj from '@/libs/util/cos'
import util from '@/libs/util'
export default {
  name: 'CustomVueCropper',
  components: {
    VueCropper
  },
  props: {
    value: {
      type: String,
      default: ''
    },
    moreImage: {
      type: Boolean,
      default: false
    },
    imageArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    imageNumber: {
      type: Number,
      default: 0
    },
    isOperationLocation: {
      type: Boolean,
      default: false
    },
    index: {
      type: Number,
      default: -1
    },
    id: {
      type: String,
      default: ''
    },
    fixedBox: {
      type: Boolean,
      default: false
    },
    fixed: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number,
      default: 400
    },
    height: {
      type: Number,
      default: 300
    },
    fixedNumber: {
      type: Array,
      default: () => {
        return [1, 1]
      }
    }
  },
  data() {
    return {
      showInput: true,
      loading: false,
      dialogVisible: false,
      vueCropperShow: false,
      image_url: '',
      modalWidth: 600,
      modalHeight: 500,
      option: {
        img: '', // 裁剪图片的地址
        info: true, // 裁剪框的大小信息
        outputSize: 1, // 裁剪生成图片的质量
        outputType: 'jpeg', // 裁剪生成图片的格式
        canScale: true, // 图片是否允许滚轮缩放
        autoCrop: true, // 是否默认生成截图框
        autoCropWidth: this.width, // 默认生成截图框宽度
        autoCropHeight: this.height, // 默认生成截图框高度
        fixedBox: this.fixedBox, // 固定截图框大小 不允许改变
        fixed: this.fixed, // 是否开启截图框宽高固定比例
        fixedNumber: this.fixedNumber, // 截图框的宽高比例
        full: true, // 是否输出原图比例的截图
        canMoveBox: true, // 截图框能否拖动
        original: false, // 上传图片按照原始比例渲染
        centerBox: false, // 截图框是否被限制在图片里面
        infoTrue: true // true 为展示真实输出图片宽高 false 展示看到的截图框宽高
      }
    }
  },
  watch: {
    value: {
      handler(newVal) {
        if (newVal) {
          this.image_url = newVal
        }
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {
    this.resize()
    window.addEventListener('resize', this.resize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resize)
  },
  methods: {
    resize() {
      let wHeight = window.innerHeight - 300
      let wWidth = window.innerWidth * 0.75
      if (wHeight > 1000) {
        wHeight = 1000
      }
      if (wHeight < 200) {
        wHeight = 200
      }
      if (wWidth > 1200) {
        wWidth = 1200
      }
      if (wWidth < 600) {
        wWidth = 600
      }
      this.modalWidth = wWidth
      this.modalHeight = wHeight
    },

    // 上传图片
    uploadImg(event) {
      const that = this
      const id = that.id
      const file = document.querySelector(`input[id=${id}]`).files[0]
      if (file.size / 1024 >= 1024 * 5) {
        that.$Message.error('您选择的图片太大,请选择小于5M的图片')
        that.showInput = false
        setTimeout(() => {
          that.showInput = true
        }, 100)
      } else {
        that.fileName = file.name
        const fileRader = new FileReader()
        fileRader.onload = function() {
          that.option.img = fileRader.result
          that.dialogVisible = true
          that.vueCropperShow = true
          that.showInput = false
          setTimeout(() => {
            that.showInput = true
          }, 100)
        }
        fileRader.readAsDataURL(file)
      }
      /*
                initUploadObj(that, file.name, file, 'image', function (res) {
                    if (res.success) {
                        event.target.value = ''
                        // 先上传然后把上传成功的url赋值给需要裁切的img
                        that.option.img = res.pic
                        that.dialogVisible = true
                    } else {
                        that.$Message.error('图片上传失败')
                    }
                })
                */
    },
    // 删除图片
    deleteImg() {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该图片吗?`,
        closable: true,
        onOk: () => {
          that.setParsntSrc('')
        }
      })
    },
    closeDialog() {
      this.dialogVisible = false
      const that = this
      setTimeout(() => {
        that.vueCropperShow = false
      }, 500)
    },
    finish() {
      const that = this
      const formData = new FormData()
      that.$refs.cropper.getCropBlob((data) => {
        formData.append('file', data, that.fileName)
        that.loading = true
        initUploadObj(
          that,
          that.fileName,
          formData.get('file'),
          'blob',
          function(res) {
            if (res.success) {
              that.getSourceId(res.pic, data, true)
            } else {
              that.loading = false
              that.$Message.error('图片上传失败')
            }
          }
        )
      })
    },
    // 获取sourceId
    getSourceId(picSrc, data, isFirst) {
      const that = this
      axios
        .get(
          'https://' +
            util.cookies.get('env') +
            '.cantonfair.org.cn/content/oss/default/get_url?type=image'
        )
        .then((res) => {
          if (res.data.ret * 1 === 0) {
            const signStr = String(res.data.data.url).split(
              'edia/index/image?'
            )[1]
            that.saveContent(picSrc, data, isFirst, signStr)
          } else {
            that.$Message.error('图片保存失败,请重新保存.')
            that.loading = false
          }
        })
        .catch((res) => {
          that.$Message.error('图片保存失败,请重新保存.')
          that.loading = false
        })
    },
    saveContent(picSrc, data, isFirst, signStr) {
      const that = this
      let content = 'prod-content'
      if (util.cookies.get('env') === 'tcms') {
        content = 'content'
      }
      const sourceId = String(picSrc).split(`${content}/`)[1]
      // 上传到素材库
      const postData = {
        file_type: data.type,
        size: data.size,
        name: that.fileName,
        resource_path: '/1300585764/cantonfair-cdn/' + content + '/' + sourceId,
        img_url: picSrc,
        media_type: 'image',
        category_id: ''
      }
      axios
        .post(
          'https://' +
            util.cookies.get('env') +
            '.cantonfair.org.cn/content/media/admin-api/save' +
            (signStr ? `?${signStr}` : ''),
          postData
        )
        .then(function(resCdn) {
          if (resCdn.data.ret * 1 === 0) {
            that.setParsntSrc(resCdn.data.data.img_url)
            that.loading = false
          } else if (isFirst === true) {
            that.saveContent(picSrc, data, false, signStr)
          } else {
            that.$Message.error('图片保存失败,请重新保存.')
            that.loading = false
          }
        })
        .catch(() => {
          if (isFirst === true) {
            that.saveContent(picSrc, data, false, Location)
          } else {
            that.$Message.error('图片保存失败,请重新保存.')
            that.loading = false
          }
        })
    },
    setParsntSrc(picSrc) {
      this.image_url = picSrc
      if (this.index !== -1) {
        const item = {
          image_url: this.image_url,
          index: this.index
        }
        this.$emit('onUploadImage', item, this.id)
      } else {
        this.$emit('onUploadImage', this.image_url, this.id)
      }
      this.dialogVisible = false
      const that = this
      setTimeout(() => {
        that.vueCropperShow = false
      }, 500)
    },
    deleteImage(idx) {
      this.$emit('onDeleteImage', idx)
    }
  }
}
</script>

<style lang="less" scoped>
.custom-vue-cropper {
  display: inline-block;
}
.cropper {
  width: auto;
}
.l-upload-box {
  .hint {
    .txt {
      margin-right: 10px;
    }
  }
  .l-pic {
    width: 100%;
    display: flex;
    .upload-img {
      position: relative;
      height: 100px;
      .up-img {
        width: 100px;
        height: 100px;
      }
      .up-change {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        color: #fff;
        background: rgba(0, 0, 0, 0.4);
        .up-input {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          outline: none;
          opacity: 0;
          z-index: 3;
        }
      }
    }
    .up-block {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100px;
      height: 100px;
      background-color: #fbfdff;
      border: 1px dashed #c0ccda;
      border-radius: 6px;
      cursor: pointer;
      .up-input {
        position: absolute;
        top: 0;
        left: 0;
        width: 100px;
        height: 100px;
        outline: none;
        opacity: 0;
        z-index: 3;
      }
    }
    .msg {
      color: rgb(45, 140, 240);
      margin-left: 10px;
    }
  }
  .l-image-list {
    display: flex;
    flex-wrap: wrap;
    .upload-img {
      margin: 0 20px 20px 0;
      .up-delete {
        position: absolute;
        top: 0;
        right: 0;
        width: 24px;
        height: 24px;
        line-height: 24px;
        text-align: center;
        color: #fff;
        background: rgba(0, 0, 0, 0.4);
      }
    }
  }
}

.l-tabbar-upload-box {
  .hint {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
    .size {
      margin-left: 10px;
    }
    .upload {
      position: relative;
      .el-upload__input {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        outline: none;
        opacity: 0;
        z-index: 3;
      }
    }
  }
  &-img {
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
}
</style>
