<template>
  <div class="content-list-page">
    <Tabs v-model="tabIndex" @on-click="tabsChange">
      <TabPane
        v-for="item in tabs"
        :key="item.value"
        :label="item.label"
      ></TabPane>
      <Button
        v-if="queryData.tab_type == 1"
        slot="extra"
        :disabled="selectListId == ''"
        @click="changeStatus(0, 2)"
        >批量下线</Button
      >
      <Button
        v-if="![1, 4, 5].includes(queryData.tab_type)"
        slot="extra"
        :disabled="selectListId == ''"
        @click="changeStatus(0, 1)"
        >批量上线</Button
      >
      <Button slot="extra" type="primary" @click="goAddPage()">新建</Button>
    </Tabs>
    <div v-if="![32, 33].includes(contentType)" class="search-container">
      <div class="sc-left">
        <Input
          v-model="queryData.search_title"
          :maxlength="100"
          class="inputList inputList2"
          :placeholder="searchTitlePlaceholderTxt"
          style="width: 300px;"
        />
        <Select
          v-if="[17, 18].includes(contentType)"
          v-model="queryData.search_type"
          style="width:300px"
          placeholder="请选择活动类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
        <Select
          v-if="[6, 7].includes(contentType)"
          v-model="queryData.guest_type"
          style="width:300px"
          placeholder="请选择嘉宾类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
        <Select
          v-if="[27, 28].includes(contentType)"
          v-model="queryData.search_type"
          style="width:300px"
          placeholder="请选择合作伙伴类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
        <Select
          v-if="[22, 23].includes(contentType)"
          v-model="queryData.search_type"
          style="width:300px"
          placeholder="请选择新闻资讯类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
        <!-- <Select
          v-if="[3].includes(contentType)"
          v-model="queryData.type"
          style="width:200px"
          placeholder="请选择上级类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select> -->
        <!-- <Select
          v-if="[4, 5].includes(contentType)"
          v-model="queryData.schedule_type"
          style="width:200px"
          placeholder=" 请选择日程类型"
        >
          <Option
            v-for="item in typeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select> -->
        <!-- <Select
          v-model="formItem.other_data.schedule_type"
          placeholder="请选择日程类型"
        >
          <Option
            v-for="itemSchedule in scheduleTypeData"
            :key="itemSchedule.value"
            :value="itemSchedule.value"
            >{{ `${itemSchedule.label}` }}</Option
          >
        </Select> -->
        <!-- delSearchList -->
        <Select
          v-if="queryData.tab_type === 5"
          v-model="queryData.draft_status"
          style="width:300px"
          placeholder=" 请选择删除来源"
        >
          <Option
            v-for="item in sourceList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </div>
      <div class="sc-right">
        <Button
          type="primary"
          style="margin-left: 10px;"
          @click="onPageSearch()"
          >查询</Button
        >
        <Button @click="clearSearch()">重置</Button>
      </div>
    </div>
    <div class="form-container">
      <Table
        ref="dataTable"
        border
        :loading="tableLoading"
        :columns="tableColumns"
        :data="listData"
        @on-selection-change="selectChange"
      ></Table>
      <div class="form-container-page">
        <div style="float: left;">
          <span>共 {{ pagination.total }} 条数据</span>
          <span v-if="false" style="margin-left:5px"
            >{{ pagination.total_page }}页</span
          >
        </div>
        <div style="float: right;">
          <Page
            show-sizer
            show-elevator
            :page-size-opts="pageSizeOpts"
            :total="pagination.total"
            :page-size="pagination.page_size"
            :current="pagination.current_page"
            @on-change="changePage"
            @on-page-size-change="PageSizeChange"
          ></Page>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Viewer from 'viewerjs'
import 'viewerjs/dist/viewer.css'
import { GetListData, setStatus, deleteContent } from '@/api/content'
import { getGuestTypeList } from '@/api/common'
import Setting from '@/wau.config'
// import nopicUrl from '@/static/images/nopic.jpg'
export default {
  name: 'ContentListPage',
  props: {
    contentType: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {
      // 表格数据加载
      tableLoading: true,
      // 是否显示表格数据
      showTable: false,
      // tabs状态
      tabIndex: 0, // 当前状态
      searchTitlePlaceholderTxt: '', // 关键字输入框placeholder
      tabs: [
        {
          label: '已上线',
          value: 1
        },
        {
          label: '已下线',
          value: 2
        },
        {
          label: '待上线',
          value: 3
        },
        {
          label: '草稿',
          value: 4
        },
        {
          label: '已删除',
          value: 5
        }
      ],
      // 查询相关
      queryData: {
        tab_type: 1,
        search_title: '',
        p: 1,
        page_size: 10,
        search_type: '',
        guest_type: '',
        partner_type: '',
        news_type: '',
        schedule_type: '',
        type: '',
        draft_status: 2
      },
      // 分页数据
      pagination: {
        current_page: 1,
        page_size: 10,
        total: 1,
        total_page: 1
      },
      pageSizeOpts: [5, 10, 20],
      // 选择列表
      selectListId: '',
      // 列表数据
      listData: [
        {
          name: '111',
          head_img: ''
        }
      ],
      tableColumns: [
        { type: 'selection', width: 60, align: 'center' },
        {
          title: '封面图',
          key: 'head_img',
          width: 100,
          align: 'center',
          render: (h, params) => {
            let imgSrc = params.row.head_img
            if (!imgSrc) {
              return h('span', {})
            }
            // 修改图片文件名由于特殊符号引起的无法访问
            const urlArr = String(imgSrc).split('/')
            const url2 = urlArr[urlArr.length - 1]
            const url1 = String(imgSrc).replace(url2, '')
            imgSrc = url1 + encodeURIComponent(url2)
            return h('img', {
              attrs: {
                src: imgSrc + '?imageMogr2/thumbnail/!60x80r'
              },
              style: { cursor: 'pointer', maxWidth: '60px', maxHeight: '80px' },
              on: {
                // error: (e) => {
                //   e.target.src = nopicUrl
                //   e.target.iserror = true
                // },
                click: (e) => {
                  if (e.target.iserror !== true) {
                    const img = new Image(1, 1)
                    img.src = imgSrc
                    const viewer = new Viewer(img, {
                      toolbar: false,
                      title: false,
                      navbar: false,
                      hidden: () => {
                        viewer.destroy()
                      }
                    })
                    viewer.show()
                  }
                }
              }
            })
          }
        },
        {
          title: '活动类型（中文)',
          key: 'title',
          minWidth: 160
        },
        { title: '活动类型（英文)', key: 'en_title', width: 160 },
        { title: '排序', key: 'weight', align: 'center', width: 80 },
        { title: '创建者', key: 'creator', align: 'center', width: 150 },
        {
          title: '创建时间',
          key: 'create_time',
          align: 'center',
          width: 150
        },
        { title: '修改者', key: 'updater', align: 'center', width: 150 },
        {
          title: '修改时间',
          key: 'update_time',
          align: 'center',
          width: 150
        },
        { title: '发布者', key: 'publisher', align: 'center', width: 150 }, // 当tab为草稿箱时不显示
        {
          title: '发布时间',
          key: 'publish_time',
          align: 'center',
          width: 150
        },
        {
          title: '操作',
          key: 'action',
          fixed: 'right',
          align: 'center',
          width: 150,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: params.row.is_vote === 1 && (this.contentType === 4 || this.contentType === 5)
                      ? 'inline-block'
                      : 'none'
                  },
                  on: {
                    click: () => {
                      this.goVotePage(params.row._id)
                    }
                  }
                },
                '查看投票'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: !(this.queryData.tab_type === 5)
                      ? 'inline-block'
                      : 'none'
                  },
                  on: {
                    click: () => {
                      this.goEditPage(params.row._id)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display:
                      this.queryData.tab_type === 1 ? 'inline-block' : 'none'
                  },
                  on: {
                    click: () => {
                      this.changeStatus(params.row._id, 2)
                    }
                  }
                },
                '下线'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display:
                      this.queryData.tab_type !== 1 &&
                      this.queryData.tab_type !== 4 &&
                      this.queryData.tab_type !== 5
                        ? 'inline-block'
                        : 'none'
                  },
                  on: {
                    click: () => {
                      this.changeStatus(params.row._id, 1)
                    }
                  }
                },
                '上线'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display: !(
                      this.tabs[this.queryData.tab_type - 1].label ===
                        '已删除' || this.queryData.tab_type === 1
                    )
                      ? 'inline-block'
                      : 'none'
                  },
                  on: {
                    click: () => {
                      this.deleteData(params.row._id)
                    }
                  }
                },
                '删除'
              ),
              h(
                'Button',
                {
                  props: { size: 'small', type: 'text' },
                  style: {
                    color: '#2d8cf0',
                    display:
                      this.queryData.tab_type === 5 ? 'inline-block' : 'none'
                  },
                  on: {
                    click: () => {
                      this.goEditPage(params.row._id)
                    }
                  }
                },
                '查看'
              )
            ])
          }
        }
      ],
      typeList: [],
      sourceList: [
        {
          label: '已下线',
          value: 2
        },
        {
          label: '待上线',
          value: 3
        },
        {
          label: '草稿箱',
          value: 4
        }
      ]
    }
  },
  watch: {},
  beforeDestroy() {},
  created() {
    this.resize()
    this.searchTitlePlaceholder()
    if (this.contentType === 17 || this.contentType === 18) {
      this.getTypeList()
    }
    if ([6, 7].includes(this.contentType)) {
      this.getGuestTypeList()
    }
    if (this.contentType === 22 || this.contentType === 23) {
      this.getNewsType()
    }
    if (this.contentType === 27 || this.contentType === 28) {
      this.getPartnerType()
    }
    // if ([3].includes(this.contentType)) {
    //   this.getScheduleTypeList()
    // }
    // if ([4, 5].includes(this.contentType)) {
    //   this.getScheduleTypeTwoList()
    // }
  },

  methods: {
    // 查询事件
    onPageSearch() {
      this.queryData.p = 1
      this.getListData()
    },
    // 获取嘉宾类型
    getGuestTypeList() {
      getGuestTypeList({ all: 1 }).then((res) => {
        if (res.ret === 0) {
          this.typeList = res.data
        } else {
          this.$Message.error(res.msg)
        }
      })
    },
    // getScheduleTypeList() {
    //   getScheduleType({ level: 0, all: 1 }).then((res) => {
    //     if (res.ret === 0) {
    //       this.typeList = res.data
    //     } else {
    //       this.$Message.error(res.msg)
    //     }
    //   })
    // },
    // 大会日程活动类型
    // getScheduleTypeTwoList() {
    //   getScheduleType({ level: 1 }).then((res) => {
    //     this.typeList = res.data
    //   })
    // },
    // 获取活动类型
    getTypeList() {
      const params = {
        content_type: 16,
        tab_type: 1,
        p: 1,
        page_size: 3000
      }
      // 获取列表数据
      GetListData(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          res.data.list.map((items, index) => {
            this.typeList.push({
              label: items.title + '-' + items.en_title,
              value: items.id
            })
          })
        }
      })
    },
    getPartnerType() {
      const params = {
        content_type: 26,
        tab_type: 1,
        p: 1,
        page_size: 3000
      }
      // 获取列表数据
      GetListData(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          res.data.list.map((items, index) => {
            this.typeList.push({
              label: items.title + '-' + items.en_title,
              value: items.id
            })
          })
        }
      })
    },
    getNewsType() {
      const params = {
        content_type: 21,
        tab_type: 1,
        p: 1,
        page_size: 3000
      }
      // 获取列表数据
      GetListData(params).then((res) => {
        this.tableLoading = false
        if (res.ret === 0) {
          res.data.list.map((items, index) => {
            this.typeList.push({
              label: items.title + '-' + items.en_title,
              value: items.id
            })
          })
        }
      })
    },
    // 设置输入关键字的文本框的placeholder
    searchTitlePlaceholder() {
      let title = ''
      switch (this.contentType) {
        case 16:
          title = '请输入活动类型（中文）'
          break
        case 3:
          title = '请输入日程类型（中文）'
          break
        default:
          title = '请输入关键字'
          break
      }
      this.searchTitlePlaceholderTxt = title
    },
    // 跳转新建页面
    goAddPage() {
      const currName = Setting.pageName[this.contentType - 1] + '-' + 'create'
      const goPath = {
        name: currName,
        query: {
          tab_type: this.queryData.tab_type,
          p: this.queryData.p,
          content_type: this.contentType
        }
      }
      this.$router.push(goPath)
    },
    // 跳转编辑页面
    goEditPage(id) {
      const currName = Setting.pageName[this.contentType - 1] + '-' + 'edit'
      const goPath = {
        name: currName,
        query: {
          tab_type: this.queryData.tab_type,
          p: this.queryData.p,
          content_type: this.contentType,
          id
        }
      }
      this.$router.push(goPath)
    },
    goVotePage(id) {
      const currName = Setting.pageName[this.contentType - 1] + '-' + 'vote'
      const goPath = {
        name: currName,
        query: {
          id
        }
      }
      this.$router.push(goPath)
    },
    // 上下线
    changeStatus(id, status) {
      let statusTitle = status === 2 ? '下线' : '上线'
      let statusContent = `是否确定${status === 2 ? '下线' : '上线'}对应的内容?`
      // id为0时状态为批量删除 取selectListId
      if (id === 0) {
        // 批量下线
        id = this.selectListId
        statusTitle = status === 2 ? '批量下线' : '批量上线'
      }
      // 类型下线给出提示
      if ([3, 16].includes(this.contentType) && status === 2) {
        statusContent =
          '操作下线将导致此类型及其所关联的数据在官网无法显示，请确认是否下线？'
      }
      this.$Modal.confirm({
        title: statusTitle,
        content: statusContent,
        closable: true,
        onOk: () => {
          this.tableLoading = true
          const params = {
            _id: id,
            publish_type: status,
            tab_type: this.queryData.tab_type
          }
          setStatus(params, 1)
            .then((res) => {
              if (res.ret === 0) {
                this.$Message.success(`设置${statusTitle}成功`)
                this.getListData()
              } else {
                this.tableLoading = false
                this.$Message.error(res.msg || '操作失败')
              }
            })
            .catch((err) => {
              console.log(err)
              console.log('catch')
              this.tableLoading = false
            })
        }
      })
    },
    // 删除数据
    deleteData(id) {
      // 删除之前弹窗确认
      this.$Modal.confirm({
        title: '删除数据',
        content: `确定要删除数据吗?`,
        closable: true,
        onOk: () => {
          this.tableLoading = true
          deleteContent(
            {
              _id: id,
              tab_type: this.queryData.tab_type
            },
            3
          )
            .then((res) => {
              if (res.ret === 0) {
                this.$Message.success(`删除成功`)
                this.getListData()
              } else {
                this.tableLoading = false
                this.$Message.error(res.msg || '操作失败')
              }
            })
            .catch(() => {
              this.tableLoading = false
            })
        }
      })
    },
    // 获取表格数据
    getListData() {
      this.tableLoading = true
      this.listData = []
      this.selectListId = ''
      const params = {
        content_type: this.contentType,
        tab_type: this.queryData.tab_type,
        search_title: this.queryData.search_title,
        search_type: this.queryData.search_type,
        guest_type: this.queryData.guest_type,
        news_type: this.queryData.news_type,
        partner_type: this.queryData.partner_type,
        schedule_type: this.queryData.schedule_type, // 大会日程列表搜索类型
        draft_status: this.queryData.draft_status,
        type: this.queryData.type,
        p: this.queryData.p,
        page_size: this.queryData.page_size
      }
      if (
        [1, 4, 6, 8, 10, 12, 17, 19, 22, 24, 27, 34, 32, 37].includes(
          this.contentType
        )
      ) {
        params.lang_tag = 'zh'
      }
      if (
        [2, 5, 7, 9, 11, 13, 18, 20, 23, 25, 28, 35, 33, 38].includes(
          this.contentType
        )
      ) {
        params.lang_tag = 'en'
      }
      // 获取列表数据
      GetListData(params)
        .then((res) => {
          this.tableLoading = false
          if (res.ret === 0) {
            if (this.queryData.p > 1 && res.data.list.length === 0) {
              this.queryData.p = this.queryData.p - 1
              this.getListData()
            } else {
              this.listData = res.data.list
              this.pagination = res.data.pagination
            }
          } else {
            console.log('ret为0')
          }
        })
        .catch(() => {
          console.log('catch')
          this.tableLoading = false
        })
    },
    // 切换状态
    tabsChange(tabIndex, _noLoadData, _p) {
      this.queryData.tab_type = parseInt(tabIndex) + 1
      this.queryData.p = 1
      // 在tab切换时给表格行标题赋不同的名称
      // ！！！important   --------
      // 当切换到删除时，选择删除来源
      if (tabIndex === 4) {
        const obj = {
          title: '数据来源',
          key: 'draft_status_text',
          width: 160
        }
        this.tableColumns.splice(1, 0, obj)
        if ([1, 2, 12, 13, 16].includes(this.contentType)) {
          if (this.tableColumns[2].title === '封面图') {
            this.tableColumns.splice(2, 1)
          }
        }
        // 注册协议
        if ([1, 2].includes(this.contentType)) {
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[2].title = '标题'
            this.tableColumns[2].key = 'title'
            this.tableColumns.splice(3, 1)
          }
        }
        // 峰会与论坛
        if (this.contentType === 3) {
          // 日程类型
          if (this.tableColumns[2].title === '封面图') {
            this.tableColumns.splice(2, 1)
            this.tableColumns[2].title = '论坛类型（中文）'
            this.tableColumns[2].key = 'title'
            this.tableColumns[2].minWidth = 180
            this.tableColumns[3].title = '论坛类型（英文）'
            this.tableColumns[3].key = 'en_title'
            this.tableColumns[3].width = 160
            this.tableColumns[4].title = '上级类型'
            this.tableColumns[4].key = 'type_name'
            const item = { title: '排序', key: 'weight', minWidth: 160 }
            this.tableColumns.splice(5, 0, item)
            // const oneitem = { title: '创建者', key: 'creator', minWidth: 160 }
            // this.tableColumns.splice(6, 1, oneitem)
            // const column4 = { ...this.tableColumns[5] }
            // this.tableColumns[4] = column4
          }
        }
        if (this.contentType === 4 || this.contentType === 5) {
          const list = this.tableColumns;
          let hasLike = false;
          list.forEach(item => {
            if (item.key === 'like_num') {
              hasLike = true;
            };
          });
          if (!hasLike) {
            // const data = { title: '点赞数', key: 'like_num', align: 'center', width: 80 };
            // this.tableColumns.splice(9, 0, data);
          };
          // 日程中文列表
          const item = { title: '论坛标题', key: 'title', minWidth: 160 }
          this.tableColumns.splice(2, 1, item)
          this.tableColumns[2].title = '论坛标题'
          this.tableColumns[2].key = 'title'
          this.tableColumns[2].minWidth = 160
          this.tableColumns[3].title = '论坛类型'
          this.tableColumns[3].key = 'schedule_type_name'
          this.tableColumns[3].width = 160
          this.tableColumns[4].title = '论坛时间'
          this.tableColumns[4].key = 'schedule_time'
          this.tableColumns[4].render = (h, params) => {
            const text =
              typeof params.row.schedule_time === 'object'
                ? params.row.schedule_time.map((items, index) => {
                    return (
                      <p>
                        {items.date + ' ' + items.time}
                        {index === params.row.schedule_time.length - 1
                          ? ''
                          : ','}
                      </p>
                    )
                  })
                : ''
            return h('div', {}, text)
          }
        }
        if ([6, 7].includes(this.contentType)) {
          this.tableColumns[3].title = '嘉宾姓名'
          this.tableColumns[3].key = 'title'
          this.tableColumns[3].minWidth = 120
          this.tableColumns[4].title = '嘉宾类型'
          this.tableColumns[4].key = 'guest_type_name'
          this.tableColumns[4].width = 120
        }
        if ([8, 9].includes(this.contentType)) {
          this.tableColumns[3].title = '嘉宾姓名'
          this.tableColumns[3].key = 'title'
          this.tableColumns[3].minWidth = 120
          if (this.tableColumns[4].title === '活动类型（英文)') {
            this.tableColumns.splice(4, 1)
          }
        }
        if ([10, 11].includes(this.contentType)) {
          this.tableColumns[3].title = '赛事标题'
          this.tableColumns[3].key = 'title'
          this.tableColumns[3].minWidth = 120
          if (this.tableColumns[4].title === '活动类型（英文)') {
            this.tableColumns.splice(4, 1)
          }
        }

        if ([12, 13].includes(this.contentType)) {
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[2].title = '文章标题'
            this.tableColumns[2].key = 'title'
            this.tableColumns.splice(3, 2)
          }
        }
        if (this.contentType === 17 || this.contentType === 18) {
          // this.tableColumns.splice(2, 1)
          this.tableColumns[3].title = '标题'
          this.tableColumns[3].key = 'title'
          this.tableColumns[3].minWidth = 120
          this.tableColumns[4].title = '活动类型'
          this.tableColumns[4].key = 'type_title'
          this.tableColumns[4].width = 120
        }
        if (this.contentType === 19 || this.contentType === 20 || this.contentType === 37 || this.contentType === 38) {
          if (this.tableColumns[3].title === '活动类型（中文)') {
            this.tableColumns[3].title = '标题'
            this.tableColumns[3].key = 'title'
            this.tableColumns[3].minWidth = 120
            this.tableColumns.splice(4, 1)
          }
        }
        if ([21, 22, 23].includes(this.contentType)) {
          if (this.tableColumns[2].title === '封面图') {
            this.tableColumns.splice(2, 1)
          }
        }
        if (this.contentType === 21) {
          if (this.tableColumns[2].title === '活动类型（中文)') {
            this.tableColumns[2].title = '新闻类型（中文)'
          }
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[3].title = '新闻类型（英文)'
          }
        }
        if (this.contentType === 22 || this.contentType === 23) {
          if (this.tableColumns[2].title === '活动类型（中文)') {
            this.tableColumns[2].title = '资讯标题'
          }
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[3].title = '资讯类型'
            this.tableColumns[3].key = 'type_title'
          }
          if (this.tableColumns[4].title !== '状态') {
            this.tableColumns.splice(4, 0, {
              title: '状态',
              key: 'weight',
              align: 'center',
              width: 80,
              render: (h, params) => {
                const text = params.row.other_data.is_top === '2' ? '/' : '置顶'
                return h('div', {}, text)
              }
            })
          }
          if (this.tableColumns[5].title === '排序') {
            this.tableColumns[5].title = '置顶排序'
            this.tableColumns[5].render = (h, params) => {
              const text =
                params.row.other_data.is_top === '2' ? '/' : params.row.weight
              return h('div', {}, text)
            }
          }
        }
        if (this.contentType === 24 || this.contentType === 25) {
          if (this.tableColumns[4].title === '活动类型（英文)') {
            this.tableColumns.splice(4, 1)
          }
          this.tableColumns[2].title = 'banner图'
          this.tableColumns[3].title = '标题'
          this.tableColumns[3].key = 'title'
        }
        if (this.contentType === 26) {
          if (this.tableColumns[2].title === '封面图') {
            this.tableColumns.splice(2, 1)
          }
          if (this.tableColumns[2].title === '活动类型（中文)') {
            this.tableColumns[2].title = '伙伴类型（中文)'
          }
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[3].title = '伙伴类型（英文)'
          }
        }
        if (this.contentType === 27 || this.contentType === 28) {
          if (this.tableColumns[3].title === '活动类型（中文)') {
            this.tableColumns[3].title = '合作伙伴名称'
          }
          if (this.tableColumns[4].title === '活动类型（英文)') {
            this.tableColumns[4].title = '合作伙伴类型'
            this.tableColumns[4].key = 'type_title'
          }
        }
        if (this.contentType === 32 || this.contentType === 33) {
          if (this.tableColumns[2].title === '封面图') {
            this.tableColumns.splice(2, 3)
            this.tableColumns[2].title = '日期'
            this.tableColumns[2].key = 'publish_time'
            this.tableColumns[2].width = 360
          }
        }
        if (this.contentType === 34 || this.contentType === 35) {
          this.tableColumns[2].title = '酒店名称'
          this.tableColumns[2].key = 'title'
          this.tableColumns[3].title = '酒店地址'
          this.tableColumns[3].key = 'address'
          this.tableColumns[4].title = '经纬度'
          this.tableColumns[4].key = 'lat_long'
        }
      } else {
        if (this.tableColumns[1].title === '数据来源') {
          this.tableColumns.splice(1, 1)
        }
        if ([6, 7].includes(this.contentType)) {
          this.tableColumns[2].title = '嘉宾姓名'
          this.tableColumns[2].key = 'title'
          this.tableColumns[2].minWidth = 120
          this.tableColumns[3].title = '嘉宾类型'
          this.tableColumns[3].key = 'guest_type_name'
          this.tableColumns[3].width = 120
        }
        if ([8, 9].includes(this.contentType)) {
          this.tableColumns[2].title = '嘉宾姓名'
          this.tableColumns[2].key = 'title'
          this.tableColumns[2].minWidth = 120
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns.splice(3, 1)
          }
        }
        if ([10, 11].includes(this.contentType)) {
          this.tableColumns[2].title = '赛事标题'
          this.tableColumns[2].key = 'title'
          this.tableColumns[2].minWidth = 120
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns.splice(3, 1)
          }
        }
        if (
          this.contentType === 16 ||
          this.contentType === 1 ||
          this.contentType === 2 ||
          this.contentType === 12 ||
          this.contentType === 13
        ) {
          if (this.tableColumns[1].title === '封面图') {
            this.tableColumns.splice(1, 1)
          }
        }
        if (this.contentType === 1) {
          if (this.tableColumns[2].title === '活动类型（英文)') {
            this.tableColumns[1].title = '标题'
            this.tableColumns[1].key = 'title'
            this.tableColumns.splice(2, 1)
          }
        }
        if (this.contentType === 2) {
          if (this.tableColumns[1].title === '活动类型（中文)') {
            this.tableColumns[1].title = '标题'
            this.tableColumns[1].key = 'title'
            this.tableColumns.splice(2, 1)
          }
        }
        if ([12, 13].includes(this.contentType)) {
          if (this.tableColumns[2].title === '活动类型（英文)') {
            this.tableColumns[1].title = '文章标题'
            this.tableColumns[1].key = 'title'
            this.tableColumns.splice(2, 2)
          }
        }
        if (this.contentType === 17 || this.contentType === 18) {
          // this.tableColumns.splice(2, 1)
          this.tableColumns[2].title = '标题'
          this.tableColumns[2].key = 'title'
          this.tableColumns[2].minWidth = 120
          this.tableColumns[3].title = '活动类型'
          this.tableColumns[3].key = 'type_title'
          this.tableColumns[3].width = 120
        }
        if (this.contentType === 19 || this.contentType === 20 || this.contentType === 37 || this.contentType === 38) {
          if (this.tableColumns[2].title === '活动类型（中文)') {
            this.tableColumns[2].title = '标题'
            this.tableColumns[2].key = 'title'
            this.tableColumns[2].minWidth = 120
            this.tableColumns.splice(3, 1)
          }
        }
        if (this.contentType === 3) {
          // 日程类型
          if (this.tableColumns[1].title === '封面图') {
            this.tableColumns.splice(1, 1)
            this.tableColumns[1].title = '论坛类型（中文）'
            this.tableColumns[1].key = 'title'
            this.tableColumns[1].minWidth = 180
            this.tableColumns[2].title = '论坛类型（英文）'
            this.tableColumns[2].key = 'en_title'
            this.tableColumns[2].width = 160
            this.tableColumns[3].title = '上级类型'
            this.tableColumns[3].key = 'type_name'
            const item = { title: '排序', key: 'weight', minWidth: 160 }
            this.tableColumns.splice(4, 1, item)
            // const column4 = { ...this.tableColumns[5] }
            // this.tableColumns[4] = column4
          }
        }
        if (this.contentType === 4 || this.contentType === 5) {
          const list = this.tableColumns;
          let hasLike = false;
          list.forEach(item => {
            if (item.key === 'like_num') {
              hasLike = true;
            };
          });
          if (!hasLike) {
            // const data = { title: '点赞数', key: 'like_num', align: 'center', width: 80 };
            // this.tableColumns.splice(9, 0, data);
          };
          // 日程中文列表
          const item = { title: '论坛标题', key: 'title', minWidth: 160 }
          this.tableColumns.splice(1, 1, item)
          this.tableColumns[1].title = '论坛标题'
          this.tableColumns[1].key = 'title'
          this.tableColumns[1].minWidth = 160
          this.tableColumns[2].title = '论坛类型'
          this.tableColumns[2].key = 'schedule_type_name'
          this.tableColumns[2].width = 160
          this.tableColumns[3].title = '论坛时间'
          this.tableColumns[3].key = 'schedule_time'
          this.tableColumns[3].render = (h, params) => {
            const text =
              typeof params.row.schedule_time === 'object'
                ? params.row.schedule_time.map((items, index) => {
                    return (
                      <p>
                        {items.date + ' ' + items.time}
                        {index === params.row.schedule_time.length - 1
                          ? ''
                          : ','}
                      </p>
                    )
                  })
                : ''
            return h('div', {}, text)
          }
        }
        if ([21, 22, 23].includes(this.contentType)) {
          if (this.tableColumns[1].title === '封面图') {
            this.tableColumns.splice(1, 1)
          }
        }
        if (this.contentType === 21) {
          if (this.tableColumns[1].title === '活动类型（中文)') {
            this.tableColumns[1].title = '新闻类型（中文)'
          }
          if (this.tableColumns[2].title === '活动类型（英文)') {
            this.tableColumns[2].title = '新闻类型（英文)'
          }
        }
        if (this.contentType === 22 || this.contentType === 23) {
          if (this.tableColumns[1].title === '活动类型（中文)') {
            this.tableColumns[1].title = '资讯标题'
          }
          if (this.tableColumns[2].title === '活动类型（英文)') {
            this.tableColumns[2].title = '资讯类型'
            this.tableColumns[2].key = 'type_title'
          }
          if (this.tableColumns[3].title !== '状态') {
            this.tableColumns.splice(3, 0, {
              title: '状态',
              key: 'weight',
              align: 'center',
              width: 80,
              render: (h, params) => {
                const text = params.row.other_data.is_top === '2' ? '/' : '置顶'
                return h('div', {}, text)
              }
            })
          }
          if (this.tableColumns[4].title === '排序') {
            this.tableColumns[4].title = '置顶排序'
            this.tableColumns[4].render = (h, params) => {
              const text =
                params.row.other_data.is_top === '2' ? '/' : params.row.weight
              return h('div', {}, text)
            }
          }
        }
        if (this.contentType === 24 || this.contentType === 25) {
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns.splice(3, 1)
          }
          this.tableColumns[1].title = 'banner图'
          this.tableColumns[2].title = '标题'
          this.tableColumns[2].key = 'title'
        }
        if (this.contentType === 26) {
          if (this.tableColumns[1].title === '封面图') {
            this.tableColumns.splice(1, 1)
          }
          if (this.tableColumns[1].title === '活动类型（中文)') {
            this.tableColumns[1].title = '伙伴类型（中文)'
          }
          if (this.tableColumns[2].title === '活动类型（英文)') {
            this.tableColumns[2].title = '伙伴类型（英文)'
          }
        }
        if (this.contentType === 27 || this.contentType === 28) {
          if (this.tableColumns[2].title === '活动类型（中文)') {
            this.tableColumns[2].title = '合作伙伴名称'
          }
          if (this.tableColumns[3].title === '活动类型（英文)') {
            this.tableColumns[3].title = '合作伙伴类型'
            this.tableColumns[3].key = 'type_title'
          }
        }
        if (this.contentType === 32 || this.contentType === 33) {
          if (this.tableColumns[1].title === '封面图') {
            this.tableColumns.splice(1, 3)
            this.tableColumns[1].title = '日期'
            this.tableColumns[1].key = 'publish_time'
            this.tableColumns[1].width = 360
          }
        }
        if (this.contentType === 34 || this.contentType === 35) {
          const item = { title: '酒店名称', key: 'title', minWidth: 160 }
          this.tableColumns.splice(1, 1, item)
          this.tableColumns[2].title = '酒店地址'
          this.tableColumns[2].key = 'address'
          this.tableColumns[3].title = '经纬度'
          this.tableColumns[3].key = 'lat_long'
        }
      }
      this.getListData()
    },
    // 清空表单状态
    clearSearch() {
      this.queryData.p = 1
      this.queryData.page_size = this.pageSizeOpts[0]
      this.queryData.search_title = ''
      this.queryData.search_type = ''
      this.queryData.guest_type = ''
      this.queryData.news_type = ''
      this.queryData.partner_type = ''
      this.queryData.type = ''
      this.queryData.schedule_type = ''
      this.queryData.draft_status = 2
      this.getListData()
    },
    // 选择数据
    selectChange(select) {
      let idStr = ''
      for (const i in select) {
        idStr += (idStr !== '' ? ',' : '') + select[i].id
      }
      this.selectListId = idStr
    },
    /**
     * 分页变化
     */
    changePage(page) {
      this.queryData.p = page
      this.getListData()
    },
    PageSizeChange(pageSize) {
      this.queryData.page_size = pageSize
      this.queryData.p = 1
      this.getListData()
    },
    // 自适应大小
    resize() {
      const listHeight = 74
      const searchHeight = 335
      let listNum = ((window.innerHeight - searchHeight) / listHeight) >> 0
      if (listNum < 3) {
        listNum = 3
      }
      this.pageSizeOpts[0] = listNum
      this.pageSizeOpts[1] = listNum * 2
      this.pageSizeOpts[2] = listNum * 3
      this.queryData.page_size = listNum
      if (this.$route.query.tab_type) {
        this.tabs.map((item, index) => {
          if (item.value * 1 === this.$route.query.tab_type * 1) {
            this.tabIndex = index
          }
        })
        this.tabsChange(this.tabIndex, true, this.$route.query.p)
      } else {
        this.tabsChange(0, true)
      }
    }
  }
}
</script>
<style lang="less">
.content-list-page {
  padding-bottom: 40px;
  padding-top: 0px !important;
  .ivu-tabs {
    padding-top: 0px;
    .ivu-tabs-nav-right {
      height: 44px;
      line-height: 40px;
      button {
        margin-left: 10px;
      }
    }
  }
  .ivu-table-overflowX {
    &::-webkit-scrollbar {
      height: 16px;
      width: 4px;
    }
    &::-webkit-scrollbar-track {
      visibility: hidden; /* doesn't seem to work */
    }
    &::-webkit-scrollbar-thumb {
      background: #dcdee2;
    }
    &::-webkit-scrollbar-thumb:hover {
      background: rgba(0, 0, 0, 0.2);
    }
    &::-webkit-scrollbar:window-inactive {
      visibility: hidden;
    }
  }
  .ivu-tabs-bar {
    margin-bottom: 0px;
  }
  .ivu-table-column-center {
    .ivu-table-cell {
      padding: 0px 4px;
    }
  }
  .ivu-form-item-label {
    font-weight: bold;
    color: #464c5b;
    font-size: 14px;
  }
  .ivu-form-item-content {
    font-size: 14px;
  }
  .ivu-tabs-nav-container {
    .ivu-tabs-tab {
      padding: 12px 16px;
    }
  }
  .search-container {
    margin-top: 20px;
    height: 32px;
    .sc-left {
      float: left;
      width: calc(~'100% - 170px');
      .inputList {
        width: calc(~'100% - 245px');
        margin-right: 10px;
      }
      .inputList2 {
        width: calc(~'100% - 469px');
        margin-right: 10px;
      }
    }
    .sc-right {
      float: right;
      button {
        margin-left: 20px;
      }
    }
  }
  .form-container {
    clear: both;
    margin-top: 20px;
    &-page {
      margin: 10px 0;
      line-height: 32px;
    }
  }
  .demo-drawer-footer {
    width: 100%;
    /*position: absolute;*/
    /*bottom: 0;*/
    /*left: 0;*/
    border-top: 1px solid #e7e8eb;
    padding: 20px 16px;
    text-align: right;
    background: #fff;
    button {
      margin-left: 10px;
    }
  }
  .ticket-list {
    .list-item {
      .i-title {
        display: inline-block;
        width: 80px;
        text-align: right;
        margin-right: 35px;
      }
      .i-check {
        color: #ff9901;
      }
      .i-check-btn {
        margin-left: 43px;
        color: #0252db;
        cursor: pointer;
      }
    }
  }
}
</style>
