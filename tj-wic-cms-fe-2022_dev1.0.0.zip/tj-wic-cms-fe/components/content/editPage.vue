<template>
  <div class="content-edit-page">
    <Form ref="form" :model="form" :rules="formRules" :label-width="100">
      <FormItem
        v-if="[1].indexOf(contentType) != -1"
        label="报道类型"
        prop="other_data.report_type"
      >
        <Select
          v-model="form.other_data.report_type"
          placeholder="请选择报道类型"
          @on-change="validateChange"
        >
          <Option
            v-for="(item, index) in reportTypeList"
            :key="'report_type_' + index"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem
        v-if="[23].indexOf(contentType) == -1"
        label="标题"
        prop="title"
      >
        <Input
          v-model="form.title"
          placeholder="请输入标题"
          :maxlength="500"
          class="input-word-limit"
          show-word-limit
        />
      </FormItem>
      <FormItem
        v-if="[23, 24].indexOf(contentType) == -1"
        label="副标题"
        prop="sub_title"
      >
        <Input
          v-model="form.sub_title"
          placeholder="请输入副标题"
          :maxlength="500"
          class="input-word-limit"
          show-word-limit
        />
      </FormItem>
      <FormItem
        v-if="[23, 24].indexOf(contentType) == -1"
        label="摘要"
        prop="content"
      >
        <Input
          v-model="form.content"
          placeholder="请输入摘要"
          type="textarea"
          :rows="4"
          :maxlength="500"
          class="input-word-limit"
          show-word-limit
        />
      </FormItem>
      <FormItem label="版本标签" prop="tag">
        <CheckboxGroup v-model="form.tag">
          <Checkbox
            v-for="item in langList"
            :key="item.value"
            :label="item.value"
            >{{ item.label }}</Checkbox
          >
        </CheckboxGroup>
      </FormItem>
      <FormItem
        v-if="[11].indexOf(contentType) != -1"
        label="发布时间"
        prop="publish_time"
      >
        <DatePicker
          v-model="form.publish_time"
          type="datetime"
          placeholder="点击选择发布时间"
          style="width: 230px"
        ></DatePicker>
      </FormItem>
      <FormItem v-if="[11].includes(contentType)" label="排序" prop="weight">
        <InputNumber
          v-model="form.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px"
        /><Checkbox
          v-if="[12, 13].indexOf(contentType) == -1"
          style="margin-left:10px"
          @on-change="weightChange"
          >置顶</Checkbox
        ><span class="inputTip"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem
        v-if="contentType == 11"
        label="跳转类型"
        prop="other_data.exhibitor_notice_link_type"
      >
        <Select
          v-model="form.other_data.exhibitor_notice_link_type"
          placeholder="请选择跳转类型"
        >
          <Option
            v-for="item in linkTypeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem
        v-if="
          [10, 12, 13, 23, 24, 11].indexOf(contentType) == -1 ||
            (contentType == 11 &&
              form.other_data.exhibitor_notice_link_type != 'jump_href')
        "
        label="届数"
        prop="session"
      >
        <Select v-model="form.other_data.session" placeholder="请选择届数">
          <Option
            v-for="item in sessionList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem
        v-if="
          [10, 12, 13, 23, 24, 11].indexOf(contentType) == -1 ||
            (contentType == 11 &&
              form.other_data.exhibitor_notice_link_type != 'jump_href')
        "
        label="媒体来源"
        prop="source"
      >
        <Input
          v-model="form.source"
          :maxlength="50"
          class="input-word-limit"
          placeholder="请输入媒体来源"
          show-word-limit
        />
      </FormItem>
      <FormItem
        v-if="[11, 23, 24].indexOf(contentType) == -1"
        label="排序"
        prop="weight"
      >
        <InputNumber
          v-model="form.weight"
          :min="1"
          :max="999"
          :precision="0"
          placeholder="请输入排序值"
          style="width:150px"
        /><Checkbox
          v-if="[12, 13].indexOf(contentType) == -1"
          style="margin-left:10px"
          @on-change="weightChange"
          >置顶</Checkbox
        ><span class="inputTip"
          >请输入1-999间的整数，输入数字越小，排序越靠前</span
        >
      </FormItem>
      <FormItem
        v-if="[1, 2, 3, 4, 5, 10].indexOf(contentType) != -1"
        label="发布时间"
        prop="publish_time"
      >
        <DatePicker
          v-model="form.publish_time"
          type="datetime"
          placeholder="点击选择发布时间"
          style="width: 230px"
        ></DatePicker>
      </FormItem>
      <FormItem
        v-if="
          [1, 3, 10, 12, 13, 23, 24, 11].indexOf(contentType) == -1 ||
            (contentType == 11 &&
              form.other_data.exhibitor_notice_link_type != 'jump_href')
        "
        label="封面图"
        prop="head_img"
      >
        <Input
          v-if="false"
          v-model="form.head_img"
          placeholder="请上传图片"
          style="width:300px"
        /><Button type="primary" @click="selectFile('image', 'head_img')"
          >上传图片</Button
        >
        <div v-if="form.head_img" class="l-tabbar-upload-box-img">
          <img :src="form.head_img" />
          <Icon type="md-trash" size="18" @click="deleteImg('head_img')" />
        </div>
      </FormItem>
      <FormItem
        v-if="[3].indexOf(contentType) != -1"
        label="封面图"
        prop="head_img"
      >
        <CustomVueCropper
          id="head_img"
          :value="form.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="282"
          :height="158"
          :fixed-number="[282, 158]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem
        v-if="contentType == 1"
        class="relesImg"
        label="PC端封面图"
        prop="head_img"
      >
        <CustomVueCropper
          id="head_img"
          :value="form.head_img"
          :fixed="true"
          :is-operation-location="true"
          :width="282"
          :height="158"
          :fixed-number="[282, 158]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem
        v-if="contentType == 1"
        class="relesImg"
        label="H5端封面图"
        prop="other_data.H5CoverImage"
      >
        <CustomVueCropper
          id="H5CoverImage"
          :value="form.other_data.H5CoverImage"
          :fixed="true"
          :is-operation-location="true"
          :width="240"
          :height="180"
          :fixed-number="[240, 180]"
          @onUploadImage="onUploadImage"
        />
      </FormItem>
      <FormItem v-if="contentType == 2" label="音频" prop="audio_source">
        <Input
          v-if="false"
          v-model="form.audio_source"
          placeholder="请上传音频源"
          style="width:300px"
        /><Button type="primary" @click="selectFile('audio', 'audio_source')"
          >上传音频</Button
        ><span class="inputTip">支持mp3，最多上传1个音频。</span>
        <div v-if="form.audio_source" class="audioPlayer">
          <audio preload="auto" controls controlsList="nodownload">
            <source :src="form.audio_source" type="audio/mpeg" /></audio
          ><Icon
            class="deleteBtn"
            type="md-trash"
            size="18"
            @click="deleteAudio('audio_source')"
          />
        </div>
      </FormItem>
      <FormItem
        v-if="[2, 12, 13].indexOf(contentType) == -1 && false"
        label="视频源"
        prop="video_source"
      >
        <Input
          v-model="form.video_source"
          placeholder="请输入腾讯视频地址"
        /><span class="inputTip"
          >请先将视频传到腾讯视频,然后再复制粘贴视频地址.</span
        >
      </FormItem>
      <FormItem
        v-if="contentType == 10"
        label="跳转类型"
        prop="other_data.buyer_hot_link_type"
      >
        <Select
          v-model="form.other_data.buyer_hot_link_type"
          placeholder="请选择跳转类型"
        >
          <Option
            v-for="item in linkTypeList"
            :key="item.value"
            :value="item.value"
            >{{ item.label }}</Option
          >
        </Select>
      </FormItem>
      <FormItem
        v-if="
          [10, 11, 23, 24].indexOf(contentType) == -1 ||
            (contentType == 11 &&
              form.other_data.exhibitor_notice_link_type != 'jump_href') ||
            (contentType == 10 &&
              form.other_data.buyer_hot_link_type != 'jump_href')
        "
        label="添加文档"
        prop="attachment_source"
      >
        <div v-if="form.attachment_source.length < 10">
          <Button
            type="primary"
            @click="selectFile('document', 'attachment_source')"
            >上传文档</Button
          ><span class="inputTip">最多上传10个文档</span>
        </div>
        <div
          v-if="form.attachment_source && form.attachment_source.length > 0"
          class="attachmentList"
        >
          <Table
            :border="false"
            :width="400"
            :show-header="false"
            :context-menu="true"
            :draggable="false"
            :columns="documentColumns"
            :data="form.attachment_source"
            @on-drag-drop="attachmentDrop"
          >
            <template slot="contextMenu">
              <DropdownItem @click.native="handleContextMenuEdit"
                >编辑</DropdownItem
              >
              <DropdownItem
                style="color: #ed4014"
                @click.native="handleContextMenuDelete"
                >删除</DropdownItem
              >
            </template>
          </Table>
        </div>
      </FormItem>
      <FormItem
        v-if="
          [4].indexOf(contentType) !== -1 ||
            (contentType == 11 &&
              form.other_data.exhibitor_notice_link_type !== 'jump_href')
        "
        label="添加文件"
        prop="other_data.file_source"
      >
        <div v-if="form.other_data.file_source.length < 10">
          <Button
            type="primary"
            @click="selectFile('attachment', 'other_data.file_source')"
            >上传文件</Button
          ><span class="inputTip">最多上传10个文件</span>
        </div>
        <div
          v-if="
            form.other_data.file_source &&
              form.other_data.file_source.length > 0
          "
          class="attachmentList"
        >
          <Table
            :border="false"
            :width="400"
            :show-header="false"
            :context-menu="true"
            :draggable="false"
            :columns="attachmentColumns"
            :data="form.other_data.file_source"
            @on-drag-drop="attachmentDrop"
          >
            <template slot="contextMenu">
              <DropdownItem @click.native="handleContextMenuEdit"
                >编辑</DropdownItem
              >
              <DropdownItem
                style="color: #ed4014"
                @click.native="handleContextMenuDelete"
                >删除</DropdownItem
              >
            </template>
          </Table>
        </div>
      </FormItem>
      <FormItem
        v-if="
          contentType == 10 &&
            form.other_data.buyer_hot_link_type == 'jump_href'
        "
        label="跳转URL"
        prop="other_data.buyer_hot_link_url"
        class="requireStar"
      >
        <Input
          v-model="form.other_data.buyer_hot_link_url"
          :maxlength="500"
          show-word-limit
          class="input-word-limit"
          placeholder="请输入跳转URL"
        />
      </FormItem>
      <FormItem
        v-if="
          contentType == 11 &&
            form.other_data.exhibitor_notice_link_type == 'jump_href'
        "
        class="requireStar"
        label="跳转URL"
        prop="other_data.exhibitor_notice_link_url"
      >
        <Input
          v-model="form.other_data.exhibitor_notice_link_url"
          :maxlength="500"
          show-word-limit
          class="input-word-limit"
          placeholder="请输入跳转URL"
        />
      </FormItem>
      <FormItem
        v-if="
          [23, 24].indexOf(contentType) == -1 &&
            form.other_data.exhibitor_notice_link_type !== 'jump_href' &&
            form.other_data.buyer_hot_link_type !== 'jump_href'
        "
        label="文章内容"
        prop="html_content"
      >
        <vue-ueditor-wrap
          v-model="form.html_content"
          :config="editorConfig"
          @ready="editorReady"
        />
      </FormItem>
      <FooterButton
        :loading="loading"
        :form="form"
        :content-type="contentType"
        :tab-type="tab_type"
        :p="p"
        @submitForm="submitForm"
      />
    </Form>
    <showIframe :show-obj="showIframeObj" @getSelectFile="getSelectFile" />
  </div>
</template>
<script>
import VueUeditorWrap from 'vue-ueditor-wrap'
import FooterButton from '@/components/content/fotterButton'
import showIframe from '@/components/iframe'
import CustomVueCropper from '@/components/imgUpload/CustomVueCropper'
import {
  GetLangData,
  getSessionList,
  getReportType,
  GetEnterpriseType,
  getlinkType
} from '@/api/common'
import { getView, getPreview } from '@/api/content'
import Setting from '@/wau.config'
import util from '@/libs/util'
export default {
  name: 'ContentEditPage',
  components: {
    FooterButton,
    VueUeditorWrap,
    CustomVueCropper,
    showIframe
  },
  data() {
    return {
      tab_type: '',
      p: '',
      enterprise: [], // 企业类型
      contentType: '',
      id: '',
      showIframeObj: {
        limit: 10,
        show: false,
        valObj: '',
        type: ''
      },
      documentColumns: [
        {
          render: (h, params) => {
            return h('div', [
              h(
                'Icon',
                {
                  style: { marginRight: '6px' },
                  props: { type: 'ios-copy-outline', size: 18 }
                },
                ''
              ),
              h('span', {}, params.row.title)
            ])
          }
        },
        {
          width: 60,
          align: 'right',
          title: 'control',
          render: (h, params) => {
            return h(
              'Icon',
              {
                props: { type: 'md-trash', size: 18 },
                style: { cursor: 'pointer' },
                class: 'deleteBtn',
                on: {
                  click: () => {
                    this.deleteAttachment(params.index)
                  }
                }
              },
              ''
            )
          }
        }
      ],
      attachmentColumns: [
        {
          render: (h, params) => {
            return h('div', [
              h(
                'Icon',
                {
                  style: { marginRight: '6px' },
                  props: { type: 'ios-copy-outline', size: 18 }
                },
                ''
              ),
              h('span', {}, params.row.title)
            ])
          }
        },
        {
          width: 60,
          align: 'right',
          title: 'control',
          render: (h, params) => {
            return h(
              'Icon',
              {
                props: { type: 'md-trash', size: 18 },
                style: { cursor: 'pointer' },
                class: 'deleteBtn',
                on: {
                  click: () => {
                    this.deleteAttachments(params.index)
                  }
                }
              },
              ''
            )
          }
        }
      ],
      loading: false,
      langList: [], // 版本下拉列表
      reportTypeList: [],
      sessionList: [], // 届数列表
      showZoneList: [], // 展区列表
      linkTypeList: [], // 跳转类型
      form: {
        title: '',
        sub_title: '',
        content: '',
        tag: [],
        source: '',
        weight: 999,
        head_img: '',
        audio_source: '',
        video_source: '',
        html_content: '',
        content_model_is_preview: '',
        publish_time: '',
        tag_str: '',
        other_data: {
          exhibitor_notice_link_url: '',
          exhibitor_notice_link_type: '',
          buyer_hot_link_type: '',
          buyer_hot_link_url: '',
          report_type: '',
          session: '',
          content_model: '',
          H5CoverImage: '',
          file_source: [] // 文件上传
        },
        attachment_source: []
      },
      formRules: {
        weight: [
          {
            required: true,
            type: 'number',
            message: '请输入数字',
            trigger: 'change'
          }
        ],
        'other_data.buyer_hot_link_type': [
          {
            required: true,
            type: 'string',
            message: '请至少选择一个选项',
            trigger: 'change'
          }
        ],
        'other_data.buyer_hot_link_url': [
          { required: true, message: '请输入跳转URL', trigger: 'blur' }
        ],
        'other_data.exhibitor_notice_link_type': [
          {
            required: true,
            type: 'string',
            message: '请至少选择一个选项',
            trigger: 'change'
          }
        ],
        'other_data.exhibitor_notice_link_url': [
          { required: true, message: '请输入跳转URL', trigger: 'blur' }
        ],
        'other_data.report_type': [
          {
            required: true,
            type: 'string',
            min: 1,
            message: '请选择报道类型',
            trigger: 'change'
          }
        ],
        'other_data.H5CoverImage': [
          { required: false, message: '请上传图片', trigger: 'change' }
        ],
        title: [{ required: true, message: '请输入文章标题', trigger: 'blur' }],
        tag: [
          {
            required: true,
            type: 'array',
            min: 1,
            message: '请至少选择一个选项',
            trigger: 'change'
          }
        ],
        html_content: [
          { required: true, message: '请填写文章内容', trigger: 'blur' }
        ]
      },
      editorConfig: {
        // 编辑器不自动被内容撑高
        autoHeightEnabled: true,
        // 初始容器高度
        initialFrameHeight: 150,
        maximumWords: 100000,
        // 初始容器宽度
        initialFrameWidth: '100%',
        catchRemoteImageEnable: false,
        UEDITOR_HOME_URL: Setting.editorUrl
      },
      uEditor: null
    }
  },
  beforeDestroy() {
    if (this.uEditor) {
      this.uEditor.destroy()
    }
    window.removeEventListener('resize', this.resize)
  },
  created() {
    this.tab_type = this.$route.query.tab_type * 1
    this.p = this.$route.query.p * 1
    this.id = this.$route.query.id
    this.contentType = this.$route.query.contentType * 1
    switch (this.contentType) {
      case 1:
        if (!this.formRules.other_data) {
          this.formRules.other_data = {}
        }
        this.formRules['other_data.H5CoverImage'] = [
          { required: false, message: '请上传图片', trigger: 'change' }
        ]
        this.formRules.head_img = [
          { required: false, message: '请上传图片', trigger: 'change' }
        ]
        break
      case 3:
        delete this.formRules.html_content
        break
    }
    this.loadStatus()
  },
  mounted() {
    const that = this
    window.cmsSelectImg = function() {
      that.showIframeObj = {
        limit: 10,
        show: true,
        valObj: 'editor',
        type: 'image'
      }
    }
    // 编辑器的视频选择
    window.editorVideoSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editorVideo',
        type: 'video'
      }
    }
    // 编辑器的视频封面选择
    window.editorVideoImgSelect = function() {
      that.showIframeObj = {
        limit: 1,
        show: true,
        valObj: 'editorVideoImg',
        type: 'image'
      }
    }
    window.isEditIng = true
  },
  methods: {
    // 置顶
    weightChange(val) {
      if (val) {
        this.form.weight = 1
      } else {
        this.form.weight = 999
      }
    },
    // 删除音频
    deleteAudio(name) {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除吗?`,
        closable: true,
        onOk: () => {
          that.form[name] = ''
        }
      })
    },
    // 删除文档
    deleteAttachment(index, params) {
      const that = this
      this.$Modal.confirm({
        title: '删除附件',
        content: `确定要删除吗?`,
        closable: true,
        onOk: () => {
          that.form.attachment_source.splice(index, 1)
        }
      })
    },
    // 删除附件
    deleteAttachments(index, params) {
      const that = this
      this.$Modal.confirm({
        title: '删除附件',
        content: `确定要删除吗?`,
        closable: true,
        onOk: () => {
          that.form.other_data.file_source.splice(index, 1)
        }
      })
    },
    editorReady(e) {
      this.uEditor = e
    },
    // 选择文件
    selectFile(type, valObj) {
      console.log(type, valObj)
      let limit = 1
      if (type === 'document') {
        limit = 10 - this.form.attachment_source.length
      }
      if (type === 'attachment') {
        limit = 10 - this.form.other_data.file_source.length
      }
      this.showIframeObj = {
        limit,
        show: true,
        valObj,
        type
      }
    },
    // 获取选择后的文件列表
    getSelectFile(type, list) {
      console.log(type, list, '选择文件后')
      const that = this
      const addArr = []
      switch (type) {
        case 'audio':
          this.form[this.showIframeObj.valObj] = list[0].play_url
          break
        case 'image':
          if (this.showIframeObj.valObj === 'editor') {
            let insertHtml = ''
            list.map((item) => {
              insertHtml += '<img src="' + item.img_url + '" />'
            })
            that.uEditor.execCommand('insertHtml', insertHtml)
          } else if (this.showIframeObj.valObj === 'editorVideoImg') {
            window.setEditorVideo('img', list[0].img_url)
          } else {
            this.form[this.showIframeObj.valObj] = list[0].img_url
          }
          break
        case 'video':
          if (this.showIframeObj.valObj === 'editorVideo') {
            window.setEditorVideo('video', list[0].play_url)
            window.setEditorVideo('img', list[0].title_url)
          } else {
            this.form[this.showIframeObj.valObj] = list[0].play_url
          }
          break
        case 'document':
          list.map((item) => {
            let addBo = true
            that.form[that.showIframeObj.valObj].map((item2) => {
              if (item2.src === item.attachment_url) {
                addBo = false
              }
            })
            if (addBo === true) {
              addArr.push({
                title: item.name,
                src: item.attachment_url
              })
            }
          })
          this.form[this.showIframeObj.valObj] = [
            ...this.form[this.showIframeObj.valObj],
            ...addArr
          ]
          break
        case 'attachment':
          list.map((item) => {
            let addBo = true
            this.form.other_data.file_source.map((item2) => {
              if (item2.src === item.attachment_url) {
                addBo = false
              }
            })
            if (addBo === true) {
              addArr.push({
                title: item.name,
                src: item.attachment_url
              })
            }
          })
          this.form.other_data.file_source = [
            ...this.form.other_data.file_source,
            ...addArr
          ]
          break
      }
      this.showIframeObj.show = false
    },
    // 删除图片
    deleteImg(_formName) {
      const that = this
      this.$Modal.confirm({
        title: '删除',
        content: `确定要删除该图片吗?`,
        closable: true,
        onOk: () => {
          that.form[_formName] = ''
        }
      })
    },
    // 裁截图片后
    onUploadImage(url, name) {
      console.log(url, name, '++++++++++++++++++++++++')
      const that = this
      if (name === 'H5CoverImage') {
        this.form.other_data[name] = url
        if (
          this.contentType === 1 &&
          (name === 'head_img' || name === 'H5CoverImage')
        ) {
          this.validateChange()
          that.$refs.form.validateField('other_data.H5CoverImage')
          that.$refs.form.validateField('head_img')
          setTimeout(() => {
            this.validateChange()
          }, 100)
        } else {
          this.$refs.form.validateField(`other_data.${name}`)
        }
      } else {
        this.form[name] = url
        if (
          this.contentType === 1 &&
          (name === 'head_img' || name === 'H5CoverImage')
        ) {
          this.validateChange()
          that.$refs.form.validateField('other_data.H5CoverImage')
          that.$refs.form.validateField('head_img')
          setTimeout(() => {
            this.validateChange()
          }, 100)
        } else {
          this.$refs.form.validateField(name)
        }
      }
    },
    // 改变表单验证规则
    validateChange() {
      if (this.contentType === 1) {
        if (
          this.form.head_img !== '' ||
          this.form.other_data.H5CoverImage !== '' ||
          this.form.other_data.report_type * 1 === 2
        ) {
          // 添加必填
          this.formRules['other_data.H5CoverImage'][0].required = true
          this.formRules.head_img[0].required = true
          document
            .getElementsByClassName('relesImg')[0]
            .setAttribute(
              'class',
              'relesImg ivu-form-item ivu-form-item-required'
            )
          document
            .getElementsByClassName('relesImg')[1]
            .setAttribute(
              'class',
              'relesImg ivu-form-item ivu-form-item-required'
            )
        } else {
          // 取消必填
          this.formRules['other_data.H5CoverImage'][0].required = false
          this.formRules.head_img[0].required = false
          document
            .getElementsByClassName('relesImg')[0]
            .setAttribute('class', 'relesImg ivu-form-item')
          document
            .getElementsByClassName('relesImg')[1]
            .setAttribute('class', 'relesImg ivu-form-item')
        }
      }
    },
    // 加载下拉状态
    loadStatus() {
      GetLangData().then((res) => {
        if (res.ret === 0) {
          this.langList = res.data
        }
      })
      getSessionList().then((res) => {
        if (res.ret === 0) {
          res.data.map((item) => {
            item.value = String(item.value)
          })
          this.sessionList = res.data
          if (this.id !== 0 && this.id !== '0') {
            this.loadInfo()
          } else {
            this.form.other_data.session = String(res.data[0].value)
          }
        }
      })
      if (this.contentType === 1) {
        getReportType().then((res) => {
          if (res.ret === 0) {
            res.data.map((item) => {
              item.value = String(item.value)
            })
            this.reportTypeList = res.data
          }
        })
      }
      if (this.contentType === 23) {
        GetEnterpriseType({ all: 0 })
          .then((res) => {
            this.enterprise = res.data
          })
          .catch((err) => {
            console.log(err)
          })
      }
      if (this.contentType === 11 || this.contentType === 10) {
        getlinkType().then((res) => {
          if (res.ret === 0) {
            this.linkTypeList = res.data
            if (this.id * 1 === 0) {
              switch (this.contentType) {
                case 10:
                  this.form.other_data.buyer_hot_link_type = res.data[0].value
                  break
                case 11:
                  this.form.other_data.exhibitor_notice_link_type =
                    res.data[0].value
                  break
              }
            }
          }
        })
      }
    },
    // 加载信息
    loadInfo() {
      this.$Loading.start()
      this.loading = true
      const view_type = this.$route.query.view_type
      getView({
        tab_type: this.tab_type,
        _id: this.id,
        view_type
      }).then((res) => {
        this.loading = false
        if (res.ret === 0) {
          this.$Loading.finish()
          if (!res.data.tag) {
            res.data.tag = []
          }
          res.data.weight *= 1
          res.data.other_data.session = String(res.data.other_data.session)
          if (res.data.attachment_source) {
            try {
              res.data.attachment_source = JSON.parse(
                res.data.attachment_source
              )
            } catch (e) {
              res.data.attachment_source = []
            }
          } else {
            res.data.attachment_source = []
          }
          if (res.data.other_data.file_source) {
            try {
              res.data.other_data.file_source = JSON.parse(
                res.data.other_data.file_source
              )
            } catch (e) {
              res.data.other_data.file_source = []
            }
          } else {
            res.data.other_data.file_source = []
          }
          console.log(res.data.other_data.file_source)
          for (const key in this.form) {
            if (key === 'other_data') {
              if (res.data.other_data) {
                for (const okey in this.form.other_data) {
                  if (res.data.other_data[okey]) {
                    this.form.other_data[okey] = res.data.other_data[okey]
                  }
                }
              }
            } else {
              this.form[key] = res.data[key]
            }
          }
          if (this.contentType === 1) {
            this.validateChange()
          }
        } else {
          this.$Loading.error()
          this.$Message.error(res.msg || '读取数据错误')
        }
      })
    },
    // 提交保存
    // submitType, 1,预览,2保存,3提交
    submitForm(formName, submitType) {
      const that = this
      // 清除校验状态
      that.$refs[formName].fields.map((item) => {
        item.validateState = false
      })
      // 录入员,提交数据
      // 审核员也可以提交数据了
      if (this.$store.role === 'operator' || 1 !== 0) {
        if (submitType === 1 || submitType === 3) {
          this.$refs[formName].validate((valid) => {
            if (valid) {
              that.submitData(submitType)
            } else {
              that.$Message.error(
                '请完善必填信息后再操作' +
                  (submitType === 1 ? '预览' : '提交') +
                  '!'
              )
              setTimeout(() => {
                that.validateChange()
              }, 100)
            }
          })
        } else if (this.form.title) {
          that.submitData(submitType)
        } else {
          that.$refs.form.validateField('title')
          that.$Message.error('请填写标题后再保存!')
        }
      } else {
        // 弃用
        // 获取预览接口
        this.loading = true
        getPreview({
          _id: this.id,
          tab_type: this.tab_type,
          content_type: this.contentType
        })
          .then((res) => {
            if (res.ret === 0) {
              if (res.data.preview_url) {
                window.open(res.data.preview_url)
              }
              that.loading = false
            } else {
              that.loading = false
              that.$Loading.error()
              that.$Message.error(res.msg || '保存数据失败')
            }
          })
          .catch((res) => {
            that.loading = false
          })
      }
    },
    // 拖动附件排序
    attachmentDrop(index1, index2) {
      console.log(index1, index2)
    },
    // 提交数据
    // submitType, 1,预览,2保存,3提交
    submitData(submitType) {
      const that = this
      const params = JSON.parse(JSON.stringify(this.form))
      delete params.content_model_is_preview
      params.content_type = this.contentType
      params.tab_type = this.tab_type
      if (params.attachment_source && params.attachment_source.length > 0) {
        params.attachment_source = JSON.stringify(params.attachment_source)
      } else {
        params.attachment_source = ''
      }
      if (
        params.other_data.file_source &&
        params.other_data.file_source.length > 0
      ) {
        params.other_data.file_source = JSON.stringify(
          params.other_data.file_source
        )
      } else {
        params.other_data.file_source = ''
      }
      console.log(params.other_data.file_source)
      if (this.id * 1 !== 0) {
        params._id = this.id
      }
      if (this.contentType === 1) {
        // 获取报道类型的字符串
        // this.reportTypeList.map((item) => {
        //   if (String(item.value) === that.form.other_data.report_type) {
        //     params.other_data.report_type_text = item.label
        //   }
        // })
      }
      util.editSaveContent(that, submitType, params)
    }
  }
}
</script>
<style lang="less">
.input-word {
  margin-right: 65px !important;
}
.requireStar .ivu-form-item-label:before {
  content: '*';
  display: inline-block;
  margin-right: 4px;
  line-height: 1;
  font-family: SimSun;
  font-size: 12px;
  color: #ed4014;
}
.content-edit-page {
  padding-top: 30px;
  .inputTip {
    margin-left: 10px;
    button {
      margin-right: 10px;
    }
  }
  .edui-default .edui-toolbar .edui-combox .edui-combox-body {
    height: 23px;
  }
  .edui-default .edui-editor-toolbarboxinner {
    height: 32px;
  }
  .audioPlayer {
    margin-top: 10px;
    audio {
      height: 36px;
      vertical-align: middle;
    }
    i {
      vertical-align: middle;
      margin-left: 10px;
    }
  }
  .ivu-table {
    &:before {
      background: #fff;
    }
    td {
      border-bottom: none;
    }
    .ivu-table-cell {
      padding-left: 0;
    }
  }
  .deleteBtn:hover {
    cursor: pointer;
    color: red;
  }
  .l-tabbar-upload-box-img {
    margin-top: 10px;
    img {
      vertical-align: bottom;
      display: inline-block;
      max-width: 300px;
      max-height: 150px;
      margin-right: 6px;
    }
    i {
      vertical-align: bottom;
      display: inline-block;
      cursor: pointer;
      &:hover {
        color: red;
      }
    }
  }
  .ivu-table-row td {
    height: auto;
  }
}
audio::-internal-media-controls-download-button {
  display: none;
}
audio::-webkit-media-controls-enclosure {
  overflow: hidden;
}
audio::-webkit-media-controls-panel {
  width: calc(100% + 30px);
}
</style>
