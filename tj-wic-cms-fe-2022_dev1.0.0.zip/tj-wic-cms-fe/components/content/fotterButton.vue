<template>
  <FormItem class="fotterButton" :label-width="alignLeft ? 0 : null">
    <Button
      v-if="
        [
          1,
          2,
          4,
          5,
          6,
          7,
          8,
          9,
          12,
          13,
          17,
          18,
          19,
          20,
          22,
          23,
          27,
          28,
          37,
          38
        ].includes(contentType) &&
          (tabType != 5 || !id)
      "
      type="primary"
      :disabled="loading"
      @click="submitForm(2)"
      >{{ loading ? 'loading...' : '预览' }}</Button
    >
    <Button
      v-if="tabType != 5 || !id"
      type="primary"
      :disabled="loading"
      @click="submitForm(-1)"
      >{{ loading ? 'loading...' : '保存' }}</Button
    >
    <Button
      v-if="tabType != 5 || !id"
      type="primary"
      :disabled="loading"
      @click="submitForm(0)"
      >{{ loading ? 'loading...' : '提交' }}</Button
    >
    <Button @click="goBackPage()">{{ tabType != 5 ? '取消' : '返回' }}</Button>
  </FormItem>
</template>
<script>
import util from '@/libs/util'
export default {
  name: 'FotterButtonCom',
  props: {
    form: {
      type: Object,
      default() {
        return {}
      }
    },
    alignLeft: {
      type: Boolean,
      default: false
    },
    loading: {
      type: Boolean,
      default: false
    },
    contentType: {
      type: Number,
      default: 0
    },
    tabType: {
      type: Number,
      default: 0
    },
    p: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      id: ''
    }
  },
  created() {
    this.id = this.$route.query.id
  },
  mounted() {
    if (this.tabType === 5 && this.id !== '') {
      setTimeout(() => {
        window.isEditIng = false
      }, 500)
    }
  },
  methods: {
    submitForm(submitType) {
      this.$emit('submitForm', submitType)
    },
    goBackPage() {
      this.tab_type = this.tabType
      util.goBackPage(this)
    }
  }
}
</script>
<style lang="less" scoped>
.fotterButton {
  button {
    margin-right: 10px;
  }
}
</style>
