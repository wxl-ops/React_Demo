/*
 * @Author: const_ytl
 * @Date: 2022-03-15 14:45:58
 * @LastEditors: const_ytl
 * @LastEditTime: 2022-03-28 14:16:08
 * @Description: 请填写简介
 */
const env = process.env.NODE_ENV
const url = window.location.host
console.log(url, '++++++++++++++++++++++++判断域名')
let material = []
if (url.includes('t-2022cms.wicongress.org.cn')) {
  material = [
    't-2022cms.wicongress.org.cn/content/',
    't-2022cms.wicongress.org.cn/',
    false
  ]
} else if (url.includes('2022cms.wicongress.org.cn')) {
  material = [
    '2022cms.wicongress.org.cn/content/',
    '2022cms.wicongress.org.cn/',
    false
  ]
} else {
  material = [
    't-2022cms.wicongress.org.cn/content/',
    't-2022cms.wicongress.org.cn/',
    false
  ]
}
//  else if (url.includes('cms.cantonfair.org.cn')) {
//   material = ['cms.cantonfair.org.cn/content/', 'cms.cantonfair.org.cn/', false]
// }
console.log(material)
export default {
  showBreadcrumb: true,
  showLog: false,
  layout: {
    logo: {
      src: '',
      title: '',
      href: '/'
    },
    siderTheme: 'dark',
    siderMenuWidth: 255,
    headerTheme: 'light'
  },
  menu: {
    source: 'remote'
  },
  editorUrl: env === 'development' ? '/cms-fe/ueditor/' : '/cms-fe/UEditor/',
  material,
  pageName: [
    'registrationAgreement-zh', // 注册协议
    'registrationAgreement-en',
    'agendaofConference-type', // 峰会与论坛类型
    'agendaofConference-zh', // 峰会与论坛
    'agendaofConference-en',
    'conferenceGuests-zh', // 大会嘉宾
    'conferenceGuests-en',
    'homoSapiens-zh', // 智人智语
    'homoSapiens-en',
    'cloudEvents-zh', // 云赛事
    'cloudEvents-en',
    'eventIntroduction-zh', // 赛事介绍文章
    'eventIntroduction-en',
    '', // 云系列活动直播配置
    '',
    'cloudSeriesActivities-type', // 云系列活动
    'cloudSeriesActivities-zh',
    'cloudSeriesActivities-en',
    'cloudIntelligentExperience-zh', // 云智能体验
    'cloudIntelligentExperience-en',
    'newsInformation-type', // 新闻资讯
    'newsInformation-zh',
    'newsInformation-en',
    'newsInformation-hotzh',
    'newsInformation-hoten',
    'cooperativePartner-type', // 合作伙伴类型
    'cooperativePartner-zh',
    'cooperativePartner-en',
    '',
    'pcConfiguration', // pc配置
    'webConfiguration', // h5首页配置
    'scheduleGlance-zh', // 大会日程
    'scheduleGlance-en',
    'hotelGuide-zh', // 参会指南（协议酒店）
    'hotelGuide-en',
    '', // 直播id列表
    'excellentCases-zh', // 优秀案例
    'excellentCases-en',
  ]
}
