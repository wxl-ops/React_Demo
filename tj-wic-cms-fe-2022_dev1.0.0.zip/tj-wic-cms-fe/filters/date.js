import dayjs from 'dayjs'

export default {
  date_format: (date, setting = 'YYYY-MM-DD HH:mm:ss') => {
    return dayjs(date).format(setting)
  }
}
