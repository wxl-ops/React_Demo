import date from './date'

export default {
  ...date
}
