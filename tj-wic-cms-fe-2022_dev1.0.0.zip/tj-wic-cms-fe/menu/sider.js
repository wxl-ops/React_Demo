/*
 * @Author: const_ytl
 * @Date: 2022-03-15 14:45:58
 * @LastEditors: const_ytl
 * @LastEditTime: 2022-06-27 18:12:12
 * @Description: 请填写简介
 */
import registrationAgreement from './modules/registrationAgreement'
import agendaofConference from './modules/agendaofConference'
import conferenceGuests from './modules/conferenceGuests'
import homoSapiens from './modules/homoSapiens'
import cloudEvents from './modules/cloudEvents'
import eventIntroduction from './modules/eventIntroduction'
import cloudSeriesActivities from './modules/cloudSeriesActivities'
import cloudIntelligentExperience from './modules/cloudIntelligentExperience'
import newsInformation from './modules/newsInformation'
import cooperativePartner from './modules/cooperativePartner'
import registeredUsers from './modules/registeredUsers'
// import mediaInvitationCode from './modules/mediaInvitationCode'
import material from './modules/material'
import questionnaire from './modules/questionnaire'
import webConfiguration from './modules/webConfiguration'
import pcConfiguration from './modules/pcConfiguration'
import scheduleGlance from './modules/scheduleGlance'
import hotelGuide from './modules/hotelGuide'
import excellentCases from './modules/excellentCases'
import greatDemo from './modules/greatDemo'

export default [
  greatDemo,
  pcConfiguration,
  webConfiguration,
  scheduleGlance,
  registrationAgreement,
  agendaofConference,
  conferenceGuests,
  homoSapiens,
  cloudEvents,
  eventIntroduction,
  cloudSeriesActivities,
  cloudIntelligentExperience,
  newsInformation,
  cooperativePartner,
  excellentCases,
  material,
  hotelGuide,
  // registeredUsers,
  // mediaInvitationCode,
  questionnaire
]
