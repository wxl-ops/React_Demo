const pre = '/webConfiguration/'
export default {
  path: pre,
  title: '移动端首页配置',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}zh`,
      title: '中文版配置'
    },
    {
      path: `${pre}en`,
      title: '英文版配置'
    }
  ]
}
