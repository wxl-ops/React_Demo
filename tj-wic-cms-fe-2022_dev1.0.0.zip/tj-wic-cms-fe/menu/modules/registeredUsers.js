const pre = '/registeredUsers/'
export default {
  path: pre,
  title: '注册用户管理',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}user`,
      title: '用户管理',
      children: [
        {
          path: `${pre}user/detail`,
          title: '详情'
        }
      ]
    }
  ]
}
