/*
 * @Author: gd
 * @Date: 2022-05-05 10:39:34
 * @LastEditors: gd
 * @LastEditTime: 2022-05-05 16:17:56
 * @Description: 请填写简介
 */
const pre = '/pcConfiguration/'
export default {
  path: pre,
  title: 'PC首页配置',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}zh`,
      title: '中文版配置'
    },
    {
      path: `${pre}en`,
      title: '英文版配置'
    }
  ]
}
