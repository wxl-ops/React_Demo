const pre = '/questionnaire/'
export default {
  path: pre,
  title: '调查问卷',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}naire`,
      title: '观众问卷列表',
      children: [
        {
          path: `${pre}naire/detail`,
          title: '详情'
        }
      ]
    },
    {
      path: `${pre}enterprise`,
      title: '企业问卷列表',
      children: [
        {
          path: `${pre}enterprise/detail`,
          title: '详情'
        }
      ]
    }
  ]
}
