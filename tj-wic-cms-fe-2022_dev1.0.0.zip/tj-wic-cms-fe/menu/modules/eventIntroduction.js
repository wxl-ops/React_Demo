const pre = '/eventIntroduction/'
export default {
  path: pre,
  title: '赛事文章',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}zh`,
      title: '中文版配置',
      children: [
        {
          path: `${pre}zh/edit`,
          title: '编辑'
        },
        {
          path: `${pre}zh/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}en`,
      title: '英文版配置',
      children: [
        {
          path: `${pre}en/edit`,
          title: '编辑'
        },
        {
          path: `${pre}en/create`,
          title: '新建'
        }
      ]
    }
  ]
}
