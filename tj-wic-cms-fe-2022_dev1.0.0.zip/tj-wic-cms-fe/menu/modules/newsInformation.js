const pre = '/newsInformation/'
export default {
  path: pre,
  title: '新闻资讯',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}hotzh`,
      title: '中文热点',
      children: [
        {
          path: `${pre}hotzh/edit`,
          title: '编辑'
        },
        {
          path: `${pre}hotzh/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}hoten`,
      title: '英文热点',
      children: [
        {
          path: `${pre}hoten/edit`,
          title: '编辑'
        },
        {
          path: `${pre}hoten/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}type`,
      title: '新闻资讯类型',
      children: [
        {
          path: `${pre}type/edit`,
          title: '编辑'
        },
        {
          path: `${pre}type/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}zh`,
      title: '中文资讯',
      children: [
        {
          path: `${pre}zh/edit`,
          title: '编辑'
        },
        {
          path: `${pre}zh/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}en`,
      title: '英文资讯',
      children: [
        {
          path: `${pre}en/edit`,
          title: '编辑'
        },
        {
          path: `${pre}en/create`,
          title: '新建'
        }
      ]
    }
  ]
}
