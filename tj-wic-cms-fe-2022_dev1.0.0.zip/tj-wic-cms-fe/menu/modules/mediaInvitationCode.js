const pre = '/mediaInvitationCode/'
export default {
  path: pre,
  title: '媒体邀请码管理',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}code`,
      title: '媒体邀请码',
      children: [
        {
          path: `${pre}code/detail`,
          title: '详情'
        }
      ]
    }
  ]
}
