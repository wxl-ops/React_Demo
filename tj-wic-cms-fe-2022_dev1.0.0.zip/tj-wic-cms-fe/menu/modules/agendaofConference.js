/*
 * @Author: const_ytl
 * @Date: 2022-03-15 14:45:58
 * @LastEditors: const_ytl
 * @LastEditTime: 2022-04-06 10:51:16
 * @Description: 请填写简介
 */
const pre = '/agendaofConference/'
export default {
  path: pre,
  title: '峰会与论坛',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}type`,
      title: '论坛类型',
      children: [
        {
          path: `${pre}type/edit`,
          title: '编辑'
        },
        {
          path: `${pre}type/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}zh`,
      title: '中文版配置',
      children: [
        {
          path: `${pre}zh/edit`,
          title: '编辑'
        },
        {
          path: `${pre}zh/create`,
          title: '新建'
        },
        {
          path: `${pre}zh/vote`,
          title: '投票详情'
        }
      ]
    },
    {
      path: `${pre}en`,
      title: '英文版配置',
      children: [
        {
          path: `${pre}en/edit`,
          title: '编辑'
        },
        {
          path: `${pre}en/create`,
          title: '新建'
        },
        {
          path: `${pre}en/vote`,
          title: '投票详情'
        }
      ]
    }
  ]
}
