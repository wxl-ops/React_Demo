const pre = '/material/'
export default {
  path: 'material',
  title: '素材中心',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}picture`,
      title: '图片',
      hideChildren: true,
      children: [
        {
          path: `${pre}communication/edit`,
          title: '编辑',
          listName: 'communication'
        },
        {
          path: `${pre}communication/create`,
          title: '新建',
          listName: 'communication'
        }
      ]
    },
    {
      path: `${pre}video`,
      title: '视频',
      hideChildren: true,
      children: [
        {
          path: `${pre}news/edit`,
          title: '编辑',
          listName: 'news'
        },
        {
          path: `${pre}news/create`,
          title: '新建',
          listName: 'news'
        }
      ]
    },
    // {
    //   path: `${pre}enclosure`,
    //   title: '文件',
    //   hideChildren: true,
    //   children: [
    //     {
    //       path: `${pre}roam/edit`,
    //       title: '编辑',
    //       listName: 'roam'
    //     },
    //     {
    //       path: `${pre}roam/create`,
    //       title: '新建',
    //       listName: 'roam'
    //     }
    //   ]
    // },
    {
      path: `${pre}file`,
      title: '文档',
      hideChildren: true,
      children: [
        {
          path: `${pre}file/edit`,
          title: '编辑',
          listName: 'notice'
        },
        {
          path: `${pre}file/create`,
          title: '新建',
          listName: 'notice'
        }
      ]
    }
    // {
    //   path: `${pre}music`,
    //   title: '音频',
    //   hideChildren: true,
    //   children: [
    //     {
    //       path: `${pre}music/edit`,
    //       title: '编辑',
    //       listName: 'notice'
    //     },
    //     {
    //       path: `${pre}music/create`,
    //       title: '新建',
    //       listName: 'notice'
    //     }
    //   ]
    // }
  ]
}
