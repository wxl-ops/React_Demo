const pre = '/cloudSeriesActivities/'
export default {
  path: pre,
  title: '系列活动',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}type`, 
      title: '云系列活动类型',
      children: [
        {
          path: `${pre}type/edit`,
          title: '编辑'
        },
        {
          path: `${pre}type/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}zh`,
      title: '中文版配置',
      children: [
        {
          path: `${pre}zh/edit`,
          title: '编辑'
        },
        {
          path: `${pre}zh/create`,
          title: '新建'
        }
      ]
    },
    {
      path: `${pre}en`,
      title: '英文版配置',
      children: [
        {
          path: `${pre}en/edit`,
          title: '编辑'
        },
        {
          path: `${pre}en/create`,
          title: '新建'
        }
      ]
    }
  ]
}
