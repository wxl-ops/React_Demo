/*
 * @Author: gd
 * @Date: 2022-05-05 16:16:44
 * @LastEditors: gd
 * @LastEditTime: 2022-05-05 16:21:22
 * @Description: 请填写简介
 */

const pre = '/greatDemo/'
export default {
  path: pre,
  title: '页面呈现配置',
  header: 'home',
  icon: 'logo-buffer',
  children: [
    {
      path: `${pre}showConfig`, 
      title: '优秀案例配置',
    },
    // {
    //   path: `${pre}zh`,
    //   title: '中文版配置'
    // },
    // {
    //   path: `${pre}en`,
    //   title: '英文版配置'
    // }
  ]
}
