import pkg from './package'
const env = process.env.NODE_ENV
// require('dotenv').config()

// console.log(
//   `欢迎使用${process.env.title}, 有相关问题可以联系：${process.env.author}`
// )

export default {
  // buildDir: 'nuxt-dist',
  mode: 'spa',
  /*
   ** Headers of the page
   */
  env: {
    version: pkg.version,
    _ENV_: env
  },
  head: {
    title: '世界智能大会',
    meta: [
      { charset: 'utf-8' },
      {
        name: 'viewport',
        content:
          'width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, minimal-ui, viewport-fit=cover'
      },
      { name: 'screen-orientation', content: 'portrait' },
      { name: 'apple-mobile-web-app-capable', content: 'yes' },
      { name: 'format-detection', content: 'telephone=no' },
      { name: 'full-screen', content: 'yes' },
      { itemprop: 'name', content: '世界智能大会' },
      { itemprop: 'description', content: '世界智能大会' },
      {
        itemprop: 'image',
        content:
          '//baike-med-1256891581.file.myqcloud.com/2019088/dbeb0df0-be40-11e9-a853-dff0a4da1470_0.png'
      },
      { 'http-equiv': 'x-dns-prefetch-control', content: 'on' },
      { hid: 'description', name: 'description', content: pkg.description }
    ],
    link: [{ rel: 'icon', type: 'image/x-icon', href: '/cms-fe/favicon.ico' }]
  },
  /*
   ** Customize the progress-bar color
   */
  loading: { color: '#fff' },
  /*
   ** Global CSS
   */
  css: ['@/styles/theme/index.less', '@/styles/index.less'],
  /*
   ** Plugins to load before mounting the App
   */
  plugins: ['@/wau/plugins/index', '@/plugins/index', '@/plugins/route'],
  /*
   ** Nuxt.js dev-modules
   */
  buildModules: [
    // Doc: https://github.com/nuxt-community/eslint-module
    '@nuxtjs/eslint-module',
    // Doc: https://github.com/nuxt-community/stylelint-module
    '@nuxtjs/stylelint-module'
  ],
  /*
   ** Nuxt.js modules
   */
  modules: [
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    // Doc: https://github.com/nuxt-community/dotenv-module
    '@nuxtjs/dotenv',
    '@nuxtjs/proxy'
  ],
  /*
   ** Axios module configuration
   ** See https://axios.nuxtjs.org/options
   */
  axios: {
    proxy: true
  },
  proxy: {
    '/api': {
      target: 'https://t-2022cms.wicongress.org.cn',
      changeOrigin: true,
      logLevel: 'debug',
      secure: false,
      pathRewrite: {
        '^/api': ''
      }
    }
  },
  router: {
    base: '/cms-fe/',
    mode: 'hash', //history || hash
    extendRoutes(routes, resolve) {
      routes.push({
        name: 'custom',
        path: '*',
        component: resolve(__dirname, 'pages/error/404/index.vue')
      })
    }
  },
  server: {
    port: 8081,
    host: '0.0.0.0'
  },
  /*
   ** Build configuration
   */
  build: {
    /*
     ** You can extend webpack config here
     */
    babel: {
      plugins: ['@babel/plugin-proposal-optional-chaining']
    },
    maxChunkSize: 300000,
    /*
     ** You can extend webpack config here
     */
    extractCSS: true,
    optimization: {
      splitChunks: {
        chunks: 'async',
        minSize: 30000,
        maxSize: 0,
        minChunks: 1,
        maxAsyncRequests: 5,
        maxInitialRequests: 3,
        automaticNameDelimiter: '~',
        name: true,
        cacheGroups: {
          cos: {
            test: /node_modules[\\/]cos-js-sdk-v5/,
            chunks: 'all',
            priority: 30,
            name: true
          },
          iview: {
            test: /node_modules[\\/]view-design/,
            chunks: 'all',
            priority: 20,
            name: true
          },
          vendors: {
            test: /[\\/]node_modules[\\/]/,
            priority: -10
          },
          default: {
            minChunks: 2,
            priority: -20,
            reuseExistingChunk: true
          }
        }
      }
    },
    loaders: {
      less: {
        javascriptEnabled: true
      }
    },
    extend(config, ctx) {}
  }
}
